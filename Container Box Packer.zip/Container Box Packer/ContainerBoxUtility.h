#ifndef CONTAINER_BOX_TOOLS_H
#define CONTAINER_BOX_TOOLS_H

// header files
#include <stdlib.h>  // for malloc
#include <stdio.h>    // for printing recursion ops
#include <stdbool.h>  // for Boolean
#include "InsideBoxTools.h"
#include "PointTools.h"

typedef enum { NO_DISPLAY = 101, TO_MONITOR, TO_FILE } DisplayControl;

// Constants
extern const char DEFAULT_FIELD_CHAR;
extern const int NO_BOXES_AVAILABLE;
extern const int FILL_BOX;  // used to control fillBoxLocation function
extern const int CLEAR_BOX;  // used to control fillBoxLocation function
extern const int MAX_NUM_BOXES;

// Data Structures

typedef struct ContainerBoxDataStruct
   {
    char **field;

    InsideBoxData *insideBoxList;

    int width;

    int height;

    int numBoxes;
   } ContainerBoxData;

// Prototypes

/*
Name: checkForFitInField
process: finds location and limits of a given box and reports if it would
         fit in the 2D array (field)
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           test location starting point (PointData),
                           test box data (InsideBoxData)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool checkForFitInField( ContainerBoxData *containerBox,
                                PointData testLocation, InsideBoxData testBox );

/*
Name: clearContainerBox
process: deallocates all dynamic data in container box, 
         sets other data to zero or defaults
Function input/parameters: pointer to container box data (ContainerBoxData *)
Function output/parameters: updated pointer (set to NULL) (ContainerBoxData *)
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: free
*/
void clearContainerBox( ContainerBoxData *containerBox );

/*
Name: create2DArray
process: allocates array of pointers as rows,
         and data as columns of two dimensional character array
Function input/parameters: rows and columns (int)
Function output/parameters: none
Function output/returned: pointer to 2D array (char **)
Device input/---: none
Device output/---: none
Dependencies: malloc
*/
char **create2DArray( int maxRows, int maxCols );

/*
Name: displayField
process: displays complete container box with currently set internal boxes
         if display flag parameter is set
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           display flag (bool)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: character display as specified
Dependencies: printf
*/
void displayField( ContainerBoxData *containerBox, bool displayFlag );

/*
Name: fillBoxLocation
process: fills box with appropriate characters, posts to container box array,
         uses box letter unless clear flag is set, then it uses the default
         background character (DEFAULT_FIELD_CHAR) to clear the box area
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           box location (PointData), box shape (InsideBoxData ),
                           clear flag (bool)
Function output/parameters: updated pointer to container box data 
                                                            (ContainerBoxData *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void fillBoxLocation( ContainerBoxData *containerBox, PointData boxLocation, 
                                         InsideBoxData fillBox, int clearFlag );

/*
Name: fillContainerBox
process: uses recursive backtracking strategy to place smaller boxes
         inside larger container box
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           display flag (bool)
Function output/parameters: updated pointer to container box data 
                                                            (ContainerBoxData *)
Function output/returned: Boolean result of box location attempt (bool)
Device input/---: none
Device output/---: none
Dependencies: as needed
*/
bool fillContainerBox( ContainerBoxData *containerBox, bool displayFlag );

/*
Name: findNextOpenLocation
process: searches from lower right to upper left for first blank location
         (background character - DEFAULT_FIELD_CHAR) in the container box, 
         returns point data to location
Function input/parameters: pointer to container box data (ContainerBoxData *)
Function output/parameters: pointer to found point data (PointData *) if found
Function output/returned: Boolean result of search (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool findNextOpenLocation( const ContainerBoxData *containerBox, 
                                                       PointData *returnPoint );

/*
Name: findNextUnusedBoxIndex
process: searches from specified index to end of box list 
         for available (not used) box, returns array index of box if found,
         if not found, returns NO_BOXES_AVAILABLE
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           index at which to start (int)
Function output/parameters: none
Function output/returned: available box index (int)
Device input/---: none
Device output/---: none
Dependencies: none
*/
int findNextUnusedBoxIndex( ContainerBoxData *containerBox, int startAtIndex );

/*
Name: initializeContainerBox
process: creates two dimensional array for container box,
         sets all elements to background (DEFAULT_FIELD_CHAR) character,
         creates inside box list, sets other member data to empty/defaults
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           number of boxes (int)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: create2DArray, malloc
*/
void initializeContainerBox( ContainerBoxData *containerBox, int numBoxes );

/*
Name: rotate
process: rotates a given box by setting width to height and height to width
Function input/parameters: pointer to box (InsideBoxData *)
Function output/parameters: updated pointer to box (InsideBoxData *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void rotateBox( InsideBoxData *box );

#endif   // CONTAINER_BOX_TOOLS_H


