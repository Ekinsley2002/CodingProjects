// Header files
#include "ContainerBoxUtility.h"

// constant definitions
const char DEFAULT_FIELD_CHAR = '-';
const int NO_BOXES_AVAILABLE = -1;
const int FILL_BOX = 102;  // used to control fillBoxLocation function
const int CLEAR_BOX = 103;  // used to control fillBoxLocation function
const int MAX_NUM_BOXES = 26;  // number of letters in alphabet

// function implementations

/*
Name: checkForFitInField
process: finds location and limits of a given box and reports if it would
         fit in the 2D array (field)
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           test location starting point (PointData),
                           test box data (InsideBoxData)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool checkForFitInField( ContainerBoxData *containerBox,
                                 PointData testLocation, InsideBoxData testBox )
   {
    // initialize function/variables

       // set height and width limits
       int heightLimit = testLocation.pos_Y - testBox.height;
       int widthLimit = testLocation.pos_X + testBox.width;

       // set above box limit to -1
       int aboveBox = -1;
 
       // initialize indices
       int rowIndex, colIndex;
    
    // check for calculated limits out of bounds
    if( heightLimit < aboveBox || widthLimit > containerBox->width )
       {
        // return false
        return false;              
       }
    
    // row loop from bottom up
    for( rowIndex = testLocation.pos_Y; rowIndex > heightLimit; rowIndex-- )
       {
        // col loop from left to right
        for( colIndex = testLocation.pos_X; colIndex < widthLimit; colIndex++ )
           {
            // check for anything other than default character
            if( containerBox->field[ rowIndex ][ colIndex ] 
                                                         != DEFAULT_FIELD_CHAR )
               {
                // return false
                return false;
               }
           }
       }
    
    // return true
    return true;
   }

/*
Name: clearContainerBox
process: deallocates all dynamic data in container box, 
         sets other data to zero or defaults
Function input/parameters: pointer to container box data (ContainerBoxData *)
Function output/parameters: updated pointer (set to NULL) (ContainerBoxData *)
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: free
*/
void clearContainerBox( ContainerBoxData *containerBox )
   {
    // initialize function/variables
    int rowIndex;

    // loop across container box rows
    for( rowIndex = 0; rowIndex < containerBox->height; rowIndex++ )
       {
        // free memory at row
           // function: free
        free( containerBox->field[ rowIndex ] );
       }

    // free pointer array
    free( containerBox->field );

    // sest container field pointer to null
    containerBox->field = NULL;

    // set width, height, number of boxes to zero
    containerBox->height = containerBox->numBoxes = 0;
    containerBox->width = containerBox->height;

    // free the box list array
       // function: free
    free( containerBox->insideBoxList );

    // set the box list pointer to null
    containerBox->insideBoxList = NULL;

    // free the data structure
    free( containerBox );
   }

/*
Name: create2DArray
process: allocates array of pointers as rows,
         and data as columns of two dimensional character array
Function input/parameters: rows and columns (int)
Function output/parameters: none
Function output/returned: pointer to 2D array (char **)
Device input/---: none
Device output/---: none
Dependencies: malloc
*/
char **create2DArray( int maxRows, int maxCols )
   {
    // initialize function/variables
    int rowIndex;

    // create double pointer (2D) array pointer
       // function: malloc
    char **array = (char **)malloc( maxRows * sizeof( char * ) );

    // loop across rows of pointer
    for( rowIndex = 0; rowIndex < maxRows; rowIndex++ )
       {
        // create a new row at each element of the 2D array
           // function: malloc
        array[ rowIndex ] = (char *)malloc( maxCols * sizeof( char ) );
       }

    // return the double pointer to the initialized 2D array
    return array;
   }

/*
Name: displayField
process: displays complete container box with currently set internal boxes
         if display flag parameter is set
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           display flag (bool)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: character display as specified
Dependencies: printf
*/
void displayField( ContainerBoxData *containerBox, bool displayFlag )
   {
    // initialize function/variables
    int rowIndex, colIndex;
    
    // check for display flag
    if( displayFlag )
       {
        // print vertical space
           // function: printf
        printf( "\n" );
        
        // loop across container width plus two for edges to draw top line
        for( colIndex = 0; colIndex < containerBox->width + 2; colIndex++ )
           {
            // print equal signs
               // function: printf
            printf( "%c", '=' );
           }
          
        // print end line
           // function: printf
        printf( "\n" );
        
        // loop across container rows
        for( rowIndex = 0; rowIndex < containerBox->height; rowIndex++ )
           {
            // print initial pipe for lefts side
               // function: printf
            printf( "|" );
            
            // loop across columns of row
            for( colIndex = 0; colIndex < containerBox->width; colIndex++ )
               {
                // print box characters
                   // function: printf
                printf( "%c", containerBox->field[ rowIndex ][ colIndex ] );
               }
            
            // print pipe with end line
               // function: printf
            printf( "|\n" );
           }

        // loop across container width plus two for edges to draw bottom line
        for( colIndex = 0; colIndex < containerBox->width + 2; colIndex++ )
           {
            // print equals sign
               // function: printf
            printf( "%c", '=' );
           }
        
        // print end line
           // function: printf
        printf( "\n" );  
       }
   }

/*
Name: fillBoxLocation
process: fills box with appropriate characters, posts to container box array,
         uses box letter unless clear flag is set, then it uses the default
         background character (DEFAULT_FIELD_CHAR) to clear the box area
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           box location (PointData), box shape (InsideBoxData ),
                           clear flag (bool)
Function output/parameters: updated pointer to container box data 
                                                            (ContainerBoxData *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void fillBoxLocation( ContainerBoxData *containerBox, PointData boxLocation, 
                                         InsideBoxData fillBox, int clearFlag )
   {
    // initialize function/variables

       // find height and width limits
       int heightLimit = boxLocation.pos_Y - fillBox.height;
       int widthLimit = boxLocation.pos_X + fillBox.width;

       // get id letter of box, assign to fill character
       char fillChar = fillBox.idLetter;

       // declare loop indices
    int rowIndex, colIndex;
    
    // check for clear flag
    if( clearFlag == CLEAR_BOX )
       {
        // assign default to fill character
        fillChar = DEFAULT_FIELD_CHAR;
       }
    
    // loop across rows from bottom to top
    for( rowIndex = boxLocation.pos_Y; rowIndex > heightLimit; rowIndex-- )
       {
        // loop across columns from left to right
        for( colIndex = boxLocation.pos_X; colIndex < widthLimit; colIndex++ )
           {
            // place fill characters 
            containerBox->field[ rowIndex ][ colIndex ] = fillChar;
           }
       }
   }

/*
Name: fillContainerBox
process: uses recursive backtracking strategy to place smaller boxes
         inside larger container box
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           display flag (bool)
Function output/parameters: updated pointer to container box data 
                                                            (ContainerBoxData *)
Function output/returned: Boolean result of box location attempt (bool)
Device input/---: none
Device output/---: none
Dependencies: as needed
*/
bool fillContainerBox( ContainerBoxData *containerBox, bool displayFlag )
  {
   // initialize functions/variables
      // initialize the point location data
      PointData locationPoint;
      // initialize index variable for box list
      int currentBox = 0;
      // initialize previously rotated flag
      bool prevRotated;
      // initialize next location/flag variable
      bool nextLocation;
      
   // find the next location/flag
      // function findNextOpenLocation
   nextLocation = findNextOpenLocation( containerBox, &locationPoint );
   // find next unused box
      // function: findNextUnusedBoxIndex
   currentBox = findNextUnusedBoxIndex( containerBox, currentBox );
   
   // check to see if we should stop based on the following cases
   // no boxes left
   if( ( nextLocation ) && currentBox == NO_BOXES_AVAILABLE )
     {
       return false;
     }
   // no spaces left
   else if( ( !nextLocation ) && currentBox != NO_BOXES_AVAILABLE )
     {
      return false;
     }
   // no spaces left and no boxes left
   else if( ( !nextLocation )  && currentBox == NO_BOXES_AVAILABLE )
     {
      return true;
     }
   
   // as long as there is boxes
   while( currentBox != NO_BOXES_AVAILABLE )
     {
      //check if box fits
         // function: checkForFitInField
      if( checkForFitInField( containerBox, locationPoint,
         containerBox->insideBoxList[ currentBox ] ) )
        {
         // place the block in the container
            // function: fillBoxLocation
         fillBoxLocation( containerBox, locationPoint,
            containerBox->insideBoxList[ currentBox ], FILL_BOX );
         // set container box used state to true
         containerBox->insideBoxList[ currentBox ].usedState = true;
         // display the container
            // function: displayField
         displayField( containerBox, displayFlag );
         // return true if container box is full
            // function: fillContainerBox
         if( fillContainerBox( containerBox, displayFlag ) )
           {
            return true;
           }
         // clear the box from container
            // function: fillBoxLocation
         fillBoxLocation( containerBox, locationPoint,
            containerBox->insideBoxList[ currentBox ], CLEAR_BOX );
         // set the used state of the current box to false
         containerBox->insideBoxList[ currentBox ].usedState = false;
   

/*
Name: findNextOpenLocation
process: searches from lower right to upper left for first blank location
         (background character - DEFAULT_FIELD_CHAR) in the container box, 
         returns point data to location
         // display the container
            // function: displayField
         displayField( containerBox, displayFlag );
        }
      // if the box hasnt been rotated, then rotate it
         // function: rotateBox
      if( !prevRotated )
        {
         printf( "\nBox %c first attempt failed, rotating\n",
            containerBox->insideBoxList[ currentBox ].idLetter );
         rotateBox( &containerBox->insideBoxList[ currentBox ] );
         prevRotated = true;
        }
      // if the box has been rotated before, try another box
         // function: findNextUnusedBoxIndex
      else
        {
         printf( "\nBox %c second attempt failed, trying another box\n",
            containerBox->insideBoxList[ currentBox ].idLetter );
         rotateBox( &containerBox->insideBoxList[ currentBox ] );
         prevRotated = false;
         currentBox = findNextUnusedBoxIndex( containerBox, currentBox + 1 );
        }
     }
   // if the code reaches this point, return false and start backtracking
   printf( "\nFailed at this location, backtracking\n" );
   return false;
  }
   

/*
Name: findNextOpenLocation
process: searches from lower right to upper left for first blank location
         (background character - DEFAULT_FIELD_CHAR) in the container box, 
         returns point data to location
Function input/parameters: pointer to container box data (ContainerBoxData *)
Function output/parameters: pointer to found point data (PointData *) if found
Function output/returned: Boolean result of search (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool findNextOpenLocation( const ContainerBoxData *containerBox, 
                                                        PointData *returnPoint )
   {
    // initialize function/variables
    int rowIndex, colIndex;
    
    // loop across container box rows bottom to top
    for( rowIndex = containerBox->height - 1; rowIndex >= 0; rowIndex-- )
       {
        // loop across container rows left to right
        for( colIndex = 0; colIndex < containerBox->width; colIndex++ )
           {
            // check for default character
            if( containerBox->field[ rowIndex ][ colIndex ] 
                                                         == DEFAULT_FIELD_CHAR )
               {
                // set return values
                returnPoint->pos_X = colIndex; 
                returnPoint->pos_Y = rowIndex;

                // return true
                return true;
               }
           }
       }

    // assume test failed, return false
    return false;
   }

/*
Name: findNextUnusedBoxIndex
process: searches from specified index to end of box list 
         for available (not used) box, returns array index of box if found,
         if not found, returns NO_BOXES_AVAILABLE
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           index at which to start (int)
Function output/parameters: none
Function output/returned: available box index (int)
Device input/---: none
Device output/---: none
Dependencies: none
*/
int findNextUnusedBoxIndex( ContainerBoxData *containerBox, int startAtIndex )
   {
    // initialize function/variables
       // none

    // loop from given start index
    while( startAtIndex < containerBox->numBoxes )
       {
        // check for unused state
        if( !containerBox->insideBoxList[ startAtIndex ].usedState )
           {
            // return current index
            return startAtIndex;
           }
        
        // increment index
        startAtIndex++;
       }
    
    // assume no boxes found, return no boxes condition
    return NO_BOXES_AVAILABLE;
   }

/*
Name: initializeContainerBox
process: creates two dimensional array for container box,
         sets all elements to background (DEFAULT_FIELD_CHAR) character,
         creates inside box list, sets other member data to empty/defaults
Function input/parameters: pointer to container box data (ContainerBoxData *),
                           number of boxes (int)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: create2DArray, malloc
*/
void initializeContainerBox( ContainerBoxData *containerBox, int numBoxes )
   {
    // initialize function/variables
    int rowIndex, colIndex;
        
    // create the 2D array with the given height and width
       // function: create2DArray
    containerBox->field = create2DArray( containerBox->height, 
                                                          containerBox->width );

    // loop across rows of container
    for( rowIndex = 0; rowIndex < containerBox->height; rowIndex++ )
       {
        // loop across columns of container
        for( colIndex = 0; colIndex < containerBox->width; colIndex++ )
           {
            // set element to default character
            containerBox->field[ rowIndex ][ colIndex ] = DEFAULT_FIELD_CHAR;
           }
       }

    // create the box list (array) with the number of boxes
       // function: malloc
    containerBox->insideBoxList 
                = (InsideBoxData *)malloc( numBoxes * sizeof( InsideBoxData ) );

    // set the number of boxes into the container box struct
    containerBox->numBoxes = numBoxes;
   }

/*
Name: rotate
process: rotates a given box by setting width to height and height to width
Function input/parameters: pointer to box (InsideBoxData *)
Function output/parameters: updated pointer to box (InsideBoxData *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void rotateBox( InsideBoxData *box )
   {
    // initialize function/variables

       // set temp to box width
       int tempWidth = box->width;
   
    // set width to height 
    box->width = box->height;
    
    // set height to width (temp)
    box->height = tempWidth;
   }


