#ifndef POINT_TOOLS_H
#define POINT_TOOLS_H

// Constants


// Data Structures

typedef struct PointDataStruct
   {
    int pos_X;

    int pos_Y;
   } PointData;

// Prototypes


#endif   // POINT_TOOLS_H


