#ifndef PROJECT_9_H
#define PROJECT_9_H

// header files
#include <stdlib.h>
#include <time.h>
#include "Console_IO_Utility.h"
#include "File_Input_Utility.h"
#include "File_Output_Utility.h"

////////////////////////////////////////////////////////////////////////////////
// External constants

#define N_CHOICE 'n'

////////////////////////////////////////////////////////////////////////////////
// Data Structures

typedef struct GameElementStruct
   {
    bool elementSet;

    bool elementUsed;

    int elementVal;
   } GameElementType;


// Prototypes - Forward Declarations

/*
Name: clearTwoDimensionalArray
Process: Clears data type array rows, then data type array
Function input/parameters: pointer to two-dimensional array (GameElementType **),
                           number of rows (int)
Function output/parameters: none
Function output/returned: NULL (GameElementType *)
Device input/---: none
Device output/---: none
Dependencies: free
*/
GameElementType **clearTwoDimensionalArray( 
                                         GameElementType **array, int numRows );

/*
Name: createTwoDimensionalArray
Process: creates array of row pointers, then arrays of columns on each pointer
Function input/parameters: number of rows & columns (int)
Function output/parameters: none
Function output/returned: pointer to created two-dimensional array 
                                                            (GameElementType **)
Device input/---: none
Device output/---: none
Dependencies: malloc
*/
GameElementType **createTwoDimensionalArray( int numRows, int numCols );

/*
Name: displayArr
Process: if display character is not 'n', displays array as follows:
         - if display character is set to 'c', displays entire array
         - if display character is set to 'y', displays only current attempts
Function input/parameters: pointer to two-dimensional array 
                                                           (GameElementType **),
                           number of rows & columns (int),
                           display character (char)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed to screen as specified
Dependencies: printf, elementIsUsed
*/
void displayArr( GameElementType **array, 
                                      int numRows, int numCols, char dispChar );

/*
Name: duplicateTwoDimensionalArray
Process: creates duplicate of array parameter
Function input/parameters: pointer to source array (GameElementType *),
                           number of rows & columns (int)
Function output/parameters: none
Function output/returned: pointer to duplicate two-dimensional array 
                                                            (GameElementType **)
Device input/---: none
Device output/---: none
Dependencies: createTwoDimensionalArray
*/
GameElementType **duplicateTwoDimensionalArray( GameElementType **srcArr, 
                                                     int numRows, int numCols );

/*
Name: elementExists
Process: tests for element indices within array bounds, reports
Function input/parameters: number of rows & columns, row & column index (int)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
Note: if statement may not be used
*/
bool elementExists( int numRows, int numCols, int rowIndex, int colIndex );
       
/*
Name: elementIsSet
Process: tests for element set (i.e., holds a value)
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns, row & column index (int)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
Note: if statement may not be used
Note: does not protect from boundary limits
*/
bool elementIsSet( GameElementType **array, int rowIndex, int colIndex );
    
/*
Name: elementIsUsed
Process: tests for element used (i.e., has been set during game)
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns, row & column index (int)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
Note: if statement may not be used
Note: does not protect from boundary limits
*/
bool elementIsUsed( GameElementType **array, int rowIndex, int colIndex );
    
/*
Name: getRandBetween
Process: generates random value within provided low and high limits 
         (i.e., inclusive)
Function input/parameters: low & high limits (int)
Function output/parameters: none
Function output/returned: resulting value as specified (int)
Device input/---: none
Device output/---: none
Dependencies: rand
Note: must use two statements
*/
int getRandBetween( int lowLimit, int highLimit ); 
    
/*
Name: getValueAt
Process: tests for provided indices in bounds,
         then sets element values into result parameter,
         if indices out of bounds, sets all element values to zero or false
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns, row & column index (int)
Function output/parameters: pointer to result value (GameElementType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: elementExists
*/
void getValueAt( GameElementType *result, 
                        GameElementType **array, int numRows, 
                                      int numCols, int rowIndex, int colIndex );
      
/*
Name: initializeGameBoard
Process: initializes all members of each elements on a game board 
         to zero and false
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns (int)
Function output/parameters: pointer to updated array (GameElementType **)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void initializeGameBoard( GameElementType **array, int numRows, int numCols );
 
/*
Name: playGame
Process: game play driver:
         - if playGameFromFile Boolean set, retrieves game;
           - if game upload fails, returns NULL
         - otherwise, prompts user for grid rows and columns
         - creates a duplicate game array for potential storage
         - initial score set to number of rows times number of columns
         - starts loop, plays game by prompting user for row/col input,
           - if winning location is found, reports, ends game, 
             and returns duplicated array
           - if input is out of bounds, decrements score
           - if input misses win location, reports, sets element to used,
             and decrements score
           - if input has already been tried, reports, and decrements score 
           - displays grid depending on displayControl 
         - returns duplicated game array         
Function input/parameters: pointer to array (GameElementType **),
                           pointers to numbers of rows & columns (int *),
                           play game from file flag (bool),
                           display control (char)
Function output/parameters: pointer to updated array (GameElementType **),
                            pointers to updated numbers of rows and columns 
                                                                        (int *),
Function output/returned: pointer to copy of unplayed game (GameElementType **)
Device input/keyboard: game play input as specified
Device output/monitor: game play display as specified
Dependencies: retrieveGame, promptForInteger, createTwoDimensionalArray,
              initializeGameBoard, setWinSpot, duplicateTwoDimensionalArray,
              displayArr, printf, elementExists, getValueAt,
              clearTwoDimensionalArray 
*/
GameElementType **playGame( GameElementType **gameArr, int *numRows, 
                        int *numCols, bool playGameFromFile, char dispControl );

/*
Name: retrieveGame
Process: prompts user for file name,
         retrieves previously created game from file,
         acquires row and column values,
         creates and initializes new array, 
         sets all element values,
         returns initial score,
         prints "Game file not found - Please try again" if file not found
         and returns NULL
Function input/parameters: none
Function output/parameters: pointers to numbers of rows & columns, initialScore 
                                                                           (int)
Function output/returned: pointer to retrieved game array (GameElementType *)
Device input/---: none
Device output/---: none
Dependencies: promptForString, openInputFile, readStringToDelimiterFromFile,
              readIntegerFromFile, createTwoDimensionalArray, 
              initializeGameBoard, closeInputFile
*/
GameElementType **retrieveGame( int *numRows, int *numCols, int *initialScore );

/*
Name: setAllNearNeighbors
Process: sets all near neighbors of all elements in the array,
         if they exist and are in bounds
Function input/parameters: none
Function output/parameters: pointer to game array (GameElementType **),
                            number of rows and columns
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: setNearNeighbors
*/
void setAllNearNeighbors( GameElementType **array, int numRows, int numCols );

/*
Name: setNearNeighbors
Process: given a location, checks for value set,
         if so, sets above, below, left, and right elements 
         to one more than the location value where possible,
         reports setting at least one of the neighbor elements
Function input/parameters: pointer to array (GameElementType **),
                            number of rows & columns (int),
                            row and column indices (int)
Function output/parameters: none
Function output/returned: Boolean report that at least one neighbor was set 
                                                                          (bool)
Device input/---: none
Device output/---: none
Dependencies: elementExists, elementIsSet
*/
bool setNearNeighbors( GameElementType **array, int numRows, 
                                      int numCols, int rowIndex, int colIndex );

/*
Name: setWinSpot
Process: given the number of rows and columns, generates a location
         as the win spot (value 1), and assigns the appropriate data
         to the array location members
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns (int)
Function output/parameters: pointer to updated array (GameElementType **)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: getRandBetween
*/
void setWinSpot( GameElementType **array, int numRows, int numCols );
                 
/*
Name: storeGame
Process: prompts user for file name,
         checks that array has data,
         opens file, stores "Number of Rows:" with the correct value,
         stores "Number of Columns:" with the correct value,
         then stores game element values as a matrix to a text file,
         closes file, if no game has been played,
         prints "Game currently not stored - Please try again"
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns (int)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: promptForString, openOutputFile, writeStringToFile,
              writeIntegerToFile, writeEndlineToFile, sprintf,
              closeOutputFile
*/
void storeGame( GameElementType **array, int numRows, int numCols );

/*
Name: toLowerCase
Process: tests input character for upper case,
         if character is upper case, converts to lower case,
         otherwise returns character unchanged
Function input/parameters: test character (char)
Function output/parameters: none
Function output/returned: character updated as specified (char)
Device input/---: none
Device output/---: none
Dependencies: none
Note: no more than three lines of actual code
*/
char toLowerCase( char testChar );

#endif    // PROJECT_9_H
