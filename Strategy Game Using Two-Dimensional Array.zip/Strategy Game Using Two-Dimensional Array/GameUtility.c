#include "GameUtility.h"

////////////////////////////////////////////////////////////////////////////////
// local constants
const char C_CHOICE = 'c';
const char Y_CHOICE = 'y';
const int NOT_FOUND = -111;
const int WIN_ELEMENT = 1;

/*
Name: clearTwoDimensionalArray
Process: Clears data type array rows, then data type array
Function input/parameters: pointer to two-dimensional array (GameElementType **),
                           number of rows (int)
Function output/parameters: none
Function output/returned: NULL (GameElementType *)
Device input/---: none
Device output/---: none
Dependencies: free
*/
GameElementType **clearTwoDimensionalArray( 
                                         GameElementType **array, int numRows )
   {
    int rowIndex;

    if( array != NULL )
       {
        for( rowIndex = 0; rowIndex < numRows; rowIndex++ )
           {
            free( array[ rowIndex ] );
           }

        free( array );
       }

   return NULL;
   }

/*
Name: createTwoDimensionalArray
Process: creates array of row pointers, then arrays of columns on each pointer
Function input/parameters: number of rows & columns (int)
Function output/parameters: none
Function output/returned: pointer to created two-dimensional array 
                                                            (GameElementType **)
Device input/---: none
Device output/---: none
Dependencies: malloc
*/
GameElementType **createTwoDimensionalArray( int numRows, int numCols )
   {
    // initialize function/variables
    int rowIndex;
    GameElementType **array;

    // create pointers for each row
    array = (GameElementType **)malloc( numRows * sizeof( GameElementType *) );

    // create individual rows of columns
    for( rowIndex = 0; rowIndex < numRows; rowIndex++ )
       {
        array[ rowIndex ] = (GameElementType *)malloc( 
                                          numCols * sizeof( GameElementType ) );
       }

    return array;
   }

/*
Name: displayArr
Process: if display character is not 'n', displays array as follows:
         - if display character is set to 'c', displays entire array
         - if display character is set to 'y', displays only current attempts
Function input/parameters: pointer to two-dimensional array 
                                                           (GameElementType **),
                           number of rows & columns (int),
                           display character (char)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed to screen as specified
Dependencies: printf, elementIsUsed
*/
void displayArr( GameElementType **array, 
                                       int numRows, int numCols, char dispChar )
    {
        // initialize functions/variables
           // initialize row index variable
           int indexRow = 0;
           // initialize row index variable
           int indexCol = 0;
           // initialize boolean variable to test if array has been printed
           bool arrayPrinted = false;
	   
        // while loop to check display choice options	
        while ( ( ( dispChar == C_CHOICE ) || ( dispChar == Y_CHOICE))
                                           && (!arrayPrinted) )
            {   
                // print display array title
                printf("\nDisplay Array:\n\n");
                // traverse game array
                for ( indexRow = 0; indexRow<numRows; indexRow++ )
                    {
                    for ( indexCol = 0; indexCol<numCols; indexCol++ )
                        {
                            // if the users choice is Y and if
                            //the element hasn't been used
                                // function: elementIsUsed
                            if ( ( dispChar == Y_CHOICE) && 
                                                       ( !elementIsUsed(array, indexRow, indexCol) ) )
                                {
                                    // print ASTERISK
                                    printf( "%3c", ASTERISK );
                                }
                            // if the users choice is N
                            // or if the element has been used
                            else
                                {
                                    // print the current elements value
                                    printf( "%3d",
                                          array[indexRow][indexCol].elementVal );
                                }
                        }
                        // print newline
                        printf( "%c", NEWLINE_CHAR );
                   }
                   // once array has been printed, make array printed true
                   arrayPrinted = true;
            }
    }	

/*
Name: duplicateTwoDimensionalArray
Process: creates duplicate of array parameter
Function input/parameters: pointer to source array (GameElementType *),
                           number of rows & columns (int)
Function output/parameters: none
Function output/returned: pointer to duplicate two-dimensional array 
                                                            (GameElementType **)
Device input/---: none
Device output/---: none
Dependencies: createTwoDimensionalArray
*/
GameElementType **duplicateTwoDimensionalArray( GameElementType **srcArr, 
                                                      int numRows, int numCols )
    {
        // initialize function/variables

            // initialize row index variable
            int indexRow = 0;

            // initialize col index variable
            int indexCol = 0;

        // create stored array pointer
        GameElementType **dupArray;

        // allocate memeory for the duplicated array
            // function: createTwoDimensionalArray
        dupArray = createTwoDimensionalArray(numRows, numCols);

        // traverse the source array
        for ( indexRow = 0; indexRow < numRows; indexRow++ ) 
            {
                for ( indexCol = 0; indexCol < numCols; indexCol++ ) 
                    {
                        // store current element 
                        // from source array into duplicatedArray
                        dupArray[ indexRow ][ indexCol ].elementVal 
                                      = srcArr[ indexRow ][ indexCol ].elementVal;
                    }
            }

        // return the duplicated array
        return dupArray;
    }

/*
Name: elementExists
Process: tests for element indices within array bounds, reports
Function input/parameters: number of rows & columns, row & column index (int)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
Note: if statement may not be used
*/
bool elementExists( int numRows, int numCols, int rowIndex, int colIndex )
    {
        // while row index and col index is in range
        return ( ( rowIndex >= 0 ) && ( rowIndex < numRows )
                                  && ( colIndex >= 0) && (colIndex < numCols) )
              {
                  // return true
                  return true;
              }
    }
       
/*
Name: elementIsSet
Process: tests for element set (i.e., holds a value)
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns, row & column index (int)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: elementExists (may not need)
Note: if statement may not be used
Note: does not protect from boundary limits
*/
bool elementIsSet( GameElementType **array, int rowIndex, int colIndex )
   {
        // return boolean value elementSet from the given rowIndex and colIndex
	    return array[ rowIndex ][ colIndex ].elementSet;
   }
    
/*
Name: elementIsUsed
Process: tests for element used (i.e., has been set during game)
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns, row & column index (int)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: elementExists (may not need)
Note: if statement may not be used
Note: does not protect from boundary limits
*/
bool elementIsUsed( GameElementType **array, int rowIndex, int colIndex )
   {
	    // return boolean value elementUsed from the given rowIndex and colIndex
        return array[ rowIndex ][ colIndex ].elementUsed;
   }
    
/*
Name: getRandBetween
Process: generates random value within provided low and high limits 
         (i.e., inclusive)
Function input/parameters: low & high limits (int)
Function output/parameters: none
Function output/returned: resulting value as specified (int)
Device input/---: none
Device output/---: none
Dependencies: rand
Note: must use two statements
*/
int getRandBetween( int lowLimit, int highLimit ) 
    {
        // set the range for the random number
        int range = highLimit + 1 - lowLimit;
        // return random number within the limits
            //function: rand
        return rand() % range + lowLimit;
    }
    
/*
Name: getValueAt
Process: tests for provided indices in bounds,
         then sets element values into result parameter,
         if indices out of bounds, sets all element values to zero or false
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns, row & column index (int)
Function output/parameters: pointer to result value (GameElementType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: elementExists
*/
void getValueAt( GameElementType *result, 
                        GameElementType **array, int numRows, 
                                       int numCols, int rowIndex, int colIndex )
    {
        // if the element given exist
    if ( elementExists( numRows, numCols, rowIndex, colIndex) )
       {
           // set the result to the value of the position in the array
           *result = array[ rowIndex ][ colIndex ];
       }
    // if indices are out of bounds
    else
       {
           // set elementSet and elementUsed to false and eleemnt value to 0
           result->elementVal = 0;
           result->elementSet = false;
           result->elementUsed = false;
       }
    }
      
/*
Name: initializeGameBoard
Process: initializes all members of each elements on a game board 
         to zero and false
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns (int)
Function output/parameters: pointer to updated array (GameElementType **)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void initializeGameBoard( GameElementType **array, int numRows, int numCols )
    {
        // initialize function/variables
            // initialize row index variable
            int indexRow = 0;
            // initialize row index variable
            int indexCol = 0;
        // traverse the game array
        for ( indexRow = 0; indexRow < numRows; indexRow++ )
            {
            for ( indexCol = 0; indexCol < numCols; indexCol++ )
                {
                    // initialize elements as zero and false
                    array[ indexRow ][ indexCol ].elementVal = 0; 
                    array[ indexRow ][ indexCol ].elementSet = false;
                    array[ indexRow ][ indexCol ].elementUsed = false;
                }
            }
    }
 
/*
Name: playGame
Process: game play driver:
         - if playGameFromFile Boolean set, retrieves game;
           - if game upload fails, returns NULL
         - otherwise, prompts user for grid rows and columns
         - creates a duplicate game array for potential storage
         - initial score set to number of rows times number of columns
         - starts loop, plays game by prompting user for row/col input,
           - if winning location is found, reports, ends game, 
             and returns duplicated array
           - if input is out of bounds, decrements score
           - if input misses win location, reports, sets element to used,
             and decrements score
           - if input has already been tried, reports, and decrements score 
           - displays grid depending on displayControl 
         - returns duplicated game array         
Function input/parameters: pointer to array (GameElementType **),
                           pointers to numbers of rows & columns (int *),
                           play game from file flag (bool),
                           display control (char)
Function output/parameters: pointer to updated array (GameElementType **),
                            pointers to updated numbers of rows and columns 
                                                                        (int *),
Function output/returned: pointer to copy of unplayed game (GameElementType **)
Device input/keyboard: game play input as specified
Device output/monitor: game play display as specified
Dependencies: retrieveGame, promptForInteger, createTwoDimensionalArray,
              initializeGameBoard, setWinSpot, duplicateTwoDimensionalArray,
              displayArr, printf, elementExists, getValueAt,
              clearTwoDimensionalArray 
*/
GameElementType **playGame( GameElementType **gameArr, int *numRows, 
                        int *numCols, bool playGameFromFile, char dispControl )
   {
    // initialize function/variables

       // initialize game won flag to false
       bool gameWon = false;      

       // initialize current score to zero
       int currentGameScore = 0;

       // create stored array pointer
       GameElementType **storeArr;
       GameElementType result;

       // initialize other variables
       int inputRow, inputCol;

    // clear game, in case previously used
    // only clears if gameArr pointer is NULL
    gameArr = clearTwoDimensionalArray( gameArr, *numRows );

    // check for play game from file
    if( playGameFromFile )
       {
        gameArr = retrieveGame( numRows, numCols, &currentGameScore );

        if( gameArr == NULL )
           {
            return NULL;
           }
       }

    // otherwise, assume new game
    else
       {
        *numRows 
          = promptForInteger( "\n       Enter the number of rows in the grid: " );

        *numCols = promptForInteger( "    Enter the number of columns in the grid: " );

        gameArr = createTwoDimensionalArray( *numRows, *numCols );

        initializeGameBoard( gameArr, *numRows, *numCols );

        setWinSpot( gameArr, *numRows, *numCols );

        setAllNearNeighbors( gameArr, *numRows, *numCols );

        currentGameScore = *numRows * *numCols;
       }

    // create duplicate for return
    storeArr = duplicateTwoDimensionalArray( gameArr, *numRows, *numCols );

    // display array, depending on display control
    displayArr( gameArr, *numRows, *numCols, dispControl );

    // start loop for game
    do
       {
        // prompt for row index
           // function: printf, promptForChar
        printf( "\nEnter row index between 0 and %d", *numRows - 1);
        inputRow = promptForInteger( ": " );

        // prompt for col index
           // function: printf, promptForChar
        printf( "Enter col index between 0 and %d", *numCols - 1);
        inputCol = promptForInteger( ": " );

        // check for valid location
           // function: elementExists
        if( elementExists( *numRows, *numCols, inputRow, inputCol ) )
           {
            // get value at location
               // function: getValueAt
            getValueAt( &result, gameArr, *numRows, 
                                                 *numCols, inputRow, inputCol );

            // check for win
            if( result.elementVal == WIN_ELEMENT )
               {
                // print winning display
                   // function: printf
                printf( "\nYOU FOUND IT at (%d, %d)! Your final score is %d\n", 
                                         inputRow, inputCol, currentGameScore );                  
                // set element to used state
                   // function: setElementUsed
                gameArr[ inputRow][ inputCol ].elementUsed = true;

                // set game won flag to true
                gameWon = true;
               }

            // otherwise, check for already used location
            else if( result.elementUsed )
               {
                // decrement game score
                currentGameScore--;
             
                // print used location display
                   // function: printf
                printf( "You have already tried the element at (%d, %d);", 
                                                           inputRow, inputCol );
                printf( " your score is now %d\n", currentGameScore );
               }
             
            // otherwise, assume new valid value found
            else
               {
                // decrement score
                currentGameScore--;

                // print value found display
                   // function: printf
                printf( "Value %d found at (%d, %d); your score is now %d\n", 
                      result.elementVal, inputRow, inputCol, currentGameScore );
          
                // set element to used state
                   // function: setElementUsed
                gameArr[ inputRow][ inputCol ].elementUsed = true;
               }
           }

        // otherwise, assume location out of bounds
        else
           {
            // decrement score
            currentGameScore--;

            // print location out of bounds display
               // function: printf
            printf( "The element at (%d, %d) is outside the boundaries", 
                                                           inputRow, inputCol ); 
            printf( " of your game; your score is now %d\n", currentGameScore );
           }

        displayArr( gameArr, *numRows, *numCols, dispControl );
       }
    // loop until game won
    while( !gameWon );

    // clear game array
    gameArr = clearTwoDimensionalArray( gameArr, *numRows ); 

    // return unused game copy
    return storeArr;
   }

/*
Name: retrieveGame
Process: prompts user for file name,
         retrieves previously created game from file,
         acquires row and column values,
         creates and initializes new array, 
         sets all element values,
         returns initial score,
         prints "Game file not found - Please try again" if file not found
         and returns NULL
Function input/parameters: none
Function output/parameters: pointers to numbers of rows & columns, initialScore 
                                                                           (int)
Function output/returned: pointer to retrieved game array (GameElementType *)
Device input/---: none
Device output/---: none
Dependencies: promptForString, openInputFile, readStringToDelimiterFromFile,
              readIntegerFromFile, createTwoDimensionalArray, 
              initializeGameBoard, closeInputFile
*/
GameElementType **retrieveGame( int *numRows, int *numCols, int *initialScore )
    {
        // initialize functions/variables
            // initialize file name variable
            char fileName[ MAX_STR_LEN ];
            // initialize temporary string variable
            char tempStr[ MIN_STR_LEN ];
            // initialize row index variable
            int indexRow = 0;
            // initialize column index variable
            int indexCol = 0;

        GameElementType **gameArray;

        // prompt the user for the file name
        promptForString( "\nPlease enter file name: ", fileName );

        // check if the file is found
        if ( openInputFile( fileName ) )
            { 
                // read the number of rows and columns from the file
                    // functions: readStringToDelimiterFromFile,
                        // readIntegerFromFile
		   
                // remove strings until integer variable
                readStringToDelimiterFromFile( COLON, tempStr );
                // read the integer and store it in numRows variable
                *numRows = readIntegerFromFile();
			  
                // remove strings until integer variable
                readStringToDelimiterFromFile( COLON, tempStr );
                // read the integer and store it in numCols variable
                *numCols = readIntegerFromFile();

                // allocate memory for the game array
                    // function: createTwoDimensionalArray
                gameArray = createTwoDimensionalArray( *numRows, *numCols );

                // initialize the game board
                    // function: initializeGameBoard
                initializeGameBoard( gameArray, *numRows, *numCols );

                // traverse the game array
                for ( indexRow = 0; indexRow < *numRows; indexRow++ ) 
                    {
                    for ( indexCol= 0; indexCol < *numCols; indexCol++ )
                        {
                            // asign each element value to the integer being read
                                // function: readIntegerFromFile
                            gameArray[ indexRow ][ indexCol ].elementVal = readIntegerFromFile();
                        }
                    }

                // create initial game score from numRows and numCols
                *initialScore = *numRows * *numCols;

                // close the input file
                    // function: closeInputFile
                closeInputFile();

                // return the retrieved game array
                return gameArray;
            }    
        // if the file is not found
        else
            {
                // print a message if the file is not found
                printf( "Game file not found - Please try again\n" );
                return NULL;
            }
    }

/*
Name: setAllNearNeighbors
Process: sets all near neighbors of all elements in the array,
         if they exist and are in bounds
Function input/parameters: none
Function output/parameters: pointer to game array (GameElementType **),
                            number of rows and columns
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: setNearNeighbors
*/
void setAllNearNeighbors( GameElementType **array, int numRows, int numCols )
    {
        // initialize function/variables

            // initialize row index variable
            int indexRow = 0;
            // initialize column index variable
            int indexCol = 0;
            // set actionTaken flag to true
            bool actionTaken = true;

        while ( actionTaken )
            {
                // set actionTaken flag to false
                actionTaken = false;

                // traverse the 2d array
                for ( indexRow = 0; indexRow < numRows; indexRow++ )
                    {
                        for ( indexCol = 0; indexCol < numRows; indexCol++ )
                            {
                                // check to see if the current element is set
                                // AND initiate setNearNeighbors
                                if ( ( ( array[ indexRow ][ indexCol ].elementSet) ) && 
                                       ( setNearNeighbors( array, numRows, numCols,
                                                            indexRow, indexCol ) ) ) 
                                    {
                                        actionTaken = true;
                                    }
                            }
                    }
            }   
    }

/*
Name: setNearNeighbors
Process: given a location, checks for value set,
         if so, sets above, below, left, and right elements 
         to one more than the location value where possible,
         reports setting at least one of the neighbor elements
Function input/parameters: pointer to array (GameElementType **),
                            number of rows & columns (int),
                            row and column indices (int)
Function output/parameters: none
Function output/returned: Boolean report that at least one neighbor was set 
                                                                          (bool)
Device input/---: none
Device output/---: none
Dependencies: elementExists, elementIsSet
*/
bool setNearNeighbors( GameElementType **array, int numRows, 
                                       int numCols, int rowIndex, int colIndex )
    {
    // initialize function/variables

       // set action taken flag to false
       bool actionTaken = false;

       // set current value to element at given location
       int currentValue;
    
    // check for current element is set
    if( elementExists( numRows, numCols, rowIndex, colIndex ) 
                                  && elementIsSet( array, rowIndex, colIndex ) )
       {
        // get value
        currentValue = array[ rowIndex ][ colIndex ].elementVal;

        // check for element below exists and is clear
           // function: elementExists, elementIsClear
        if( elementExists( numRows, numCols, rowIndex + 1, colIndex ) 
                             && !elementIsSet( array, rowIndex + 1, colIndex ) )
           {
            // set below element to current value plus one
            array[ rowIndex + 1 ][ colIndex ].elementVal = currentValue + 1;
            array[ rowIndex + 1 ][ colIndex ].elementSet = true;
            
            // set action taken flag to true
            actionTaken = true;
           }

        // check for element above exists and is clear
           // function: elementExists, elementIsClear
        if( elementExists( numRows, numCols, rowIndex - 1, colIndex ) 
                             && !elementIsSet( array, rowIndex - 1, colIndex ) )
           {
            // set above element to current value plus one
            array[ rowIndex - 1 ][ colIndex ].elementVal = currentValue + 1;                                
            array[ rowIndex - 1 ][ colIndex ].elementSet = true;                                
            
            // set action taken flag to true
            actionTaken = true;
           }

        // check for element to the right exists and is clear
           // function: elementExists, elementIsClear
        if( elementExists( numRows, numCols, rowIndex, colIndex + 1 ) 
                             && !elementIsSet( array, rowIndex, colIndex + 1 ) )
           {
            // set right side element to current value plus one
            array[ rowIndex ][ colIndex + 1 ].elementVal = currentValue + 1;                                
            array[ rowIndex ][ colIndex + 1 ].elementSet = true;                                
            
            // set action taken flag to true
            actionTaken = true;
           }

        // check for element to the left exists and is clear
           // function: elementExists, elementIsClear
        if( elementExists( numRows, numCols, rowIndex, colIndex - 1 ) 
                             && !elementIsSet( array, rowIndex, colIndex - 1 ) )
           {
            // set left side element to current value plus one
            array[ rowIndex ][ colIndex - 1 ].elementVal = currentValue + 1;                                
            array[ rowIndex ][ colIndex - 1 ].elementSet = true;                                
            
            // set action taken flag to true
            actionTaken = true;
           }
       }

    // return action taken flag    
    return actionTaken;
    }

/*
Name: setWinSpot
Process: given the number of rows and columns, generates a location
         as the win spot (value 1), and assigns the appropriate data
         to the array location members
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns (int)
Function output/parameters: pointer to updated array (GameElementType **)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: getRandBetween
*/
void setWinSpot( GameElementType **array, int numRows, int numCols )
    {
        // initialize function/variables
            // initialize random row variable
            int randomRow;
            // initialize random column variable
            int randomCol;
            // initialize lower bound variable
            int lowerBound = 0;

        // initialize a random integer representing row in bounds
            // function: getRandBetween
        randomRow = getRandBetween( lowerBound, numRows - 1 );

        // initialize a random integer representing column in bounds
            // function: getRandBetween
        randomCol = getRandBetween( lowerBound, numCols - 1 );

	    // assign the appropriate data to the array location members
	    array[ randomRow ][ randomCol ].elementVal = WIN_ELEMENT;

        // set elementSet to true
        array[ randomRow ][ randomCol ].elementSet = true;
    }
                 
/*
Name: storeGame
Process: prompts user for file name,
         checks that array has data,
         opens file, stores "Number of Rows:" with the correct value,
         stores "Number of Columns:" with the correct value,
         then stores game element values as a matrix to a text file,
         closes file, if no game has been played,
         prints "Game currently not stored - Please try again"
Function input/parameters: pointer to array (GameElementType **),
                           number of rows & columns (int)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: promptForString, openOutputFile, writeStringToFile,
              writeIntegerToFile, writeEndlineToFile, sprintf,
              closeOutputFile
*/
void storeGame( GameElementType **array, int numRows, int numCols )
    {
        // initialize function/variables

            // intitialize row index variable
            int indexRow = 0;
            // intitialize column index variable
            int indexCol = 0;
            // initialize file name variable
            char fileName[ MAX_STR_LEN ];
            // initialize column prompt variable
            char buffer[ MAX_STR_LEN ];

        // prompt the user for file
            // function: promptForString
        promptForString( "\nPlease enter file name: ", fileName );

        // if the array is made
        if (array != NULL)
            {
                // open file
                    //function: openOutputFile
                openOutputFile( fileName );

                // write data into file
                    // write the number of rows prompt into stored file
                        // function: writeStringToFile
                    writeStringToFile( "Number of Rows: " );
                    // write the numRows integer into file
                        // function: writeIntegerToFile
                    writeIntegerToFile( numRows );
                    // write end of line into file
                        // function: writeEndlineToFile
                    writeEndlineToFile();
                    // write the number of rows for the stored file
                        // function: writeStringToFile
                    writeStringToFile( "Number of Columns: " );
                    // write the numRows integer into file
                        // function: writeIntegerToFile
                    writeIntegerToFile( numCols );
                    // write endLine for good spacing
                        // function: writeEndlineToFile
                    writeEndlineToFile();
                    // write endLine for good spacing
                        // function: writeEndlineToFile
                    writeEndlineToFile();

                    // traverse game array 
                    for ( indexRow = 0; indexRow < numRows; indexRow++ ) 
                        {
                            for ( indexCol = 0; indexCol < numCols; indexCol++ ) 
                                {
                                    // assign current element value to buffer
                                        // function: sprintf
                                    sprintf(buffer, "%3d", 
                                       array[ indexRow ][ indexCol ].elementVal);

                                    //write the element value to the file
                                        // function: writeStringToFile
                                    writeStringToFile( buffer );
                                }
                            // print newline
                                // function: writeEndlineToFile
                            writeEndlineToFile();
                        }

                    // close output file
                        // function: closeOutputFile
                    closeOutputFile();
            }

        // if there is no game currently stored
        else
            {
                // tell the user there is no game stored
                printf( "\nGame currently not stored - Please try again\n" );
            }
    }

/*
Name: toLowerCase
Process: tests input character for upper case,
         if character is upper case, converts to lower case,
         otherwise returns character unchanged
Function input/parameters: test character (char)
Function output/parameters: none
Function output/returned: character updated as specified (char)
Device input/---: none
Device output/---: none
Dependencies: none
Note: no more than three lines of actual code
*/
char toLowerCase(char testChar) 
    {
        // check to see if given charecter is uppercase
        if ( testChar >= 'A' && testChar <= 'Z' ) 
            {
                // convert and return lowercase char
                return testChar + ( 'a' - 'A' );
            }
        // otherwise return the initial charecter
        return testChar;
    }
   
   
   
   
   
   
   