// header files
#include "GameUtility.h"


/*
Description: Strategy game using two-dimensional array

Instructions: User creates board with given row and column limits.
Program places a winning value (1) at a random location,
then runs through array placing increasing values 
at near neighbors (left, right, top, bottom). The higher the value,
the farther from the winning location; the lower the value,
the closer to the winning location
*/
       
int main()
   {
    // initialize program/variables
	

       // initialize variables
       int numRows, numCols;
       GameElementType **gameArray = NULL;
       bool continueGame = true, gameFromFile = false;
       char inputChar, displayChar = N_CHOICE;

       // show title
          // function: printf
       printf( "\nGrid Search Game\n" );
       printf( "================\n" );

       // seed random generator
         // function: srand
       srand( time( NULL ) );

    // start menu loop
    do
       {
        printf( "\n     MAIN MENU\n\n" );

        printf( "1) Play <n>ew game\n" );
        printf( "2) Play game from <f>ile\n" );
        printf( "3) Set <d>isplay control\n" );
        printf( "4) <S>tore game to file\n" );
        printf( "5) <E>nd program\n\n" );
       
        inputChar = promptForCharacter( "Enter selection: " );

        switch( inputChar )
           {
            case '1':
            case 'N':
            case 'n':

               gameFromFile = false;
               gameArray = playGame( gameArray, &numRows, 
                                          &numCols, gameFromFile, displayChar );

               break;

            case '2':
            case 'F':
            case 'f':

               gameFromFile = true;  
               gameArray = playGame( gameArray, &numRows, 
                                          &numCols, gameFromFile, displayChar );

               break;

            case '3':
            case 'D':
            case 'd':
 
               displayChar 
                      = promptForCharacter( "Enter display selection (Y/N): " );
               displayChar = toLowerCase( displayChar );

               break;

            case '4':
            case 'S':
            case 's':
 
               storeGame( gameArray, numRows, numCols );

               break;

            case '5':
            case 'E':
            case 'e':
 
               continueGame = false;

               break;

            default:

               printf( "\nERROR: Incorrect selection entered - " );
               printf( "Please make another selection\n\n" );
        
               break;
           }
       }
    while( continueGame );

    // end program

       // clear array as needed
          // function: clearTwoDimensionalArray
       gameArray = clearTwoDimensionalArray( gameArray, numRows );

       // show program end
          // function: printf
       printf( "\nEnd Program\n" );
   }

