#include "QueueUtility.h"

/*
Name: clearQueue
Process: recursively deallocates queue linked list, returns NULL
Function input/parameters: pointer to first (head) queue node (QueueNodeType *)
Function output/parameters: none
Function output/returned: NULL (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearQueueNode, clearQueue (recursively)
*/
QueueNodeType *clearQueue( QueueNodeType *queuePtr )
  {
   // check to see if queue is not empty
   if( queuePtr != NULL )
     {
      // clear next pointer
      clearQueue( queuePtr->nextPtr );
      // clear next node
      clearQueueNode( queuePtr );
     }

   return NULL;
  }

/*
Name: clearQueueNode
Process: deallocates queue node, returns NULL
Function input/parameters: pointer to queue node (QueueNodeType *)
Function output/parameters: none
Function output/returned: NULL (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
QueueNodeType *clearQueueNode( QueueNodeType *queuePtr )
  {  
   // free the queue ptr
   free( queuePtr );
   return NULL;
  }

/*
Name: initializeQueue
Process: initializes queue head pointer to NULL
Function input/parameters: none
Function output/parameters: none
Function output/returned: NULL (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
QueueNodeType *initializeQueue()
  {
   return NULL;
  }

/*
Name: createQueueNodeWithData
Process: dynamically allocates new linked list node,
         then stores name, returns pointer to new node
Function input/parameters: name (const char *)
Function output/parameters: none
Function output/returned: created Queue node (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, privateCopyString
*/
QueueNodeType *createQueueNodeWithData( const char *name )
  {
   //allocate memory for new node
   QueueNodeType *newNode = (QueueNodeType *)malloc( sizeof( QueueNodeType ) );
   
   //copy name to node
   privateCopyString( newNode->name, name );
   
   //make next ptr equal to null
   newNode->nextPtr = NULL;
   
   //return the new node
   return newNode;
  }

/*
Name: dequeue
Process: removes and returns name at front of queue (end of linked list)
         if found, sets return data, deallocates node, and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: address of pointer to queue first node 
                                                               (QueueNodeType *)
Function output/parameters: removed string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString, clearQueueNode
*/
bool dequeue( QueueNodeType **addressOfQueueHeadPtr, char *returnStr )
  {
   // Make a current node
   QueueNodeType *currentNode = *addressOfQueueHeadPtr;

   // Check if the queue is empty
   if( *addressOfQueueHeadPtr == NULL )
     {
      // Return false
      return false;
     }

   if( (*addressOfQueueHeadPtr )->nextPtr == NULL )
     {
      // Copy the name from the only node to returnStr
      privateCopyString(returnStr, ( *addressOfQueueHeadPtr )->name);

      // Deallocate the memory for the only node
      clearQueueNode( *addressOfQueueHeadPtr );

      // Set the head pointer to NULL
      *addressOfQueueHeadPtr = NULL;

      // Return true
      return true;
     }

   // Traverse the queue until the last node
   while( currentNode->nextPtr->nextPtr != NULL )
     {
      // Set current node to its next pointer
      currentNode = currentNode->nextPtr;
     }
   // copy the next pointer name to return
   privateCopyString( returnStr, currentNode->nextPtr->name );
   
   // make next pointer equal to null
   currentNode->nextPtr = NULL;
   
   // clear the next pointer
   clearQueueNode( currentNode->nextPtr );
   return true;
  } 


/*
Name: duplicateQueue
Process: if source queue is not empty,
         creates new queue, copies data from given source
Function input/parameters: pointer to source queue (const QueueNodeType *)
Function output/parameters: none
Function output/returned: new duplicated queue (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueueNodeWithData
*/
QueueNodeType *duplicateQueue( const QueueNodeType *srcPtr )
  {
   // make a new queue pointer
   QueueNodeType *newQueuePtr = NULL;
   // make a source pointer and a working pointer
   QueueNodeType *srcWkgPtr, *destWkgPtr;
   
   // if the source pointer doesn't equal NULL
   if( srcPtr != NULL )
     {
      // create new node with the name
      newQueuePtr = createQueueNodeWithData( srcPtr->name );
      // make destination working pointer equal to new queue ptr
      destWkgPtr = newQueuePtr;
      // assign source working pointer to the next pointer
      srcWkgPtr = srcPtr->nextPtr;
      
      // traverse the linked list
      while( srcWkgPtr != NULL )
        {
         destWkgPtr->nextPtr = createQueueNodeWithData( srcWkgPtr->name );

         destWkgPtr = destWkgPtr->nextPtr;

         srcWkgPtr = srcWkgPtr->nextPtr;
        }   
     }
   return newQueuePtr;
  }

/*
Name: enqueue
Process: adds new data to the rear of the queue (beginning of linked list)
Function input/parameters: address of pointer to queue first node 
                                                            (QueueNodeType **),
                           new name/string (const char *)
Function output/parameters: address of pointer to updated queue 
                                                             (QueueNodeType **)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueueNodeWithData
*/
void enqueue( QueueNodeType **queueHeadPtr, const char *newStr )
  {
   // make a new node
   QueueNodeType *newNode = createQueueNodeWithData( newStr );

   // make the next pointer the head pointer
   newNode->nextPtr = *queueHeadPtr;
   
   // make the head pointer equal the new node
   *queueHeadPtr = newNode;
  }

/*
Name: peekFront
Process: returns value at the front of the queue (end of linked list)
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to queue first node (QueueNodeType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekFront( QueueNodeType *queueHeadPtr, char *returnStr )
  {
   // create a current node and make it equal to head pointer
   QueueNodeType *currentNode = queueHeadPtr;
    
   // check if the list is empty
   if( queueHeadPtr == NULL )
     {
      return false;
     }
   // traverse the linked list
   while( currentNode->nextPtr != NULL )
     {
      currentNode = currentNode->nextPtr;
     }
   // copy the front item to result string
   privateCopyString( returnStr, currentNode->name );
   
   return true;
  }

/*
Name: queueIsEmpty
Process: returns true if queue is empty, false otherwise
Function input/parameters: pointer to queue (QueueNodeType *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool queueIsEmpty( QueueNodeType *queue )
  {
   return queue == NULL;
  }