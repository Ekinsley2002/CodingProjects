// header file
#include "File_Input_Utility.h"
#include "GeneralUtility.h"
#include "StackUtility.h"
#include "QueueUtility.h"

// local constants for program
const int MAX_STATES = 55;

// function prototypes
void showTitle();
bool uploadNames( char nameArray[][ STD_STR_LEN ], const char *fileName );
void displayQueue( QueueNodeType *queuePtr );
void displayStack( StackNodeType *stackPtr );

int main()
   {
    // initialize function/program

       // initialize variables
       char names[ MAX_STATES ][ STD_STR_LEN ];
       char name[ STD_STR_LEN ];
       int index, testStart, testLimit;

       // show title
          // function: showTitle
       showTitle();

       // create data pointers
       QueueNodeType *queuePtr, *dupQueuePtr;
       StackNodeType *stackPtr, *dupStackPtr;
       
    // set up data
    queuePtr = initializeQueue();
    dupQueuePtr = initializeQueue();
    stackPtr = initializeStack();
    dupStackPtr = initializeStack();

    // Upload data
    if( uploadNames( names, "StateData.csv" ) )
       {
        // Testing for Queues
        printf( "\nQueue Test Bed ------------------------------------\n\n" );

        printf( "Enqueue items:\n" );

        testStart = 0; testLimit = 15;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Enqueueing: %s\n", name );

            enqueue( &queuePtr, name );
           }

        displayQueue( queuePtr );

        printf( "Dequeue items:\n" );

        testStart = 0; testLimit = 5;
        for( index = testStart; index < testLimit; index++ )
           {
            dequeue( &queuePtr, name );

            printf( "Dequeueing: %s\n", name );
           }

        displayQueue( queuePtr );

        printf( "Enqueue more items:\n" );

        testStart = 20; testLimit = 25;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Enqueueing: %s\n", name );

            enqueue( &queuePtr, name );
           }

        displayQueue( queuePtr );

        printf( "*** Duplicating queue ***\n" );

        dupQueuePtr = duplicateQueue( queuePtr );

        printf( "\nDequeueing duplicate queue until empty:\n" );

        while( dequeue( &dupQueuePtr, name ) )
           {
            printf( "Dequeueing: %s\n", name );
           }

        // Testing for Stacks
        printf( "\nStack Test Bed ------------------------------------\n\n" );

        printf( "Push items on stack:\n" );

        testStart = 0; testLimit = 15;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Pushing: %s\n", name );

            push( &stackPtr, name );
           }

        displayStack( stackPtr );

        printf( "Pop items from stack:\n" );

        testStart = 0; testLimit = 5;
        for( index = testStart; index < testLimit; index++ )
           {
            pop( &stackPtr, name );

            printf( "Popping: %s\n", name );
           }

        displayStack( stackPtr );

        printf( "Push more items on stack:\n" );

        testStart = 25; testLimit = 30;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Pushing: %s\n", name );

            push( &stackPtr, name );
           }

        displayStack( stackPtr );

        printf( "*** Duplicating stack ***\n\n" );

        dupStackPtr = duplicateStack( stackPtr );

        printf( "Popping duplicate stack until empty:\n" );

        while( pop( &dupStackPtr, name ) )
           {
            printf( "Popping: %s\n", name );
           }
       }

    else
       {
        printf( "\nFile not found - Program aborted\n" );
       }
       
    // end program

       // report end program
          // function: printf
       printf( "\nProgram End\n" );

       // deallocate memory

       stackPtr = clearStack( stackPtr );

       queuePtr = clearQueue( queuePtr );

       dupQueuePtr = clearQueue( dupQueuePtr );

       // return program success
       return 0;
   }

void showTitle()
   {
    printf( "\nData Structure Test Program\n" );
    printf( "===========================\n" );
   }

/*
Name: displayQueue
Process: displays queue names from rear to front
Function input/parameters: pointer to queue (QueueNodeType *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: printf
*/
void displayQueue( QueueNodeType *queuePtr )
   {
    printf( "\nCurrent queue:\n" );
    printf( "    Rear\n" );
    printf( "============\n" );

    while( queuePtr != NULL )
       {
        printf( "%s\n", queuePtr->name );

        queuePtr = queuePtr->nextPtr;
       }

    printf( "=============\n" );
    printf( "    Front\n\n" );
   }

/*
Name: displayStack
Process: displays stack names from top to bottom
Function input/parameters: pointer to stack (StackNodeType *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: printf
*/
void displayStack( StackNodeType *stackPtr )
   {
    printf( "\nCurrent stack:\n" );
    printf( "    Top\n" );
    printf( "===========\n" );

    while( stackPtr != NULL )
       {
        printf( "%s\n", stackPtr->name );

        stackPtr = stackPtr->nextPtr;
       }

    printf( "============\n" );
    printf( "   Bottom\n\n" );
   }

/*
Name: uploadNames
Process: uploads names from given state data file,
         ignores first (title) line in .csv file,
         then captures comma-delimited state name, population, growth, 
         and political majority data on each row,
         then sets name in array,
         returns true if upload successful, false otherwise
Function input/parameters: file name (const char *)
Function output/parameters: updated array with uploaded values (StateDataType *)
Function output/returned: Boolean result of upload operation
Device input/HD: data uploaded from text file as specified
Device output/---: none
Dependencies: as needed
*/
bool uploadNames( char nameArray[][ STD_STR_LEN ], const char *fileName )
   {
    int intVal, index = 0;
    char name[ STD_STR_LEN ];
    char charVal;
    double doubleVal;
    bool verboseFlag = false;

    if( openInputFile( fileName ) )
       {
        // input top row, ignore
        readStringToLineEndFromFile( name );

        // input first data line, read prime
        readStringToDelimiterFromFile( COMMA, name );

        while( !checkForEndOfInputFile() )
           {
            // get population
            intVal = readIntegerFromFile();
            readCharacterFromFile();

            // get growth percentage
            doubleVal = readDoubleFromFile();
            readCharacterFromFile();
        
            charVal = readCharacterFromFile();

            if( verboseFlag )
               {
                printf( "[%3d] name: %s, int: %d, double: %7.6f, char: %c\n",
                              index + 1, name, intVal, doubleVal, charVal );
               }
            
            privateCopyString( nameArray[ index ], name  );

            index++;
  
            // read re-prime
            readStringToDelimiterFromFile( COMMA, name );
           }

        closeInputFile();

        return true;
       }

    return false;
   }


