#ifndef QUEUE_UTILITY_H
#define QUEUE_UTILITY_H

////////////////////////////////////////////////////////////////////////////////
// header files
#include <stdbool.h>
#include <stdlib.h>
#include "GeneralUtility.h"
#include <stdio.h>  // diagnostics
////////////////////////////////////////////////////////////////////////////////
// data structures

typedef struct QueueNodeStruct
   {
    char name[ STD_STR_LEN ];

    struct QueueNodeStruct *nextPtr;
   } QueueNodeType;

////////////////////////////////////////////////////////////////////////////////
// function prototypes

/*
Name: clearQueue
Process: recursively deallocates queue linked list, returns NULL
Function input/parameters: pointer to first (head) queue node (QueueNodeType *)
Function output/parameters: none
Function output/returned: NULL (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearQueueNode, clearQueue (recursively)
*/
QueueNodeType *clearQueue( QueueNodeType *queuePtr );

/*
Name: clearQueueNode
Process: deallocates queue node, returns NULL
Function input/parameters: pointer to queue node (QueueNodeType *)
Function output/parameters: none
Function output/returned: NULL (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
QueueNodeType *clearQueueNode( QueueNodeType *queuePtr );

/*
Name: initializeQueue
Process: initializes queue head pointer to NULL
Function input/parameters: none
Function output/parameters: none
Function output/returned: NULL (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
QueueNodeType *initializeQueue();

/*
Name: createQueueNodeWithData
Process: dynamically allocates new linked list node,
         then stores name, returns pointer to new node
Function input/parameters: name (const char *)
Function output/parameters: none
Function output/returned: created Queue node (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, privateCopyString
*/
QueueNodeType *createQueueNodeWithData( const char *name );

/*
Name: dequeue
Process: removes and returns name at front of queue (end of linked list)
         if found, sets return data, deallocates node, and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: address of pointer to queue first node 
                                                               (QueueNodeType *)
Function output/parameters: removed string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString, clearQueueNode
*/
bool dequeue( QueueNodeType **addressOfQueueHeadPtr, char *returnStr );

/*
Name: duplicateQueue
Process: if source queue is not empty,
         creates new queue, copies data from given source
Function input/parameters: pointer to source queue (const QueueNodeType *)
Function output/parameters: none
Function output/returned: new duplicated queue (QueueNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueueNodeWithData
*/
QueueNodeType *duplicateQueue( const QueueNodeType *srcPtr );

/*
Name: enqueue
Process: adds new data to the rear of the queue (beginning of linked list)
Function input/parameters: address of pointer to queue first node 
                                                             (QueueNodeType **),
                           new name/string (const char *)
Function output/parameters: address of pointer to updated queue 
                                                              (QueueNodeType **)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueueNodeWithData
*/
void enqueue( QueueNodeType **queueHeadPtr, const char *newStr );

/*
Name: peekFront
Process: returns value at the front of the queue (end of linked list)
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to queue first node (QueueNodeType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekFront( QueueNodeType *queueHeadPtr, char *returnStr );

/*
Name: queueIsEmpty
Process: returns true if queue is empty, false otherwise
Function input/parameters: pointer to queue (QueueNodeType *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool queueIsEmpty( QueueNodeType *queue );


#endif   // QUEUE_UTILITY_H

