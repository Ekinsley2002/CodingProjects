#ifndef STACK_UTILITY_H
#define STACK_UTILITY_H

////////////////////////////////////////////////////////////////////////////////
// header files
#include <stdbool.h>
#include <stdlib.h>
#include "GeneralUtility.h"
#include <stdio.h>  // diagnostics
////////////////////////////////////////////////////////////////////////////////
// data structures

typedef struct StackNodeStruct
   {
    char name[ STD_STR_LEN ];

    struct StackNodeStruct *nextPtr;
   } StackNodeType;


////////////////////////////////////////////////////////////////////////////////
// function prototypes

/*
Name: clearStack
Process: recursively deallocates stack, returns NULL
Function input/parameters: pointer to stack (StackNodeType *)
Function output/parameters: none
Function output/returned: NULL (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearStackNode, clearStack (recursively)
*/
StackNodeType *clearStack( StackNodeType *stackPtr );

/*
Name: clearStackNode
Process: deallocates stack node, returns NULL
Function input/parameters: pointer to stack node (StackNodeType *)
Function output/parameters: none
Function output/returned: NULL (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
StackNodeType *clearStackNode( StackNodeType *stackPtr );

/*
Name: initializeStack
Process: returns NULL to initialize linked list
Function input/parameters: none
Function output/parameters: none
Function output/returned: NULL (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
StackNodeType *initializeStack();

/*
Name: createStackNodeWithData
Process: allocates new linked list node with string data,
         returns pointer to new node
Function input/parameters: name (const char *)
Function output/parameters: created stack node (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc
*/
StackNodeType *createStackNodeWithData( const char *name );

/*
Name: duplicateStack
Process: creates new stack, copies data from given source
Function input/parameters: pointer to source stack (const StackNodeType *)
Function output/parameters: none
Function output/returned: new duplicated stack (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createStackNodeWithData
*/
StackNodeType *duplicateStack( const StackNodeType *srcPtr );

/*
Name: peekTop
Process: returns value at the top of the stack,
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to source stack (StackNodeType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (char *)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekTop( StackNodeType *stackPtr, char *returnStr );

/*
Name: pop
Process: removes and returns name at top of stack (bottom of linked list)
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to address of stack (StackNodeType **)
Function output/parameters: pointer to updated address of stack 
                                                             (StackNodeType **),
                            removed string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString, clearStackNode
*/
bool pop( StackNodeType **addressOfStackPtr, char *returnStr );

/*
Name: push
Process: adds new data to the top of the stack (bottom of linked list)
Function input/parameters: pointer to address of stack (StackNodeType **),
                           new name/string (const char *)
Function output/parameters: pointer to updated address of stack 
                                                              (StackNodeType **)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createStackNodeWithData
*/
void push( StackNodeType **addressOfStackPtr, const char *newStr );

/*
Name: stackIsEmpty
Process: returns true if stack is empty, false otherwise
Function input/parameters: pointer to stack (Stack *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool stackIsEmpty( StackNodeType *stackPtr );

#endif