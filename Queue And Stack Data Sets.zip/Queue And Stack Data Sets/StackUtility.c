#include "StackUtility.h"

////////////////////////////////////////////////////////////////////////////////
// function implementations

/*
Name: clearStack
Process: recursively deallocates stack, returns NULL
Function input/parameters: pointer to stack (StackNodeType *)
Function output/parameters: none
Function output/returned: NULL (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearStackNode, clearStack (recursively)
*/
StackNodeType *clearStack( StackNodeType *stackPtr )
   {
    if( stackPtr != NULL )
       {
        clearStack( stackPtr->nextPtr );

        clearStackNode( stackPtr );
       }

    return NULL;
   }

/*
Name: clearStackNode
Process: deallocates stack node, returns NULL
Function input/parameters: pointer to stack node (StackNodeType *)
Function output/parameters: none
Function output/returned: NULL (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
StackNodeType *clearStackNode( StackNodeType *stackPtr )
   {  
    free( stackPtr );

    return NULL;
   }

/*
Name: initializeStack
Process: returns NULL to initialize linked list
Function input/parameters: none
Function output/parameters: none
Function output/returned: NULL (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
StackNodeType *initializeStack()
   {
    return NULL;
   }

/*
Name: createStackNodeWithData
Process: allocates new linked list node with string data,
         returns pointer to new node
Function input/parameters: name (const char *)
Function output/parameters: created stack node (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc
*/
StackNodeType *createStackNodeWithData( const char *name )
   {
    StackNodeType *newNode = (StackNodeType *)malloc( sizeof( StackNodeType ) );

    privateCopyString( newNode->name, name );

    newNode->nextPtr = NULL;

    return newNode;
   }

/*
Name: duplicateStack
Process: creates new stack, copies data from given source
Function input/parameters: pointer to source stack (const StackNodeType *)
Function output/parameters: none
Function output/returned: new duplicated stack (StackNodeType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createStackNodeWithData
*/
StackNodeType *duplicateStack( const StackNodeType *srcPtr )
   {
    StackNodeType *newStackPtr = NULL;
    StackNodeType *srcWkgPtr, *destWkgPtr;

    if( srcPtr != NULL )
       {
        newStackPtr = createStackNodeWithData( srcPtr->name );

        destWkgPtr = newStackPtr;

        srcWkgPtr = srcPtr->nextPtr;

        while( srcWkgPtr != NULL )
           {
            destWkgPtr->nextPtr = createStackNodeWithData( srcWkgPtr->name );

            destWkgPtr = destWkgPtr->nextPtr;

            srcWkgPtr = srcWkgPtr->nextPtr;
           }   
       }

    return newStackPtr;
   }

/*
Name: peekTop
Process: returns value at the top of the stack,
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to source stack (StackNodeType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (char *)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekTop( StackNodeType *stackPtr, char *returnStr )
   {
    returnStr[ 0 ] = NULL_CHAR;

    if( stackPtr != NULL )
       {
        privateCopyString( returnStr, stackPtr->name );

        return true;
       }

    return false;
   }

/*
Name: pop
Process: removes and returns name at top of stack (bottom of linked list)
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to address of stack (StackNodeType **)
Function output/parameters: pointer to updated address of stack 
                                                             (StackNodeType **),
                            removed string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString, clearStackNode
*/
bool pop( StackNodeType **addressOfStackPtr, char *returnStr )
   {
    StackNodeType *tmpPtr = *addressOfStackPtr;

    returnStr[ 0 ] = NULL_CHAR;

    if( tmpPtr != NULL )
       {
        privateCopyString( returnStr, tmpPtr->name );

        *addressOfStackPtr = tmpPtr->nextPtr;

        tmpPtr = clearStackNode( tmpPtr );

        return true;
       }

    return false;
   }

/*
Name: push
Process: adds new data to the top of the stack (bottom of linked list)
Function input/parameters: pointer to address of stack (StackNodeType **),
                           new name/string (const char *)
Function output/parameters: pointer to updated address of stack 
                                                              (StackNodeType **)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createStackNodeWithData
*/
void push( StackNodeType **addressOfStackPtr, const char *newStr )
   {
    StackNodeType *newNode = createStackNodeWithData( newStr );

    newNode->nextPtr = *addressOfStackPtr;

    *addressOfStackPtr = newNode;
   }

/*
Name: stackIsEmpty
Process: returns true if stack is empty, false otherwise
Function input/parameters: pointer to stack (Stack *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool stackIsEmpty( StackNodeType *stackPtr )
   {
    return stackPtr == NULL;
   }

