#include "HashUtility.h"

const int MIN_HASH_CHARACTERS = 10;

/*
Name: addHashItem
Process: adds new item to hash table
Function input/parameters: pointer to hash table (HashTableType *), 
                           city name (const char *), 
                           city rank and population (int)
Function output/parameters: updated pointer to hash table (HashTableType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: generateHashIndex, addItemAsData
*/
void addHashItem( HashTableType *hashData, char *cityName, 
                                                    int cityRank, int cityPop )
  {
   // initialize functions/variables
      // initialize hash index variable
      int wkgIndex;
      
   // generate hash index using city name
   wkgIndex = generateHashIndex( *hashData, cityName );
   
   // add item as data using hash index
   addItemAsData( hashData->table[ wkgIndex ], cityName, cityRank, cityPop );
  }
  
/*
Name: clearHashTable
Process: verifies valid data,
         clears contents of hash table, and then hash table itself
Function input/parameters: pointer to hash table (HashTableType *)
Function output/parameters: none
Function output/returned: NULL
Device input/---: none
Device output/---: none
Dependencies: clearArray, free
*/
HashTableType *clearHashTable( HashTableType *hashData )
  {
   // initialize functions/variables
      // initialize hash index variable
      int wkgIndex;
      
   // check if hash is not empty
   if( hashData != NULL )
     {
        
      // traverse through hash table
      for( wkgIndex = 0; wkgIndex < hashData->capacity; wkgIndex++ )
        {
           
         // is the hash table has arrays
         if( hashData->table[ wkgIndex ] != NULL )
           {
              
            // clear the table at index
            clearArray(hashData->table[ wkgIndex ] );
           }
        }
      
      // clear the hash data struct
      free( hashData );
     }
   
   return NULL;
  }

/*
Name: findMean
Process: finds the mean of a set of integers
Function input/parameters: integer array (int *), size (int)
Function output/parameters: none
Function output/returned: mean of values (double)
Device input/---: none
Device output/---: none
Dependencies: none
*/
double findMean( int *array, int size )
  {
   // initialize fucntions/variables
      // initialize sum variable
      int sum = 0;
      // initialize mean index variable
      int meanIndex = 0;
      // initialize mean variable
      double mean = 0;
      
   //traverse through integer array
   for( meanIndex = 0; meanIndex < size; meanIndex++ )
      {
      
      // sum up the array values
      sum = sum + array[ meanIndex ];
      }
   
   // calculate the mean by dividing by size
   mean = ( double )sum / size;
   
   // return found mean value
   return mean;
  }

/*
Name: findMedian
Process: finds the median of a set of integers,
         assumes all input arrays will have an odd number of values
Function input/parameters: integer array (int *), size (int)
Function output/parameters: none
Function output/returned: median of values (int)
Device input/---: none
Device output/---: none
Dependencies: none
*/
int findMedian( int *array, int size )
  {

   // initialize functions/variables
      // initialize array index for traversal
      int arrIndex = 0;
      // initialize sort index for traversal
      int sortIndex = 0;
      // initialize median index variable
      int medianIndex;
      // initialize a temporary integer variable to swap
      int tempInt;
   
   // BUBBLE SORT
   // counter traverse array
   for( arrIndex = size - 1; arrIndex >= 0; arrIndex-- )
     {
        
      // traverse using seperate index forward
      for( sortIndex = 0; sortIndex < arrIndex; sortIndex++ )
        {
           
         // compare the first number the next element
         if( array[ sortIndex ] > array[ sortIndex + 1 ] )
           {
            
            // swap the values using temporary variable
            tempInt = array[ sortIndex ];
            array[ sortIndex ] = array[ sortIndex + 1 ];
            array[ sortIndex + 1 ] = tempInt;
           }
        }
     }
   
   // find the median index by dividing size by 2
   medianIndex = size / 2;
   
   // return median value
   return array[ medianIndex ];
  }

/*
Name: generateHashIndex
Process: finds hashed index for given data item,
         sums integer values of city name characters,
         if city name length is less than MINIMUM_HASH_CHARACTERS,
         repeats going over the city letters as needed to meet this minimum
Function input/parameters: hash table (const HashTableType),
                           city name (const char *)
Function output/parameters: none
Function output/returned: generated hash index (int)
Device input/---: none
Device output/---: none
Dependencies: privateGetStringLength
*/
int generateHashIndex( const HashTableType hashData, const char *cityName )
  {
   // initialize functions/variables
      // initialize hash index variable
      int sum = 0;
      // initialize name index variable
      int wkgIndex = 0;
      // intialize name length variable
      int nameLen = 0;
      
   // assign name length to the length city name
   nameLen = privateGetStringLength( cityName );
   
   // while nameIndex variable is less than city name or MHC
   while( wkgIndex < nameLen || wkgIndex < MIN_HASH_CHARACTERS )
     {
      
      // sum the cities name integers
      sum = sum + (int)cityName[ wkgIndex % nameLen ];
      // increment index
      wkgIndex = wkgIndex + 1;
     }
   
   // return the sum modulo capacity, generating index
   return sum % hashData.capacity;
  }

/*
Name: getHashDataFromFile
Process: uploads data from city file with unknown number of data sets,
         provides Boolean parameter to display data input success
Function input/parameters: file name (char *), capacity (int),
                           verbose flag (bool)
Function output/parameters: none
Function output/returned: pointer to newly created hash table 
                            (HashTableType *)
Device input/file: data from HD
Device output/---: none
Dependencies: openInputFile, initializeHashTable, readStringToDelimiterFromFile, 
              readStringToLineEndFromFile, checkForEndOfInputFile, 
              readCharacterFromFile, readIntegerFromFile, 
              addHashItem, printf, closeInputFile
*/

HashTableType *getHashDataFromFile( const char *fileName, 
                                                   int capacity, bool verbose )
  {
   // initialize variables 
      // initialize hash
      HashTableType *newHash;
      // initialize name string
      char cityStr[ STD_STR_LEN ];
      // intialize temp string
      char tempStr[ STD_STR_LEN ];
      // initialize number variables
      int population;
      // initialize number variables
      int rank;

  // check/open file
   if( openInputFile( fileName ) )
     {
      // create new heap
      newHash = initializeHashTable( capacity );
      if( verbose )
        {
         printf("\nBegin Loading Data From File . . .\n\n");
        }
      // eat the first line in input
      readStringToLineEndFromFile( tempStr );
      
      // read the prime integer
      rank = readIntegerFromFile();
      
      // while not at the end of file
      while( !checkForEndOfInputFile() )
        {
         // read initial charecter
         readCharacterFromFile();
         
         // read the city data
         readStringToDelimiterFromFile( COMMA, cityStr );
         
         // read the population data
         population = readIntegerFromFile();
         
         // check verbose flag
         if( verbose )
           {
            
            printf( "%3d) City name: %s, Population: %d\n", rank, cityStr, population );
           }
           
         // add collected data into hash
         addHashItem( newHash, cityStr, rank, population );
         // read the next rank
         rank = readIntegerFromFile();
        }
      // close the file
      closeInputFile( fileName );
      if( verbose )
        {
           
         printf( "\n\t\t\t. . . End Loading Data From File\n\n" );
        }
      
      // returned created hash data
      return newHash;
     }
     
   // otherwise return NULL
   return NULL;
  }

/*
Name: initializeHashTable
Process: dynamically creates new hash table with internal components
Function input/parameters: capacity (int)
Function output/parameters: none
Function output/returned: pointer to newly created hash table 
                            (HashTableType *)
Device input/file: data from HD
Device output/---: none
Dependencies: malloc w/sizeof, createArray
*/
HashTableType *initializeHashTable( int capacity )
  {
   // initialize functions/variables
      // initialize the new hash member
      HashTableType *newHash;
      // initialize hash index variable
      int wkgIndex;
      
   // allocate an array of pointer of city array types
   newHash = ( HashTableType * )malloc( sizeof( HashTableType ) );
   
   // allocate memory for the hash table
   newHash->table = ( CityArrayType ** )malloc( capacity*sizeof( CityArrayType * ) );
   
   // iterate accross the number of arrays
   for( wkgIndex = 0; wkgIndex < capacity; wkgIndex++ )
     {
        
      // create arrays at every index of hash table
      newHash->table[ wkgIndex ] = createArray( capacity );
     }
     
   // assign new hashes capacity to given capacity
   newHash->capacity = capacity;
   
   // reurn initialize hash table
   return newHash;
  }

/*
Name: removeHashItem
Process: acquires hashed item, returns value and true if found,
         otherwise, returns empty removed item and false
Function input/parameters: pointer to hash table (HashTableType *),
                           city name (const char *)
Function output/parameters: pointer to removed item (CityType *), or empty data
Function output/returned: Boolean result as specified (bool)
Device input/---: none
Device output/---: none
Dependencies: generateHashIndex, removeItem
*/
bool removeHashItem( HashTableType *hashData, 
                                  CityType *removedItem, const char *cityName )
  {
   // initialize functions/variables
      // initialize hash index
      int wkgIndex;
      
   // generate a hash index with city name
   wkgIndex = generateHashIndex( *hashData, cityName );
   
   // remove the item and return boolean success
   return removeItem( hashData->table[wkgIndex], removedItem, cityName );
  }

/*
Name: searchHashTable
Process: searches for value in table, returns item if found and true,
         returns empty found item and false if not
Function input/parameters: hash table (const HashTableType),
                           city name (const char *)
Function output/parameters: found item (CityType *)
Function output/returned: Boolean result as specified (bool)
Device input/---: none
Device output/---: none
Dependencies: generateHashIndex, search, setCityFromStruct, setCityDataToEmpty
*/
bool searchHashTable( const HashTableType hashData, 
                                    CityType *foundItem, const char *cityName )
  {
   // initialize functions/variables
      // initialize index
      int wkgIndex;
      // initialize found index
      int foundIndex;
   
   // generate hash index with city name
   wkgIndex = generateHashIndex( hashData, cityName );
   
   // search the hash table with new hash index and store in found index
   foundIndex = search( hashData.table[ wkgIndex ], cityName );
   
   // if there a found index
   if( foundIndex != NOT_FOUND )
     {
        
      // set city with found index
      setCityFromStruct( foundItem, hashData.table[ wkgIndex ]->array[ foundIndex ] );
      return true;
     }
     
   // otherwise, set the city to empty
   setCityDataToEmpty( foundItem );
   return false;
  }

/*
Name: showHashTableStatus
Process: displays item counts from each array data element in the hash table,
         displays highest and lowest number of items in an element,
         displays range between highest and lowest,
         displays the mean and median,
         and displays the total number of nodes found,
         all in a formatted structure
Function input/parameters: hashTable (const HashTableType)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: hash data status displayed as specified
Dependencies: malloc w/sizeof, printf, findMean, findMedian, free, printf
*/
void showHashTableStatus( const HashTableType hashData )
  {
   // initialize functions/variables
      // initialize hash index
      int wkgIndex;
      // initialize the number of equals variable to print in the end
      int numEquals;
      // initialize array for integers
      int *sizeArray;
      //initialize median variable
      int median;
      // initialize max items variable
      int maxItems;
      // initialize min items variable
      int minItems;
      // initialize range variable
      int range;
      // initialize mean variable
      double mean;
      // initialize total variable and set to 0
      int totalArraySizes = 0;
   
   // allocate memory for integer array
   sizeArray = ( int * )malloc( hashData.capacity * sizeof( int ) );
   
   printf( "\nHash Table Status:\n" );
   printf( "\nNum Items :" );
   
   // traverse hash table 
   for( wkgIndex = 0; wkgIndex < hashData.capacity; wkgIndex++ )
     {
        
      // fill the array with each array sizes
      sizeArray[ wkgIndex ] = hashData.table[ wkgIndex ]->size;
      
      // print each size
      printf( "%4d", sizeArray[ wkgIndex ] );
      
      // total up all of the array sizes
      totalArraySizes = totalArraySizes + sizeArray[ wkgIndex ];
     }
   
   // formatting print
   printf( "\n\t   " );
   
   // display the sectioning
   for( wkgIndex = 0; wkgIndex < hashData.capacity; wkgIndex++ )
     {
        
      printf( " ---" );
     }
     
   
   printf("\nHash Index:");
   for( wkgIndex = 0; wkgIndex < hashData.capacity; wkgIndex++ )
     {
        
      printf( "%4d", wkgIndex );
     }
   
   // find the median
   median = findMedian( sizeArray, hashData.capacity );
   
   // find the max item ( last element in sorted array )
   maxItems = sizeArray[ hashData.capacity - 1 ];
   
   // find the minimum item ( first item in sorted array )
   minItems = sizeArray[0];
   
   // find the range
   range = maxItems - minItems;
   
   // find the mean
   mean = findMean( sizeArray, hashData.capacity );
   
   // display max item
   printf( "\n\nMax items in one element    :    %d", maxItems );
   
   // display min item
   printf( "\nMin num items in one element:    %d", minItems );
   
   // display range
   printf( "\nRange (min to max)          :    %d", range );
   
   // display mean num items
   printf( "\nMean num items              : %.2f", mean );
   
   // desplay the median node
   printf( "\nMedian node num             :    %d", median );
   
   // display all items processed
   printf( "\nTotal items processed       :    %d\n", totalArraySizes );
   
   // find how many equals need to be printed (13 is the initial)
   numEquals = hashData.capacity * 4 + 13;
   
   // print equal line
   for( wkgIndex = 0; wkgIndex < numEquals; wkgIndex++)
      {
         
      printf( "=" );
      }
      
   printf( "\n" );
   
   // free integer array
   if( sizeArray != NULL )
     {
        
      free( sizeArray );
     }
  }