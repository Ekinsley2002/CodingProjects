#include "AVL_Tree_utility.h"
/*
Name: clearTree
Process: recursively removes all nodes from tree and returns memory to OS,
         uses post order traversal strategy
Function input/parameters: pointer to root/ working pointer (AvlTreeNodType *)
Function output/parameters: none
Function output/returned: NULL
Device input/---: none
Device output/---: none
Dependencies: free, clearTree (recursively)
*/
AvlTreeNodeType *clearTree( AvlTreeNodeType *wkgPtr )
  {
   // if working pointer is not null
   if( wkgPtr != NULL ) 
     {
      // recurse through left side and free
      clearTree( wkgPtr->leftChildPtr );
      // recurse through right side and free
      clearTree( wkgPtr->rightChildPtr );
      // free the current node      
      free( wkgPtr );
     }

   return NULL;
  }

/*
Name: copyTree
Process: creates duplicate copy of given tree, allocates all new nodes,
         returns pointer to root of new tree or NULL if original tree was empty,
         uses pre order traversal strategy
Function input/parameters: tree root/working pointer (AvlTreeNodeType *)
Function output/parameters: none
Function output/returned: tree root of copied tree
                          or NULL as specified (AvlTreeNodeType *)
Device input/---: none
Device output/---: none
Dependencies: createNodeFromNode, copyTree (recursively)
*/
AvlTreeNodeType *copyTree( AvlTreeNodeType *wkgPtr )
  {
   // initialize functions/variables
      // initialize new node variable
      AvlTreeNodeType *newNode;
      
   // test whether the wkg pointer is empty
   if( wkgPtr != NULL ) 
     {
      // copy the current nodes data
      newNode = createNodeFromNode( *wkgPtr );

      // copy the left side of the tree
      newNode->leftChildPtr = copyTree( wkgPtr->leftChildPtr );

      // copy the right side of the tree
      newNode->rightChildPtr = copyTree( wkgPtr->rightChildPtr );

      // return copied node
      return newNode;
     }

   // return copied node
   return NULL;
  }

/*
Name: createNodeFromData
Process: captures data from individual data items, 
         dynamically creates new node,
         copies data, and returns pointer to new node         
Function input/parameters: university and city (const char *), rank (int)
Function output/parameters: none
Function output/returned: pointer to new node as specified (AvlTreeNodeType *)
Device input/---: none
Device output/---: none
Dependencies: malloc, privateCopyString
*/
AvlTreeNodeType *createNodeFromData( const char *univName, 
                                           const char *univCity, int univRank )
  {
   // initialize functions/variables
      // initialize functions/variables
      AvlTreeNodeType *newNode;
   
   // allocate memory for new node
   newNode = ( AvlTreeNodeType * )malloc( sizeof( AvlTreeNodeType ) );
   
   // test to see if the allocation was successful
   if( newNode != NULL ) 
     {
      // copy the university name
      privateCopyString( newNode->name, univName );
   
      // copy the city name
      privateCopyString( newNode->city, univCity );
   
      // copy the rank
      newNode->rank = univRank;
    
      // initialize left and right child pointers to NULL
      newNode->leftChildPtr = NULL;
      newNode->rightChildPtr = NULL;
      
      // return new node
      return newNode;
     }
   
   // otherwise return null
   return NULL;
  }

/*
Name: createNodeFromNode
Process: captures data from source node pointer, dynamically creates new node,
         copies data, and returns pointer to new node         
Function input/parameters: node to be copied (const AvlTreeNodeType)
Function output/parameters: none
Function output/returned: pointer to new node as specified (AvlTreeNodeType *)
Device input/---: none
Device output/---: none
Dependencies: createNodeFromData
*/
AvlTreeNodeType *createNodeFromNode( const AvlTreeNodeType source )
  {
   // create a new node and return pointer
   return createNodeFromData( source.name, source.city, source.rank );
  }

/*
Name: displayInOrder
Process: recursively displays numbered tree items using in order traversal
Function input/parameters: working pointer for recursion 
                                                       (const AvlTreeNodeType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayInOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayInOrder( const AvlTreeNodeType *univPtr, int *number )
  {
   // initialize functions/variables
      // initialize temporary string variable
      char tempStr[ MAX_STR_LEN ];
      
   // make sure the pointer isn't empty
   if( univPtr != NULL )
     {
      // dipslay left side of the tree
      displayInOrder( univPtr->leftChildPtr, number );

      // format the current data to print
      universityDataToString( tempStr, *univPtr ); 
      // print the formated string
      printf( "%5d) %s", ( *number )++, tempStr );

      // display right side of the tree
      displayInOrder( univPtr->rightChildPtr, number );
     }
  }
/*
Name: displayPostOrder
Process: recursively displays numbered tree items using post order traversal
Function input/parameters: working pointer for recursion 
                                                       (const AvlTreeNodeType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayPostOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayPostOrder( const AvlTreeNodeType *univPtr, int *number )
  {
   // initialize functions/variables
      // initialize tempString variable
      char tempStr[ MAX_STR_LEN ];
   
   // check to see if the tree is empty
   if( univPtr != NULL ) 
     {
      // recurse left side of tree
      displayPostOrder( univPtr->leftChildPtr, number );

      // recurse right side of tree
      displayPostOrder( univPtr->rightChildPtr, number );
      
      // format the data to string
      universityDataToString( tempStr, *univPtr ); 
      
      // print data in format
      printf( "%5d) %s", ( *number )++, tempStr );
     }
  }
/*
Name: displayPreOrder
Process: recursively displays numbered tree items using pre order traversal
Function input/parameters: working pointer for recursion 
                                                       (const AvlTreeNodeType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayPreOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayPreOrder( const AvlTreeNodeType *univPtr, int *number )
  {
   // initialize functions/variables
      // initialize tempString variable
      char tempStr[ MAX_STR_LEN ];
      
   if( univPtr != NULL ) 
     {
      // format current node data to string
      universityDataToString( tempStr, *univPtr ); 
      
      // print data in format
      printf( "%5d) %s", ( *number )++, tempStr );
      
      // recurse right child
      displayPreOrder( univPtr->leftChildPtr, number );

      // recurse left child
      displayPreOrder( univPtr->rightChildPtr, number );
     }
  }

/*
Name: displaySelectionInOrder
Process: recursively displays numbered selected items in tree using 
         in order traversal, items are specified by provided starting segment 
         of university name string
Function input/parameters: working pointer for recursion 
                                                       (const AvlTreeNodeType *),
                           name segment for searching (const char *)
                           pointer to display number (int *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: privateCompareStringSegments, universityDataToString, printf,
              displaySelectionInOrder (recursively)
*/
void displaySelectionInOrder( AvlTreeNodeType *univPtr, 
                                         const char *nameSegment, int *number )
  {
   // initialize functions/variables
      // initialize temporary string variable
      char tempStr[ MAX_STR_LEN ];
      
   // check to see if tree is empty
   if( univPtr != NULL ) 
     {
      // recurse left side of tree
      displaySelectionInOrder( univPtr->leftChildPtr, nameSegment, number );

      // check to see if the current node matches name segment
      if( privateCompareStringSegments( nameSegment, univPtr->name ) == 0 )
        {
         // format data to string
         universityDataToString( tempStr, *univPtr );
         // print formatted string
         printf( "%5d) %s", ( *number )++, tempStr );
        }

      // recurse right side of tree
      displaySelectionInOrder( univPtr->rightChildPtr, nameSegment, number );
     }
  }

/*
Name: findBalanceFactor
Process: finds balance factor by subtracting
         height differences between left and right subtrees,
         returns if found, returns zero if pointer is NULL
Function input/parameters: pointer to current tree location (TreeNodeType *)
Function output/parameters: none
Function output/returned: difference between two subtree heights (int)
Device input/---: none
Device output/---: none
Dependencies: findTreeHeight
*/
int findBalanceFactor( AvlTreeNodeType *wkgPtr )
  {
   // check if tree is empty
   if( wkgPtr != NULL )
     {
      // return balance factor
      return findTreeHeight( wkgPtr->leftChildPtr )
                                     - findTreeHeight( wkgPtr->rightChildPtr );
     }
   // if pointer is NULL return 0
   return 0;
  }
/*
Name: findTreeHeight
Process: recursively finds maximum tree height from current node 
         to bottom of tree
Function input/parameters: pointer to current tree location (AvlTreeNodeType *)
Function output/parameters: none
Function output/returned: -1 if empty tree, 0 if no subtrees,
                          max height of subtrees otherwise
Device input/---: none
Device output/---: none
Dependencies: privateFindMax, findTreeHeight (recursively)
*/
int findTreeHeight( AvlTreeNodeType *wkgPtr )
  {
   // initialize functions/variables
      // initialize left tree height variable
      int leftTreeHeight;
      // initialize right tree height variable
      int rightTreeHeight;

    // check if tree is not empty
    if( wkgPtr != NULL )
       {
        // recuse left tree and assign to left tree height
        leftTreeHeight = findTreeHeight( wkgPtr->leftChildPtr );

        // recuse right tree and assign to right tree height
        rightTreeHeight = findTreeHeight( wkgPtr->rightChildPtr );

        // return 1 + maxHeight ( 1 is for current node )
        return 1 + privateFindMax( leftTreeHeight, rightTreeHeight );
       }

    // return -1
    return -1;
  }

/*
Name: getDataFromFile
Process: uploads data from file with unknown number of data sets,
         has internal Boolean to display data input success
Function input/parameters: file name (const char *)
Function output/parameters: none
Function output/returned: pointer to BST holding data (AvlTreeNodeType *)
Device input/---: data from HD
Device output/monitor: if internal Boolean set, displays uploaded values
Dependencies: openInputFile, readStringToLineEndFromFile, 
              checkForEndOfInputFile, readIntegerFromFile,
              readStringToDelimiterFromFile, readCharacterFromFile, 
              insertRawData, printf, closeInputFile
*/
AvlTreeNodeType *getDataFromFile( const char *fileName )
  {
   // initialize functions/variables
      // initialize the temporary string
      char tempStr[ STD_STR_LEN ];
      // initialize rank variable
      int rank;
      // initialize university name variable
      char university[ STD_STR_LEN ];
      // initialize town name variable
      char town[ STD_STR_LEN ];
      // initialize starting data index
      int dataIndex = 1;
      // initialize verbose flag variable
      bool verboseFlag = true;
      // initialize new node as NULL
      AvlTreeNodeType *newNode = NULL;
      
   // open input file
   if( openInputFile( fileName ) )
     {
      // print begin loading data from file
      printf( "\nBegin Loading Data From File . . ." );
      
      // input top line (ignore)
      readStringToLineEndFromFile( tempStr );
      
      // assign rank
      rank = readIntegerFromFile();
      
      // while checkForEndOfInputFile is false
      while( !checkForEndOfInputFile() )
        {
         // "eat" the next comma
         readCharacterFromFile();
          
         // assign University
         readStringToDelimiterFromFile( COMMA, university );
         
         // assign town
         readStringToDelimiterFromFile( COMMA, town );
         
           
         // insert data into the tree
         newNode = insertRawData( newNode, university, town, rank );
         
         // if verbose flag is true
         if( verboseFlag )
           {
            // print information
            printf( "\n\t%2d) Name: %s, City: %s, Rank: %d", dataIndex,
                                                      university, town, rank );
           }
         
         // increment dataIndex
         dataIndex = dataIndex + 1;
         
         // assign rank
         rank = readIntegerFromFile();
        }
      // end of while loop
      
      // print end loading data from file
      printf( "\n\t\t\t\t\t. . . End Loading Data From File\n" );
      
      // close file
      closeInputFile( fileName );
      // end of if statement
      
      // return new node
      return newNode;
     }
   
   // if the file doesn't open
   // return NULL
   return NULL;
  }

/*
Name: initializeTree
Process: returns NULL to set tree to empty
Function input/parameters: none
Function output/parameters: none
Function output/returned: NULL
Device input/---: none
Device output/---: none
Dependencies: none
*/
AvlTreeNodeType *initializeTree()
  {
   return NULL;
  }

/*
Name: insertNodeData
Process: recursively finds location to insert node, inserts node,
         then follows recursion back up tree to implement balancing,
         does not allow duplicate entries,
         uses "look up" strategy for linking nodes
Function input/parameters: pointer to current tree location (AvlTreeNodeType *),
                           university node (const AvlTreeNodeType *)
Function output/parameters: none
Function output/returned: pointer to calling function/tree node above
                          where function is called
Device input/---: none
Device output/monitor: actions displayed as function progresses
                       ("Identified: <direction> <direction> Case")
Dependencies: insertNodeData
*/
AvlTreeNodeType *insertNodeData( AvlTreeNodeType *wkgPtr, 
                                                const AvlTreeNodeType nodePtr )
  {
   // call insertRawData with given data
   return insertRawData( wkgPtr, nodePtr.name, nodePtr.city, nodePtr.rank );
  }

/*
Name: insertRawData
Process: recursively finds location to insert node, inserts node,
         then follows recursion back up tree to implement balancing,
         does not allow duplicate entries,
         uses "look up" strategy for linking nodes
Function input/parameters: pointer to current tree location (AvlTreeNodeType *),
                           university and city names (const char *),
                           university ranking (int)
Function output/parameters: none
Function output/returned: pointer to calling function/tree node above
                          where function is called
Device input/---: none
Device output/monitor: actions displayed as function progresses
                       ("Identified: <direction> <direction> Case")
Dependencies: createNodeFromData, privateCompareStrings, findBalanceFactor,
              insertRawData (recursively), printf, rotateLeft, rotateRight,
              privateDisplayChars
*/
AvlTreeNodeType *insertRawData( AvlTreeNodeType *wkgPtr, 
                         const char *univName, const char *univCity, int rank )
  {
   // initialize functions/variables
      // initialize comparison variable
      int compareResult;
      // initilaize tree height display variable
      int treeHeightDisp;
      // initialize balance factor variable
      int balanceFactor;
      
   // if the working pointer is not NULL
   if( wkgPtr != NULL )
     {
      // compare the given name to current pointer
      compareResult = privateCompareStrings( univName, wkgPtr->name );
       
      // check if the name is less than current node
      if( compareResult < 0 )
        {
         wkgPtr->leftChildPtr = insertRawData( wkgPtr->leftChildPtr,
                                                    univName, univCity, rank );
        }
         
      // check if the name is more than current node
      else if( compareResult > 0 )
        {
         wkgPtr->rightChildPtr = insertRawData( wkgPtr->rightChildPtr,
                                                    univName, univCity, rank );
        }
      
      // otherwise data matches, return node
      else
        {
         return wkgPtr;
        }
        
      
      // find balance factor
      balanceFactor = findBalanceFactor( wkgPtr );
      // set tree height display for height
      treeHeightDisp = findTreeHeight( wkgPtr );
      
      // test first left case
      if( balanceFactor > 1 )
        {
         // test left left case
         if( privateCompareStrings( univName, wkgPtr->leftChildPtr->name ) < 0)
           {
            privateDisplayChars( treeHeightDisp, SPACE );
            printf( "\n\tIdentified: Left Left Case" );
            return rotateRight( wkgPtr );
           }
         // otherwise, left right case
         else
           {
            privateDisplayChars( treeHeightDisp, SPACE );
            printf( "\n\tIdentified: Left Right Case" );
            wkgPtr->leftChildPtr = rotateLeft( wkgPtr->leftChildPtr );
            return rotateRight( wkgPtr );
           }
        }
        
      // test first right case
      else if( balanceFactor < -1 )
        {
         // test right right case
         if( privateCompareStrings( univName,
                                             wkgPtr->rightChildPtr->name ) > 0 )
           {
            privateDisplayChars( treeHeightDisp, SPACE );
            printf( "\n\tIdentified: Right Right Case" );
            return rotateLeft( wkgPtr );
           }
         // otherwise, right left case
         else
           {
            privateDisplayChars( treeHeightDisp, SPACE );
            printf( "\n\tIdentified: Right Left Case" );
            wkgPtr->rightChildPtr = rotateRight( wkgPtr->rightChildPtr );
            return rotateLeft( wkgPtr );
           }
        }
     }
   // if tree is empty, create first node
   else
     {
      // create first node
      return createNodeFromData( univName, univCity, rank );
     }

   return wkgPtr;
  }

/*
Name: isEmpty
Process: reports if tree is empty
Function input/parameters: pointer to current root node (AvlTreeNodeType *)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool isEmpty( AvlTreeNodeType *rootPtr )
  {
   // test if the root pointer is NULL
   return ( rootPtr == NULL );
  }

/*
Name: rotateLeft
Process: conducts left rotation by manipulation of given pointer,
         displays "- Rotating Left" with an endline
Function input/parameters: pointer to given subtree to rotate
Function output/parameters: none
Function output/returned: pointer to calling function/tree node above
                          where function is called
Device input/---: none
Device output/monitor: rotation action displayed ("- Rotating Left")
                       indented by current height of tree + 2
Dependencies: printf, findTreeHeight, and privateDisplayChars for display
*/
AvlTreeNodeType *rotateLeft( AvlTreeNodeType *oldParentPtr )
  {
   // initilaize functions/variables
      // initilaize tree height variable
      int treeHeight;
      // initilaize new root pointer variable
      AvlTreeNodeType *newRootPtr;
      
   // assign tree height variable + 2
   treeHeight = findTreeHeight( oldParentPtr ) + 2;
   // assign new root pointer to old right child
   newRootPtr = oldParentPtr->rightChildPtr;
   // assign old right child too new left child
   oldParentPtr->rightChildPtr = newRootPtr->leftChildPtr;
   // assign new root left child to old parent
   newRootPtr->leftChildPtr = oldParentPtr;
   // format based on tree height
   privateDisplayChars(treeHeight, SPACE);
   // print rotating left
   printf( "\n\t- Rotating Left" );
   // return new root
   return newRootPtr;
  }

/*
Name: rotateRight
Process: conducts right rotation by manipulation of given pointer,
         displays "- Rotating Right" with an endline
Function input/parameters: pointer to given subtree to rotate
Function output/parameters: none
Function output/returned: pointer to calling function/tree node above
                          where function is called
Device input/---: none
Device output/monitor: rotation action displayed  ("- Rotating Right")
                       indented by current height of tree + 2
Dependencies: printf, findTreeHeight, and privateDisplayChars for display
*/
AvlTreeNodeType *rotateRight( AvlTreeNodeType *oldParentPtr )
  {
   // initialize functions/variables
      // initilaize tree height variable
      int treeHeight;
      // initilaize new root pointer variable
      AvlTreeNodeType *newRootPtr;
      
   // assign tree height variable + 2
   treeHeight = findTreeHeight( oldParentPtr ) + 2;
   // assign new root pointer to left child pointer
   newRootPtr = oldParentPtr->leftChildPtr;
   // assign old left child to new right child
   oldParentPtr->leftChildPtr = newRootPtr->rightChildPtr;
   // assign new root pointer right child to old parent 
   newRootPtr->rightChildPtr = oldParentPtr;
   // format spaces based on the tree height
   privateDisplayChars( treeHeight, SPACE );
   // print rotate right
   printf( "\n\t- Rotating Right" );
   // return new root pointer
   return newRootPtr;
  }

/*
Name: search
Process: recursively searches tree for specified data using university name key
Function input/parameters: pointer to working subtree (AvlTreeNodeType *),
                           university name (const char *)
Function output/parameters: none
Function output/returned: pointer to found node (AvlTreeNodeType *)
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, search (recursively)
*/
AvlTreeNodeType *search( AvlTreeNodeType *wkgPtr, const char *univName )
  {
   // initialize function/variables
      // initialize compare result
      int compareResult;
      
   // check if the tree is empty
   if( wkgPtr != NULL )
     {
      // compare the name of current node to the toFind variable
      compareResult = privateCompareStringSegments( univName, wkgPtr->name );
      
      // test if the name is less than node
      if( compareResult < 0 )
        {
         // recurse left, return
         return search( wkgPtr->leftChildPtr, univName );
        }
        
      // compare the name of current node to the toFind variable
      else if( compareResult > 0 )
        {
         // recurse right, return
         return search( wkgPtr->rightChildPtr, univName );
        }
        
      // otherwise, duplicated name
      else
        {
         // return current node
         return wkgPtr;
        }
     }

   // return NULL
   return NULL;
  }

/*
Name: universityDataToString
Process: sets data from node to formatted string
Function input/parameters: node with data to be set (const AvlTreeNodeType)
Function output/parameters: string array with result (char *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: sprintf
*/
void universityDataToString( char *destStr, 
                                         const AvlTreeNodeType universityData )
  {
   // format the the given data to the specified string format
   sprintf( destStr, "Name: %s, City: %s, Rank: %d\n", universityData.name,
                                   universityData.city, universityData.rank );
  }


////////////////////////////////////////////////////////////////////////////////
// No student coding below this point
////////////////////////////////////////////////////////////////////////////////      

/*
Name: displayAtTreeLevel
Process: displays one horizontal "level" of a tree using text graphics
         with appropriate spacing and appropriate number of nodes
Function input/parameters: recursive working node (AvlTreeNodeType *),
                           node height, display level, working level (int),
                           row start flag (bool)
Function output/parameters: none
Function output/returned: updated row start flag (bool *)
Device input/---: none
Device output/---: none
Dependencies: displayValue, displayEmptyNodeSpaces
*/
void displayAtTreeLevel( AvlTreeNodeType *workingNode, int nodeHeight, 
                                  int displayLevel, int workingLevel, 
                                                            bool *rowStartFlag )
   {
    char charOut = workingNode->name[ 0 ];
  
    if( workingLevel == displayLevel )
       {
        displayValue( charOut, nodeHeight, workingLevel, rowStartFlag );
       }
  
    else
       {
        if( workingNode->leftChildPtr != NULL )
           {
            displayAtTreeLevel( workingNode->leftChildPtr, nodeHeight,
                                 displayLevel, workingLevel + 1, rowStartFlag );
           }
  
        else
           {
            displayEmptyNodeSpaces( nodeHeight, displayLevel, 
                                               workingLevel + 1, rowStartFlag );
           }
      
        if( workingNode->rightChildPtr != NULL )
           {
            displayAtTreeLevel( workingNode->rightChildPtr, nodeHeight,
                                 displayLevel, workingLevel + 1, rowStartFlag );
           }

        else
           {
            displayEmptyNodeSpaces( nodeHeight, displayLevel, 
                                               workingLevel + 1, rowStartFlag );
           }              
       }
   }

/*
Name: displayDivider
Process: displays divider of correct length for tree
         using either THICK_DIVIDER or THIN_DIVIDER 
         depending on the control code,
         adds one endline to thick divider, two to thin for spacing
Function input/parameters: number of characters (int), 
                           character to be displayed (char)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/---: characters displayed as specified
Dependencies: printf
*/
void displayDivider( AvlTreeNodeType *rootPtr, char dividerChar )
   {
    int treeHeight = findTreeHeight( rootPtr );
    int numChars = privateToPower( 2, treeHeight + 2 );

    privateDisplayChars( numChars, dividerChar );

    if( dividerChar == THIN_DIVIDER )
       {
        printf( "\n" );
       }

    printf( "\n" );
   }

/*
Name: displayEmptyNodeSpaces
Process: displays the appropriate number of dashes for a given level
         for null nodes, can display either dashes or 'B's
Function input/parameters: node height, display level, working level (int)
                           pointer to row start flag (bool *)
Function output/parameters: none
Function output/returned: updated row start flag (bool *)
Device input/---: none
Device output/---: characters displayed as specified
Dependencies: privateToPower, displayValue
*/
void displayEmptyNodeSpaces( int nodeHeight, 
                        int displayLevel, int workingLevel, bool *rowStartFlag )
   {
    int nodesToDisplay = privateToPower( 2, displayLevel - workingLevel ); 
    char charOut = SPACE;
  
    if( displayLevel == workingLevel )
       {
        charOut = DASH;
       }
  
    while( nodesToDisplay > 0 )
       {
        displayValue( charOut, nodeHeight, displayLevel, rowStartFlag );
      
        nodesToDisplay--;
       }
   }

/*
Name: displayTreeStructure
Process: repeatedly calls other function to display 
         the structure of an RB tree, can display either dashes or 'B's,
         displays error message if empty tree
Function input/parameters: tree root pointer (AvlTreeNodeType *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/---: characters displayed as specified
Dependencies: findTreeHeight, displayAtTreeLevel, printf
*/
void displayTreeStructure( AvlTreeNodeType *avlTreeRoot )
   {
    int displayLevel, nodeHeight = findTreeHeight( avlTreeRoot ) + 2;
    int workingLevel = 1;
    bool rowStartFlag;

    if( avlTreeRoot != NULL )
       {
        for( displayLevel = 1; displayLevel <= nodeHeight; displayLevel++ )
           {
            rowStartFlag = true;
          
            displayAtTreeLevel( avlTreeRoot, nodeHeight, 
                                    displayLevel, workingLevel, &rowStartFlag );
          
            printf( "\n" );
           }
       }
  
    else
       {
        printf( "\nEmpty Tree - No Display" );
       }
   }

/*
Name: displayValue
Process: displays a tree character value or color letter (R/B)
         after a calculated set of leading spaces
Function input/parameters: character data (char), 
                           node height, working level (int),
                           pointer to row start flag (bool *)
Function output/parameters: updated row start flag (bool *)
Function output/returned: none
Device input/---: none
Device output/---: character displayed as specified
Dependencies: privateToPower, displayChars, printf
*/
void displayValue( char data, int nodeHeight, 
                                          int workingLevel, bool *rowStartFlag )
   {
    int leadingSpaces;
  
    if( *rowStartFlag )
       {
        leadingSpaces = privateToPower( 2, nodeHeight - workingLevel );

        *rowStartFlag = false;
       }
  
    else
       {
        leadingSpaces = privateToPower( 2, nodeHeight - workingLevel + 1 ) - 1;
       }

    privateDisplayChars( leadingSpaces, SPACE );
  
    printf( "%c", data );         
   }

