#ifndef SET_UTILITIES_H
#define SET_UTILITIES_H

// headers/libraries
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>
#include "StandardConstants.h"
#include "File_Input_Utility.h"
#include "StudentUtility.h"

typedef struct SetStruct
   {
    StudentType *array;

    int capacity;

    int size;
   } SetType;

// prototypes

/*
Name: addItemAsData
Process: adds item as student data to set, does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           student name (const char *),
                           student ID number (int),
                           student gpa (double),
                           student gender (char)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: isInSet, deepCopyStudentData
*/
bool addItemAsData( SetType *setData, const char *inName, int inId,
                                                  char inGender, double inGpa );

/*
Name: addItemAsStruct
Process: adds item as a struct to set, does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           new item (StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: addItemAsData
Note: One line of code
*/
bool addItemAsStruct( SetType *setData, const StudentType newValue );

/*
Name: clearSetData
Process: clears set along with internal array, returns NULL
Function Input/Parameters: pointer to set data (SetType *)
Function Output/Parameters: none
Function Output/Returned: NULL (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: free
*/
SetType *clearSetData( SetType *toBeCleared );

/*
Name: copySet
Process: copies all data of one set into other
Function Input/Parameters: source set (const SetType)
Function Output/Parameters: pointer to destination set (SetType *)
Function Output/Returned: none
Device Input/---: none
Device Output/---: none
Dependencies: deepCopyStudentData
*/
void copySet( SetType *dest, const SetType source );

/*
Name: createEmptySet
Process: creates new SetType along with array, and sets capacity and size
Function Input/Parameters: array capacity (int)
Function Output/Parameters: none
Function Output/Returned: pointer to newly created SetType (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: malloc
*/
SetType *createEmptySet( int capacitySet );

/*
Name: createSetFromData
Process: gets file name, 
         uploads data from specified file to locally created set, 
         randomly assigns specified number of unique values from local set 
         to output set, clears local set, returns output set         
Function Input/Parameters: number of random items to create (int)
Function Output/Parameters: none
Function Output/Returned: pointer to created set data (SetType *)
Device Input/HD: data uploaded as specified, file name input from keyboard
Device Output/monitor: prompt for file name
Dependencies: openInputFile, readStringToDelimiterFromFile, readIntegerFromFile,
              readCharacterFromFile, readDoubleFromFile, createSetData, 
              addItemAsData, addItemAsStruct, closeInputFile, getRandBetween,
              clearSetData
*/
SetType *createSetFromData( int numItemsToCreate, bool randomSet );

/*
Name: deleteItem
Process: searches for item, deletes if found,
         moves array data down by one from above the removed value
         test loop must stop as soon as item is found (if it is found),
         updates size as needed,
         returns true if successful, false otherwise         
Function Input/Parameters: pointer to set data (SetType *), 
                           item to delete (const StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of operation (bool)
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings, deepCopyStudentData
*/
bool deleteItem( SetType *setData, const StudentType itemToDelete );

/*
Name: displaySet
Process: displays series of set values, or displays "Empty Set" if no values
Function Input/Parameters: name of set array (const char *),
                           set data (const SetType)
Function Output/Parameters: none
Function Output/Returned: none
Device Input/---: none
Device Output/monitor: data displayed as specified
Dependencies: printf
Note: Must use printf control characters for data alignment
*/
void displaySet( const char *setName, const SetType setData );

/*
Name: isInSet
Process: searches for given student data in set,
         if found, returns true, otherwise returns false,
         must return found result immediately upon locating value
Function Input/Parameters: set (const SetType), search value (const StudentType)
Function Output/Parameters: none
Function Output/Returned: Boolean result of test, as specified
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings
*/
bool isInSet( const SetType testSet, const StudentType testData );

/*
Name: privateCompareStrings
Process: compares strings from left to right, letter by letter,
         if left string greater than right string, returns greater than zero,
         if left string less than right string, returns less than zero,
         if all string characters are equal and the string lengths are the same,
         returns zero, 
         otherwise returns left to right difference in string lengths
Function input/parameters: left and right strings (char *)
Function output/parameters: none
Function output/returned: returned value as specified (int)
Device input/---: none
Device output/---: none
Dependencies: privateGetStringLength
Note: no literal constants other than zero (e.g., -1, 1, etc.) 
      may be returned from this function
*/
int privateCompareStrings( const char *leftStr, const char *rightStr );

/*
Name: privateGetRandBetween
Process: generates and returns a random value
         between two given values, inclusive
Function Input/Parameters: low, high limits (int)
Function Output/Parameters: none
Function Output/Returned: random value as specified
Device Input/---: none
Device Output/---: none
Dependencies: rand
*/
int privateGetRandBetween( int lowVal, int highVal );

/*
Name: privateGetStringLength
Process: returns length of c-style string
Function input/parameters: c-style string (char *)
Function output/parameters: none
Function output/returned: length of string (int)
Device input/---: none
Device output/---: none
Dependencies: none
*/
int privateGetStringLength( const char *str );

/*
Name: runBubbleSort
Process: sorts Set values using bubble sort algorithm with name as key
Function input/parameters: pointer to set data (SetType *)
Function output/parameters: updated pointer to set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, swapValues
Note: must use two for loops
*/
void runBubbleSort( SetType *setData );

/*
Name: runInsertionSort
Process: sorts set values using insertion sort algorithm with name as key
Function input/parameters: pointer to set data (SetType *)
Function output/parameters: updated pointer to set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings
Note: swap function may not be used in this function
*/
void runInsertionSort( SetType *setData );

/*
Name: runSelectionSort
Process: sorts set values using selection sort algorithm with name as key
Function input/parameters: pointer to set data (SetType *)
Function output/parameters: updated pointer to set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, swapValues
*/
void runSelectionSort( SetType *setData );

/*
Name: swapValues
Process: swaps data between two set data quantities (StudentTypes)
Function input/parameters: pointers to two StudentType values (StudentType *)
Function output/parameters: pointers to updated StudentType values 
                                                                 (StudentType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: deepCopyStudentData
*/
void swapValues( StudentType *one, StudentType *other );


#endif     // SET_UTILITIES_H


