// Precompiler directives /////////////////////////////////////////////////////

#ifndef STUDENT_UTILITY_H
#define STUDENT_UTILITY_H

// Header files ///////////////////////////////////////////////////////////////

#include <stdio.h>
#include "StandardConstants.h"

// global constants ////////////////////////////////////////////////////////////

   // None

// data structures /////////////////////////////////////////////////////////////

typedef struct StudentStruct
   {
    char name[ MAX_STR_LEN ];
    int studentId;
    char gender;
    double gpa;
   } StudentType;

/*
Name: createStudentTypeStruct
Process: copies one StudentType item into another
Function input/parameters: source data (const StudentType)
Function output/parameters: destination data (StudentType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
void createStudentTypeStruct( StudentType *newStudent, char *inName,
                                        int inId, char inGender, double inGpa );

/*
Name: deepCopyStudentData
Process: copies one StudentType item into another
Function input/parameters: source data (const StudentType)
Function output/parameters: destination data (StudentType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
void deepCopyStudentData( StudentType *dest, const StudentType source );

/*
Name: privateCopyString
Process: utility function - copies one string into another
Function input/parameters: source data (char *)
Function output/parameters: destination data (char *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
void privateCopyString( char *dest, const char *source );

/*
Name: studentDataToString
Process: creates display string from all object data
Method input/parameters: student data (const StudentType )
Method output/parameters: pointer to return string (char *)
Method output/returned: none
Device input/keyboard: none
Device output/monitor: none
Dependencies: sprintf
*/
void studentDataToString( char *outString, const StudentType toDisplay );

#endif		// STUDENT_UTILITY_H



