// Header files ///////////////////////////////////////////////////////////////
#include "StudentUtility.h"

// global constants ////////////////////////////////////////////////////////////

   // None

/*
Name: createStudentTypeStruct
Process: copies one StudentType item into another
Function input/parameters: source data (const StudentType)
Function output/parameters: destination data (StudentType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
void createStudentTypeStruct( StudentType *newStudent, char *inName,
                                        int inId, char inGender, double inGpa )
   {
    privateCopyString( newStudent->name, inName );
    newStudent->studentId = inId;
    newStudent->gender = inGender;
    newStudent->gpa = inGpa;
   }

/*
Name: deepCopyStudentData
Process: copies one StudentType item into another
Function input/parameters: source data (const StudentType)
Function output/parameters: destination data (StudentType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
void deepCopyStudentData( StudentType *dest, StudentType source )
   {
    privateCopyString( dest->name, source.name );
    dest->studentId = source.studentId;
    dest->gender = source.gender;
    dest->gpa = source.gpa;
   }

/*
Name: privateCopyString
Process: utility function - copies one string into another
Function input/parameters: source data (char *)
Function output/parameters: destination data (char *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
void privateCopyString( char *dest, const char *source )
   {
    int index = 0;

    while( source[ index ] != NULL_CHAR )
       {
        dest[ index ] = source[ index ];

        index++;
       }

    dest[ index ] = NULL_CHAR;
   }

/*
Name: studentDataToString
Process: creates display string from all object data
Method input/parameters: student data (const StudentType )
Method output/parameters: pointer to return string (char *)
Method output/returned: none
Device input/keyboard: none
Device output/monitor: none
Dependencies: sprintf
*/
void studentDataToString( char *outString, StudentType toDisplay )
   {
    sprintf( outString, "Nm: %s, Id: %d, Gndr: %c, GPA: %5.4f",
                                                        toDisplay.name,
                                                        toDisplay.studentId,
                                                        toDisplay.gender,
                                                        toDisplay.gpa );

   }


