// Test file for PA02

// import libraries
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>
#include "StandardConstants.h"
#include "File_Input_Utility.h"
#include "StudentUtility.h"
#include "SetUtility.h"
#include <string.h>

// function prototypes
/*
Name: addItemAsData
Process: adds item as student data to set, does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           student name (const char *),
                           student ID number (int),
                           student gpa (double),
                           student gender (char)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: isInSet, deepCopyStudentData

bool addItemAsData(SetType *setData, const char *inName, int inId, char inGender, double inGpa) {
    // Check if the set is full
    if (setData->size >= setData->capacity) {
        return false; // Cannot add more data, set is full
    }
	StudentType tempStudent;
	privateCopyString(tempStudent.name, inName);
	tempStudent.studentId = inId;
	tempStudent.gender = inGender;
	tempStudent.gpa = inGpa;
	
	if ( ( !isInSet(*setData, tempStudent) ) && ( setData->size < setData->capacity ) )
	{
		deepCopyStudentData( &setData->array[setData->size], tempStudent);
		setData->size = setData->size + 1;
		return true;
	}

    return false;
}
*/

/*
Name: addItemAsStruct
Process: adds item as a struct to set, does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           new item (StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: addItemAsData
Note: One line of code

bool addItemAsStruct( SetType *setData, const StudentType newValue )
{
	return(addItemAsData(setData, newValue.name, newValue.studentId,
        newValue.gender, newValue.gpa));
}
*/

 /*
Name: copySet
Process: copies all data of one set into other
Function Input/Parameters: source set (const SetType)
Function Output/Parameters: pointer to destination set (SetType *)
Function Output/Returned: none
Device Input/---: none
Device Output/---: none
Dependencies: deepCopyStudentData


void copySet( SetType *dest, const SetType source )
    {
        // initialize variables/function
            // initialize array index variable
            int arrIndex = 0;
		// traverse source struct
        for ( arrIndex = 0; arrIndex < source.size; arrIndex++ )
		    {
                // copy data from source to destination struct
		        deepCopyStudentData( &dest->array[ arrIndex ],
                    source.array[ arrIndex ] );
            }
            // give the source size to destination struct
			dest->size = source.size;
    }
*/
/*
Name: createSetFromData
Process: gets file name, 
         uploads data from specified file to locally created set, 
         randomly assigns specified number of unique values from local set 
         to output set, clears local set, returns output set         
Function Input/Parameters: number of random items to create (int)
Function Output/Parameters: none
Function Output/Returned: pointer to created set data (SetType *)
Device Input/HD: data uploaded as specified, file name input from keyboard
Device Output/monitor: prompt for file name
Dependencies: openInputFile, readStringToDelimiterFromFile, readIntegerFromFile,
              readCharacterFromFile, readDoubleFromFile, createSetData, 
              addItemAsData, addItemAsStruct, closeInputFile, getRandBetween,
              clearSetData

SetType *createSetFromData( int numItemsToCreate, bool randomSet )
   {
    SetType *tempSet = NULL, *newSet = NULL;
    int index, randIndex, numItemsInFile;
    char fileName[ STD_STR_LEN ], inNameStr[ STD_STR_LEN ];
    int inId;
    char inGender;
    double inGpa;

    printf( "\nEnter file name: " );
    scanf( "%s", fileName );

    // load data into temp set
    if( openInputFile( fileName ) )
       {
        readStringToDelimiterFromFile( COLON, inNameStr );

        numItemsInFile = readIntegerFromFile();

        tempSet = createEmptySet( numItemsInFile );

        for( index = 0; index < numItemsInFile; index++ )
           {
            readStringToDelimiterFromFile( SEMICOLON, inNameStr );

            inId = readIntegerFromFile();
            readCharacterFromFile();

            inGender = readCharacterFromFile();
            readCharacterFromFile();

            inGpa = readDoubleFromFile();

            addItemAsData( tempSet, inNameStr, inId, inGender, inGpa );
           }

        closeInputFile();
       }

    else
       {
        return NULL;
       }

    if( numItemsToCreate < numItemsInFile )
       {
        tempSet->size = numItemsToCreate;
       }

    // protection from requesting more than available
    else
       {
        numItemsToCreate = numItemsInFile;
       }

    if( !randomSet )
       {
        return tempSet;
       }

    // create file to output
    newSet = createEmptySet( numItemsToCreate );

    // only allows unique values in new set
    index = 0;
    while( index < numItemsToCreate )
       {
        randIndex = privateGetRandBetween( 0, numItemsInFile - 1 );

        if( addItemAsStruct( newSet, tempSet->array[ randIndex ] ) )
           {
            index = index + 1;
           }
       }

    tempSet = clearSetData( tempSet );

    return newSet;
   }
*/

/*
Name: clearSetData
Process: clears set along with internal array, returns NULL
Function Input/Parameters: pointer to set data (SetType *)
Function Output/Parameters: none
Function Output/Returned: NULL (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: free

SetType *clearSetData(SetType *toBeCleared)
    {
		if (toBeCleared != NULL)
		{
			free(toBeCleared->array);
			
			free(toBeCleared);
		}
	return NULL;
	}
*/

/*
Name: createEmptySet
Process: creates new SetType along with array, and sets capacity and size
Function Input/Parameters: array capacity (int)
Function Output/Parameters: none
Function Output/Returned: pointer to newly created SetType (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: malloc

SetType *createEmptySet( int capacitySet )
    {
	   // TODO
	   SetType *newSet = (SetType*)malloc(sizeof(SetType));
	   if (newSet != NULL)
	   {
		   newSet->array = (StudentType *)malloc(capacitySet * sizeof(StudentType));
		   if (newSet->array != NULL)
		   {
			   newSet->capacity = capacitySet;
		   newSet->size = 0;
		   
		   return newSet;
		   }
	   }
	printf("Unable to allocate memory for set..");
	return NULL;
    }
*/

/*
Name: deleteItem
Process: searches for item, deletes if found,
         moves array data down by one from above the removed value
         test loop must stop as soon as item is found (if it is found),
         updates size as needed,
         returns true if successful, false otherwise         
Function Input/Parameters: pointer to set data (SetType *), 
                           item to delete (const StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of operation (bool)
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings, deepCopyStudentData
*/
bool deleteItem( SetType *setData, const StudentType itemToDelete )
   {

    // Initialize variables

    // Initialize index variable to 0
    int index = 0;
    int endIndex = 0;

    // loop across list
    for( index = 0; index < setData->size; index++ )
       {

        // check for item found
        if ( privateCompareStrings( setData->array[ index ].name, itemToDelete.name ) == 0 )
           {

            // decrement the size
            setData->size--;

            // loop to end of list (works but might use while)
            for (endIndex = index; endIndex < setData->size; endIndex++)
               {

                // shift values down, one at a time
                deepCopyStudentData(&setData->array[endIndex], setData->array[endIndex + 1]);
               }

            // end loop to end of list

            // return true
            return true;
           }

        // end of check
       }

    // end loop across list

    // return false
    return false;
}

/*
Name: displaySet
Process: displays series of set values, or displays "Empty Set" if no values
Function Input/Parameters: name of set array (const char *),
                           set data (const SetType)
Function Output/Parameters: none
Function Output/Returned: none
Device Input/---: none
Device Output/monitor: data displayed as specified
Dependencies: printf
Note: Must use printf control characters for data alignment
*/
void displaySet(const char *setName, const SetType setData)
{
    if (setData.size == 0)
    {
        printf("Set %s is empty.\n", setName);
    }
    else
    {
        printf("Set %s:\n", setName);
        for (int i = 0; i < setData.size; i++)
        {
            printf("%d) Nm: %s, Id: %d, Gndr: %c, GPA: %.4f\n", i + 1, setData.array[i].name, setData.array[i].studentId,
                                 setData.array[i].gender, setData.array[i].gpa);
        }
    }
} 

/*
Name: isInSet
Process: searches for given student data in set,
         if found, returns true, otherwise returns false,
         must return found result immediately upon locating value
Function Input/Parameters: set (const SetType), search value (const StudentType)
Function Output/Parameters: none
Function Output/Returned: Boolean result of test, as specified
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings
*/
bool isInSet(const SetType testSet, const StudentType testData) {
    for (int i = 0; i < testSet.size; i++) {
        // Compare the fields of testData with the corresponding fields in testSet.array[i]
        if (privateCompareStrings(testData.name, testSet.array[i].name) == 0)
			{
            return true; // Found a match
        }
    }
    return false; // No match found
}

/*
Name: privateCompareStrings
Process: compares strings from left to right, letter by letter,
         if left string greater than right string, returns greater than zero,
         if left string less than right string, returns less than zero,
         if all string characters are equal and the string lengths are the same,
         returns zero, 
         otherwise returns left to right difference in string lengths
Function input/parameters: left and right strings (char *)
Function output/parameters: none
Function output/returned: returned value as specified (int)
Device input/---: none
Device output/---: none
Dependencies: privateGetStringLength
Note: no literal constants other than zero (e.g., -1, 1, etc.) 
      may be returned from this function
*/
int privateCompareStrings( const char *leftStr, const char *rightStr )
    {
        // initialize variables
            // initialize index variable
			int stringIndex = 0;
            // initialize difference variable
            int difference;
		    // initialize the size of the left string
	        int leftStringLength = privateGetStringLength(leftStr);
			// initialize the size of the right string
            int rightStringLength = privateGetStringLength(rightStr);
        // use while loop to traverse both strings
		while ( stringIndex < leftStringLength && stringIndex < rightStringLength )
		    {
             // set difference equal to the difference in ASCII values for each char
             difference = leftStr[ stringIndex ] - rightStr[ stringIndex ];
             // if the values are different
             if ( difference != 0 )
                 {
                    // return the difference
                    return difference;
                 }
            // increment index
            stringIndex = stringIndex + 1;
            }
        // return the differences between length
		return leftStringLength - rightStringLength;
    }

/*
Name: privateGetRandBetween
Process: generates and returns a random value
         between two given values, inclusive
Function Input/Parameters: low, high limits (int)
Function Output/Parameters: none
Function Output/Returned: random value as specified
Device Input/---: none
Device Output/---: none
Dependencies: rand
*/
int privateGetRandBetween( int lowVal, int highVal )
    {
     int range = highVal + 1 - lowVal;
	 return rand() % range + lowVal;
    }
/*
Name: privateGetStringLength
Process: returns length of c-style string
Function input/parameters: c-style string (char *)
Function output/parameters: none
Function output/returned: length of string (int)
Device input/---: none
Device output/---: none
Dependencies: none
*/
int privateGetStringLength( const char *str )
   {
	// initialize functions/variables
        // initialize index variable
		int stringLength = 0;
    // while loop to traverse string
	while ( str[ stringLength ] != NULL_CHAR )
	    {
            // increment string length 
            stringLength = stringLength + 1;
        }
		// return the length of the string
		return stringLength;
   }
  
   
bool removeSetWithKey( SetType* setData, char *name )
   {
    StudentType tempData;

    // creates dummy struct with specified key
    createStudentTypeStruct( &tempData, name, 123456, 'X', 1.23 );
    return deleteItem( setData, tempData );
   }

	
int main( int argc, char **argv )
   {
    // initialize function/variables

       // create set pointers
       SetType *firstTestSet = NULL, *secondTestSet = NULL;
       SetType *thirdTestSet = NULL, *thirdTestSetCopy = NULL;
       char tempStr[ STD_STR_LEN ];
       bool randomFlag;
       int numItems;

       // seed random generator
       srand( time( NULL ) );

       // show title
       printf( "\nSET TEST PROGRAM\n" );
       printf( "================\n\n" );

    // processing

       // upload data for initial testing
       printf( "Uploading first data set\n" );
       randomFlag = false; numItems = 50;
       firstTestSet = createSetFromData( numItems, randomFlag );

       if( firstTestSet != NULL )
          {
           // display data
           displaySet( "Initial display set", *firstTestSet );
   
           // remove two or three
           printf( "\nRemoving three items\n" );
   
           privateCopyString( tempStr, "Deangelis, Shawna" );
           if( removeSetWithKey( firstTestSet, tempStr ) )
              {
               printf( "\n-----%s successfully removed\n", tempStr );
              }
   
           privateCopyString( tempStr, "Sanchez, Kieley" );
           if( removeSetWithKey( firstTestSet, tempStr ) )
              {
               printf( "\n-----%s successfully removed\n", tempStr );
              }
   
   
           privateCopyString( tempStr, "Medrano-Pacheco, Rachel" );
           if( removeSetWithKey( firstTestSet, tempStr ) )
              {
               printf( "\n-----%s successfully removed\n", tempStr );
              }
   
           // display data
           displaySet( "Initial display after removal of three items", 
                                                                 *firstTestSet );
          }

       else
          {
           printf( "\nFailure of first data set to upload\n\n" );
          }

       // upload data for bubble sort - straight from file
       printf( "Uploading second data set\n" );
       secondTestSet = createSetFromData( numItems, randomFlag );

       if( secondTestSet != NULL )
          {
           // display data
           displaySet( "Data set before bubble sort", *secondTestSet );
          
           // run bubble sort
           runBubbleSort( secondTestSet );
   
           // display data
           displaySet( "Data set after bubble sort", *secondTestSet );
          }

       else
          {
           printf( "\nFailure of second data set to upload\n\n" );
          }

        // upload data for insertion sort - randomly selected
       printf( "Uploading third data set\n" );
       randomFlag = true; numItems = 40;
       thirdTestSet = createSetFromData( numItems, randomFlag );

       if( thirdTestSet != NULL )
          {
           // copy data for selection sort
           thirdTestSetCopy = createEmptySet( numItems );
   
           printf( "\nCopying third data set for selection sort\n" );
           copySet( thirdTestSetCopy, *thirdTestSet );
   
           // display data
           displaySet( "Data set before insertion sort", *thirdTestSet );
          
           // run insertion sort
           runInsertionSort( thirdTestSet );
   
           // display data
           displaySet( "Data set after insertion sort", *thirdTestSet );
   
           // display data - use copied data from insertion sort
           displaySet( "Data set before selection sort", *thirdTestSetCopy );
           
           // run selection sort
           runSelectionSort( thirdTestSetCopy );
   
           // display data
           displaySet( "Data set after selection sort", *thirdTestSetCopy );
          }

       else
          {
           printf( "\nFailure of third data set to upload\n\n" );
          }

    // end program

        // clear test set data
        firstTestSet = clearSetData( firstTestSet );
        secondTestSet = clearSetData( secondTestSet );
        thirdTestSet = clearSetData( thirdTestSet );
        thirdTestSetCopy = clearSetData( thirdTestSetCopy );

        // display end
        printf( "\nEnd Program\n" );

        // return success
        return 0;
   }


