#include "SetUtility.h"

// prototypes
bool removeSetWithKey( SetType* setData, char *name );

// main function
int main( int argc, char **argv )
   {
    // initialize function/variables

       // create set pointers
       SetType *firstTestSet = NULL, *secondTestSet = NULL;
       SetType *thirdTestSet = NULL, *thirdTestSetCopy = NULL;
       char tempStr[ STD_STR_LEN ];
       bool randomFlag;
       int numItems;

       // seed random generator
       srand( time( NULL ) );

       // show title
       printf( "\nSET TEST PROGRAM\n" );
       printf( "================\n\n" );

    // processing

       // upload data for initial testing
       printf( "Uploading first data set\n" );
       randomFlag = false; numItems = 50;
       firstTestSet = createSetFromData( numItems, randomFlag );

       if( firstTestSet != NULL )
          {
           // display data
           displaySet( "Initial display set", *firstTestSet );
   
           // remove two or three
           printf( "\nRemoving three items\n" );
   
           privateCopyString( tempStr, "Deangelis, Shawna" );
           if( removeSetWithKey( firstTestSet, tempStr ) )
              {
               printf( "\n-----%s successfully removed\n", tempStr );
              }
   
           privateCopyString( tempStr, "Sanchez, Kieley" );
           if( removeSetWithKey( firstTestSet, tempStr ) )
              {
               printf( "\n-----%s successfully removed\n", tempStr );
              }
   
   
           privateCopyString( tempStr, "Medrano-Pacheco, Rachel" );
           if( removeSetWithKey( firstTestSet, tempStr ) )
              {
               printf( "\n-----%s successfully removed\n", tempStr );
              }
   
           // display data
           displaySet( "Initial display after removal of three items", 
                                                                 *firstTestSet );
          }

       else
          {
           printf( "\nFailure of first data set to upload\n\n" );
          }

       // upload data for bubble sort - straight from file
       printf( "Uploading second data set\n" );
       secondTestSet = createSetFromData( numItems, randomFlag );

       if( secondTestSet != NULL )
          {
           // display data
           displaySet( "Data set before bubble sort", *secondTestSet );
          
           // run bubble sort
           runBubbleSort( secondTestSet );
   
           // display data
           displaySet( "Data set after bubble sort", *secondTestSet );
          }

       else
          {
           printf( "\nFailure of second data set to upload\n\n" );
          }

        // upload data for insertion sort - randomly selected
       printf( "Uploading third data set\n" );
       randomFlag = true; numItems = 40;
       thirdTestSet = createSetFromData( numItems, randomFlag );

       if( thirdTestSet != NULL )
          {
           // copy data for selection sort
           thirdTestSetCopy = createEmptySet( numItems );
   
           printf( "\nCopying third data set for selection sort\n" );
           copySet( thirdTestSetCopy, *thirdTestSet );
   
           // display data
           displaySet( "\nData set before insertion sort", *thirdTestSet );
          
           // run insertion sort
           runInsertionSort( thirdTestSet );
   
           // display data
           displaySet( "\nData set after insertion sort", *thirdTestSet );
   
           // display data - use copied data from insertion sort
           displaySet( "\nData set before selection sort", *thirdTestSetCopy );
           
           // run selection sort
           runSelectionSort( thirdTestSetCopy );
   
           // display data
           displaySet( "\nData set after selection sort", *thirdTestSetCopy );
          }

       else
          {
           printf( "\nFailure of third data set to upload\n\n" );
          }

    // end program

        // clear test set data
        firstTestSet = clearSetData( firstTestSet );
        secondTestSet = clearSetData( secondTestSet );
        thirdTestSet = clearSetData( thirdTestSet );
        thirdTestSetCopy = clearSetData( thirdTestSetCopy );

        // display end
        printf( "\nEnd Program\n" );

        // return success
        return 0;
   }

bool removeSetWithKey( SetType* setData, char *name )
   {
    StudentType tempData;

    // creates dummy struct with specified key
    createStudentTypeStruct( &tempData, name, 123456, 'X', 1.23 );

    return deleteItem( setData, tempData );
   }

