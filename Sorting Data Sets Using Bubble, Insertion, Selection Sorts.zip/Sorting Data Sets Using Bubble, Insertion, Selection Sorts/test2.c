#include <stdio.h>
#include <stdlib.h>

#define MAX_STR_LEN 50

typedef struct StudentStruct {
    char name[MAX_STR_LEN];
    int studentId;
    char gender;
    double gpa;
} StudentType;

typedef struct SetStruct {
    StudentType *array;
    int capacity;
    int size;
} SetType;

int main() {
    SetType studentSet;
    studentSet.capacity = 10;
    studentSet.size = 0;
    
    // Dynamically allocate memory for the array
    studentSet.array = (StudentType *)malloc(studentSet.capacity * sizeof(StudentType));
    
    // Add a student to the set
    StudentType student;
    snprintf(student.name, MAX_STR_LEN, "John Doe");
    student.studentId = 1;
    student.gender = 'M';
    student.gpa = 3.5;
    
    studentSet.array[studentSet.size++] = student;
    
    // Now you have one student in the set

    // Remember to free the allocated memory when you're done
    free(studentSet.array);

    return 0;
}
