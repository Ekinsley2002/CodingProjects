#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>
#include "StandardConstants.h"
#include "File_Input_Utility.h"
#include "StudentUtility.h"
#include "SetUtility.h"
/*
Name: addItemAsData
Process: adds item as student data to set, does not allow duplicates,
		 does not allow data to be added to full list, updates size,
		 returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
						   student name (const char *),
						   student ID number (int),
						   student gpa (double),
						   student gender (char)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: isInSet, deepCopyStudentData
*/

bool addItemAsData(SetType *setData, const char *inName,
	int inId, char inGender, double inGpa) 
	{
	// create temporary student struct
	StudentType tempStudent;
	// copy inName variable into name member for temporary student
		// function: privateCopyString
	privateCopyString( tempStudent.name, inName );
	// assign inId to studentId member for temporary student
	tempStudent.studentId = inId;
	// assign Ingender to gender member for temporary student
	tempStudent.gender = inGender;
	// assign inGpa to gpa member for temporary student
	tempStudent.gpa = inGpa;
	
	// check to see if duplicate name and its less than capacity
		// function: isInSet
	if( ( !isInSet( *setData, tempStudent ) ) &&
		( setData->size < setData->capacity ) )
		{
		   // copy the student data into the array
			deepCopyStudentData( &setData->array[setData->size], tempStudent);
			// decrement the size of array
			setData->size = setData->size + 1;
			// successfully copied data to array
			return true;
		}
	// unable to store data
	return false;
	}


/*
Name: addItemAsStruct
Process: adds item as a struct to set, does not allow duplicates,
		 does not allow data to be added to full list, updates size,
		 returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
						   new item (StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: addItemAsData
Note: One line of code
*/
bool addItemAsStruct( SetType *setData, const StudentType newValue )
	{
		// return the items as struct 
		return( addItemAsData(setData, newValue.name,
			newValue.studentId, newValue.gender, newValue.gpa ));
	}


/*
Name: clearSetData
Process: clears set along with internal array, returns NULL
Function Input/Parameters: pointer to set data (SetType *)
Function Output/Parameters: none
Function Output/Returned: NULL (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: free
*/

SetType *clearSetData(SetType *toBeCleared)
	{
		// check to see if array is clear
		if (toBeCleared != NULL)
			{
				// if not clear, then clear array
				free(toBeCleared->array);
				// clear structure
				free(toBeCleared);
			}
		// return NULL once array is clear
		return NULL;
	}
	
 /*
Name: copySet
Process: copies all data of one set into other
Function Input/Parameters: source set (const SetType)
Function Output/Parameters: pointer to destination set (SetType *)
Function Output/Returned: none
Device Input/---: none
Device Output/---: none
Dependencies: deepCopyStudentData
*/

void copySet( SetType *dest, const SetType source )
	{

		// initialize variables/function
			// initialize array index variable
			int arrIndex = 0;

		// traverse source struct
		for ( arrIndex = 0; arrIndex < source.size; arrIndex++ )
			{
				// copy data from source to destination struct
					// function: deepCopyStudentData
				deepCopyStudentData( &dest->array[ arrIndex ],
					source.array[ arrIndex ] );
			}
			// give the source size to destination struct
			dest->size = source.size;

	}

/*
Name: createEmptySet
Process: creates new SetType along with array, and sets capacity and size
Function Input/Parameters: array capacity (int)
Function Output/Parameters: none
Function Output/Returned: pointer to newly created SetType (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: malloc
*/

SetType *createEmptySet( int capacitySet )
	{

	 // allocate the memory location for SetType struct
	 SetType *newSet = (SetType*)malloc(sizeof(SetType));

	 // check to see if the new set is created
	 // allocate the memory location for StudentType array
	 newSet->array = (StudentType *)malloc(capacitySet * sizeof(StudentType));

	 // set the capacity member of the new set
		 // to given capacity
	 newSet->capacity = capacitySet;

	 // set the size member of newSet to zero
	 newSet->size = 0; 
	 return newSet;

	}

/*
Name: createSetFromData
Process: gets file name, 
		 uploads data from specified file to locally created set, 
		 randomly assigns specified number of unique values from local set 
		 to output set, clears local set, returns output set		 
Function Input/Parameters: number of random items to create (int)
Function Output/Parameters: none
Function Output/Returned: pointer to created set data (SetType *)
Device Input/HD: data uploaded as specified, file name input from keyboard
Device Output/monitor: prompt for file name
Dependencies: openInputFile, readStringToDelimiterFromFile, readIntegerFromFile,
			  readCharacterFromFile, readDoubleFromFile, createSetData, 
			  addItemAsData, addItemAsStruct, closeInputFile, getRandBetween,
			  clearSetData
*/

SetType *createSetFromData( int numItemsToCreate, bool randomSet )
   {
	SetType *tempSet = NULL, *newSet = NULL;
	int index, randIndex, numItemsInFile;
	char fileName[ STD_STR_LEN ], inNameStr[ STD_STR_LEN ];
	int inId;
	char inGender;
	double inGpa;

	printf( "\nEnter file name: " );
	scanf( "%s", fileName );

	// load data into temp set
	if( openInputFile( fileName ) )
	   {
		readStringToDelimiterFromFile( COLON, inNameStr );

		numItemsInFile = readIntegerFromFile();

		tempSet = createEmptySet( numItemsInFile );

		for( index = 0; index < numItemsInFile; index++ )
		   {
			readStringToDelimiterFromFile( SEMICOLON, inNameStr );

			inId = readIntegerFromFile();
			readCharacterFromFile();

			inGender = readCharacterFromFile();
			readCharacterFromFile();

			inGpa = readDoubleFromFile();

			addItemAsData( tempSet, inNameStr, inId, inGender, inGpa );
		   }

		closeInputFile();
	   }

	else
	   {
		return NULL;
	   }

	if( numItemsToCreate < numItemsInFile )
	   {
		tempSet->size = numItemsToCreate;
	   }

	// protection from requesting more than available
	else
	   {
		numItemsToCreate = numItemsInFile;
	   }

	if( !randomSet )
	   {
		return tempSet;
	   }

	// create file to output
	newSet = createEmptySet( numItemsToCreate );

	// only allows unique values in new set
	index = 0;
	while( index < numItemsToCreate )
	   {
		randIndex = privateGetRandBetween( 0, numItemsInFile - 1 );

		if( addItemAsStruct( newSet, tempSet->array[ randIndex ] ) )
		   {
			index = index + 1;
		   }
	   }

	tempSet = clearSetData( tempSet );

	return newSet;
   }

/*
Name: deleteItem
Process: searches for item, deletes if found,
		 moves array data down by one from above the removed value
		 test loop must stop as soon as item is found (if it is found),
		 updates size as needed,
		 returns true if successful, false otherwise		 
Function Input/Parameters: pointer to set data (SetType *), 
						   item to delete (const StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of operation (bool)
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings, deepCopyStudentData
*/

bool deleteItem( SetType *setData, const StudentType itemToDelete )
   {
	// initialize variables/function
		// initialize array index variable
		int arrIndex = 0;
		// initialize end of first array variable
		int endIndex = 0;

	// loop across list
	for( arrIndex = 0; arrIndex < setData->size; arrIndex++ )
	   {
		// check for item found
		if ( privateCompareStrings( setData->array[ arrIndex ].name,
			itemToDelete.name ) == 0 )
		   {
				// decrement the size
				setData->size = setData->size - 1;

				// loop to end of list (works but might use while)
				for ( endIndex =arrIndex; endIndex < setData->size; endIndex++ )
				   {
						// shift values down, one at a time
							// function: deepCopyStudentData
						deepCopyStudentData(&setData->array[ endIndex ],
						setData->array[ endIndex + 1 ]);
				   }
				// end loop to end of list
			// return true
			return true;
		   }
		// end of check
	   }

	// end loop across list
	// return false
	return false;
   }
   
/*
Name: displaySet
Process: displays series of set values, or displays "Empty Set" if no values
Function Input/Parameters: name of set array (const char *),
						   set data (const SetType)
Function Output/Parameters: none
Function Output/Returned: none
Device Input/---: none
Device Output/monitor: data displayed as specified
Dependencies: printf
Note: Must use printf control characters for data alignment
*/
void displaySet(const char *setName, const SetType setData)
	{

	// initialize functions/variables
		// initialize temporary string
		char tempString[STD_STR_LEN];
		// initialize index variable
		int arrIndex = 0;

	// check whether the set is empty
	if ( setData.size == 0 )
		{
			// tell the user the set is empty
			printf( "Empty Set\n", setName );
		}
	// if the array isn't empty
	else
		{
			// tell the user which set display
			printf( "\nSet Data Display %c %s\n\n", DASH, setName );
			// traverse through the set
			for ( arrIndex = 0; arrIndex < setData.size; arrIndex++ )
			{
				// write the student data to temp string
					// function: studentDataToString
				studentDataToString( tempString, setData.array[ arrIndex ] );
				// print the data
				printf( "%d) %s\n", arrIndex + 1, tempString );
			}
			// print newline
			printf( "\n" );
		}
	} 

/*
Name: isInSet
Process: searches for given student data in set,
		 if found, returns true, otherwise returns false,
		 must return found result immediately upon locating value
Function Input/Parameters: set (const SetType), search value (const StudentType)
Function Output/Parameters: none
Function Output/Returned: Boolean result of test, as specified
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings
*/

bool isInSet(const SetType testSet, const StudentType testData) 
	{ 
	// initialize functions/variables
		// initialize array index variable
		int arrIndex = 0;
	// traverse through the set
	for ( arrIndex = 0; arrIndex < testSet.size; arrIndex++ ) 
		{
			// compare the name in test data to test set
			if ( privateCompareStrings(testData.name,
				testSet.array[ arrIndex ].name) == 0 )
				{
					// the name has been found
					return true;
				}
		}
	return false; // No match found
	}

/*
Name: privateCompareStrings
Process: compares strings from left to right, letter by letter,
		 if left string greater than right string, returns greater than zero,
		 if left string less than right string, returns less than zero,
		 if all string characters are equal and the string lengths are the same,
		 returns zero, 
		 otherwise returns left to right difference in string lengths
Function input/parameters: left and right strings (char *)
Function output/parameters: none
Function output/returned: returned value as specified (int)
Device input/---: none
Device output/---: none
Dependencies: privateGetStringLength
Note: no literal constants other than zero (e.g., -1, 1, etc.) 
	  may be returned from this function
*/

int privateCompareStrings( const char *leftStr, const char *rightStr )
	{

	// initialize variables
		// initialize index variable
		int stringIndex = 0;
		// initialize difference variable
		int difference = 0;
		// initialize the size of the left string
			// function: privateGetStringLength
		int leftStringLength = privateGetStringLength( leftStr );
		// initialize the size of the right string
			// function: privateGetStringLength
		int rightStringLength = privateGetStringLength( rightStr );
		// use while loop to traverse both strings
		while ( stringIndex < leftStringLength &&
			stringIndex < rightStringLength )
			{
				// set difference equal to the difference
				// in ASCII values for each char
				difference = leftStr[ stringIndex ] - rightStr[ stringIndex ];
				// if the values are different
				if ( difference != 0 )
					{

					// return the difference
					return difference;

					}
			// increment index
			stringIndex = stringIndex + 1;
			}
		// return the differences between length
		return leftStringLength - rightStringLength;

	}


/*
Name: privateGetRandBetween
Process: generates and returns a random value
		 between two given values, inclusive
Function Input/Parameters: low, high limits (int)
Function Output/Parameters: none
Function Output/Returned: random value as specified
Device Input/---: none
Device Output/---: none
Dependencies: rand
*/
int privateGetRandBetween( int lowVal, int highVal )
	{

	// find the range of the random variable
	int range = highVal + 1 - lowVal;
	// return random number in range
	return rand() % range + lowVal;

	}
	
/*
Name: privateGetStringLength
Process: returns length of c-style string
Function input/parameters: c-style string (char *)
Function output/parameters: none
Function output/returned: length of string (int)
Device input/---: none
Device output/---: none
Dependencies: none
*/

int privateGetStringLength( const char *str )
   {

	// initialize functions/variables
		// initialize index variable
		int stringLength = 0;
	// while loop to traverse string
	while ( str[ stringLength ] != NULL_CHAR )
		{
			// increment string length 
			stringLength = stringLength + 1;
		}
		// return the length of the string
		return stringLength;

   }
   
/*
Name: runBubbleSort
Process: sorts Set values using bubble sort algorithm with name as key
Function input/parameters: pointer to set data (SetType *)
Function output/parameters: updated pointer to set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, swapValues
Note: must use two for loops
*/
void runBubbleSort( SetType *setData )
	{
	// initialize functions/variables
		// initialize array index for traversal
		int arrIndex = 0;
		// initialize sort index for traversal
		int sortIndex = 0;
	// traverse array in set data
	for ( arrIndex = setData->size - 1; arrIndex >= 0; arrIndex-- )
		{
			// traverse using bubble sort
			for ( sortIndex = 0; sortIndex < arrIndex; sortIndex++ )
				{
					// compare the first letter of each name
					// to the next element
						// function: privateCompareStrings
					if ( privateCompareStrings(
					   setData->array[ sortIndex ].name
					   , setData->array[ sortIndex + 1 ].name ) > 0 )
						{ 
							// swap array elements
								// function: swapValues
							swapValues( &setData->array[ sortIndex ],
								&setData->array[ sortIndex + 1 ] );
						}
				}
		}
	}

/*
Name: runInsertionSort
Process: sorts set values using insertion sort algorithm with name as key
Function input/parameters: pointer to set data (SetType *)
Function output/parameters: updated pointer to set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings
Note: swap function may not be used in this function
*/
void runInsertionSort( SetType *setData )
	{
	// initialize functions/variables
		// initialize index variable
		int arrIndex = 0;
		// initialize previous element variable
		int sortIndex = 0;
		// initialize temporary student struct
		StudentType tempStudent;

	// traverse through SetType
	for (sortIndex = 1; sortIndex<setData->size; sortIndex++)
		{
			// assign previous index variable
			arrIndex = sortIndex - 1;
			// assign the temp student to the sort index
			tempStudent = setData->array[ sortIndex ];

			while ( privateCompareStrings(setData->array[ arrIndex ].name,
				tempStudent.name ) > 0 && arrIndex >= 0 )
			{
					// set the next index to the current index
					setData->array[ arrIndex + 1 ] = 
						setData->array[ arrIndex ]; 
					// decrement the array index
					arrIndex = arrIndex - 1;
			}
			// set the next array element to tempStudent
			setData->array[ arrIndex + 1 ] = tempStudent;
		}
	}


/*
Name: runSelectionSort
Process: sorts set values using selection sort algorithm with name as key
Function input/parameters: pointer to set data (SetType *)
Function output/parameters: updated pointer to set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, swapValues
*/
void runSelectionSort( SetType *setData )
	{
	 // initialize functions/variable
		// initialize arrray index
		int arrIndex = 0;
		// initialize sort index variable
		int sortIndex = 0;
		// initialize minimum variable
		int minimum = 0;
	 // traverse the index
	for ( sortIndex = 0; sortIndex < setData->size - 1; sortIndex++ )
		{
		 // set the minimum to the current index
		 minimum = sortIndex;
		 // traverse the index again
		 for ( arrIndex = sortIndex + 1; arrIndex < setData->size;arrIndex++ )
			 {
			  // check whether the names are the same
				  // function: privateCompareStrings
			  if ( privateCompareStrings( setData->array[ arrIndex ].name,
				  setData->array[ minimum ].name) < 0 )
				  {
					   // swap the values of the minimum and the array
					   swapValues( &setData->array[ minimum ],
						   &setData->array[ arrIndex ] );
				  }
			 }
		 }
	}

/*
Name: swapValues
Process: swaps data between two set data quantities (StudentTypes)
Function input/parameters: pointers to two StudentType values (StudentType *)
Function output/parameters: pointers to updated StudentType values 
																 (StudentType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: deepCopyStudentData
*/
void swapValues( StudentType *one, StudentType *other )
   {

	// initialize temporary student struct
	StudentType tempStr;

	// copy data from one to tempStr
	   // function: deepCopyStudentData
	deepCopyStudentData( &tempStr, *one );

	// copy other into one
	   // function: deepCopyStudentData
	deepCopyStudentData( one, *other );

	// copy tempStr into other
	   // function: deepCopyStudentData
	deepCopyStudentData( other, tempStr );
   }