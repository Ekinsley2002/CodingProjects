// header file
#include "File_Input_Utility.h"
#include "GeneralUtility.h"
#include "IteratorUtility.h"
#include "StackUtility.h"
#include "QueueUtility.h"

// local constants for program
const int INITIAL_NUM_STATES = 10;
const int MAX_STATES = 55;

// function prototypes
void showTitle();
bool uploadNames( char nameArray[][ STD_STR_LEN ], const char *fileName );
void iterateFirstToLast( IteratorType *iterator );
void iterateLastToFirst( IteratorType *iterator );
void displayQueue( QueueType *queue );
void displayStack( StackType *stack );

int main()
   {
    // initialize function/program

       // initialize variables
       char names[ MAX_STATES ][ STD_STR_LEN ];
       char name[ STD_STR_LEN ];
       int index, testStart, testLimit;
       // show title
          // function: showTitle
       showTitle();

       // create data pointers
       IteratorType *iterator;
       QueueType *queue, *dupQueue;
       StackType *stack;

    // set up data
    iterator = createIterator( INITIAL_NUM_STATES );
    queue = createQueue( INITIAL_NUM_STATES );
    dupQueue = createQueue( INITIAL_NUM_STATES );
    stack = createStack( INITIAL_NUM_STATES );

    // Upload data
    if( uploadNames( names, "StateData.csv" ))
       {
        // Testing for iterators
        printf( "\nIterator Test Bed ---------------------------------\n\n" );

        printf( "Inserting at end\n" );

        testStart = 10; testLimit = 20;
        for( index = testStart; index < testLimit; index++ )
           {
            printf( "Inserting: %s\n", names[ index ] );

            insertAtEnd( iterator, names[ index ] );
           }

        iterateFirstToLast( iterator );

        printf( "Inserting at First\n" );

        testStart = 20; testLimit = 25;
        for( index = testStart; index < testLimit; index++ )
           {
            printf( "Inserting: %s\n", names[ index ] );

            insertAtFirst( iterator, names[ index ] );
           }

        iterateFirstToLast( iterator );

        printf( "Moving current to middle\n" );   
        setToFirst( iterator );

        for( index = testStart; index < testLimit; index++ )
           {
            moveNext( iterator );
           }

        printf( "Inserting at Current (in middle)\n" );

        testStart = 30; testLimit = 35;
        for( index = testStart; index < testLimit; index++ )
           {
            printf( "Inserting: %s\n", names[ index ] );

            insertAtCurrent( iterator, names[ index ] );
           }

        iterateFirstToLast( iterator );
           
        // iterateLastToFirst( iterator );

        printf( "Removing from end\n" );

        setToLast( iterator );

        testStart = 0; testLimit = 5;
        for( index = testStart; index < testLimit; index++ )
           {
            removeAtCurrent( iterator, name );

            printf( "Removing: %s\n", name );
           }
        
       iterateFirstToLast( iterator );

       // iterateLastToFirst( iterator );

        printf( "Removing from beginning\n" );

        setToFirst( iterator );

        testStart = 0; testLimit = 5;
        for( index = testStart; index < testLimit; index++ )
           {
            removeAtCurrent( iterator, name );

            printf( "Removing: %s\n", name );
           }
        
       iterateFirstToLast( iterator );

       iterateLastToFirst( iterator );        

        printf( "Removing from beginning until empty\n" );

        setToFirst( iterator );

        while( removeAtCurrent( iterator, name ) )
           {
            printf( "Removing: %s\n", name );
           }

        // Testing for Queues
        printf( "\nQueue Test Bed ------------------------------------\n\n" );

        printf( "Enqueue items:\n" );

        testStart = 0; testLimit = 15;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Enqueueing: %s\n", name );

            enqueue( queue, name );
           }

        displayQueue( queue );

        printf( "\nDequeue items:\n" );

        testStart = 0; testLimit = 5;
        for( index = testStart; index < testLimit; index++ )
           {
            dequeue( queue, name );

            printf( "Dequeueing: %s\n", name );
           }

        displayQueue( queue );

        printf( "\nEnqueue more items:\n" );

        testStart = 20; testLimit = 25;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Enqueueing: %s\n", name );

            enqueue( queue, name );
           }

        displayQueue( queue );

        printf( "*** Duplicating queue ***\n" );

        dupQueue = duplicateQueue( queue );
        
        printf( "\nDequeueing duplicate queue until empty:\n" );

        while( dequeue( dupQueue, name ) )
           {
            printf( "Dequeueing: %s\n", name );
           }

        // Testing for Stacks
        printf( "\nStack Test Bed ------------------------------------\n\n" );
      printf( "Push items on stack:\n" );

        testStart = 0; testLimit = 15;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Pushing: %s\n", name );

            push( stack, name );
           }

        displayStack( stack );

        printf( "Pop items from stack:\n" );

        testStart = 0; testLimit = 5;
        for( index = testStart; index < testLimit; index++ )
           {
            pop( stack, name );

            printf( "Popping: %s\n", name );
           }

        displayStack( stack );

        printf( "Push more items on stack:\n" );

        testStart = 25; testLimit = 30;
        for( index = testStart; index < testLimit; index++ )
           {
            privateCopyString( name, names[ index ] );

            printf( "Pushing: %s\n", name );

            push( stack, name );
           }

        displayStack( stack );

        printf( "Popping until empty:\n" );

        while( pop( stack, name ) )
           {
            printf( "Popping: %s\n", name );
           }
       }

    else
       {
        printf( "\nFile not found - Program aborted\n" );
       }
       
    // end program

       // report end program
          // function: printf
       printf( "\nProgram End\n" );

       // deallocate memory

       iterator = clearIterator( iterator );

       queue = clearQueue( queue );

       dupQueue = clearQueue( dupQueue );

       stack = clearStack( stack );

       // return program success
       return 0;
   }

void showTitle()
   {
    printf( "\nData Structure Test Program\n" );
    printf( "===========================\n" );
   }

/*
Name: iterateFirstToLast
Process: displays data from iterator from the first to the last item
Function input/parameters: iterator (IteratorType *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displaye as specified
Dependencies: setToFirst, getAtFirst, getNext, printf
*/
void iterateFirstToLast( IteratorType *iterator )
   {
    char name[ STD_STR_LEN ];

    printf( "\nIterating first to last\n" );

    setToFirst( iterator );

    getFirst( iterator, name );

    printf( "First name: %s\n", name );

    while( getNext( iterator, name ) )
       {
        printf( "Next name: %s\n", name );
       }

    printf( "\n" );  

   }
/*
Name: iterateLastToFirst
Process: displays data from iterator from the last to the first item
Function input/parameters: iterator (IteratorType *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displaye as specified
Dependencies: setToLast, getAtLast, getPrev, printf
*/
void iterateLastToFirst( IteratorType *iterator )
   {
    char name[ STD_STR_LEN ];

    printf( "\nIterating last to first\n" );

    setToLast( iterator );

    getLast( iterator, name );

    printf( "First name: %s\n", name );

    while( getPrev( iterator, name ) )
       {
        printf( "Previous name: %s\n", name );
       }

    printf( "\n" );
   }

/*
Name: displayQueue
Process: displays queue names from rear to front
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: printf
*/
void displayQueue( QueueType *queue )
   {
    int locIndex = queue->rearIndex, ctrIndex = 0;
    printf( "\nCurrent queue:\n" );
    printf( "    Rear\n" );
    printf( "============\n" );

    for( ctrIndex = 0; ctrIndex < queue->size; ctrIndex++ )
       {
        printf( "%s\n", queue->names[ locIndex ] );

        locIndex--;

        if( locIndex < 0 )
           {
            locIndex = queue->capacity - 1;
           }
       }

    printf( "=============\n" );
    printf( "    Front\n\n" );
   }

/*
Name: displayStack
Process: displays stack names from top to bottom
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: printf
*/
void displayStack( StackType *stack )
   {
    int index;

    printf( "\nCurrent stack:\n" );
    printf( "    Top\n" );
    printf( "===========\n" );

    for( index = stack->size - 1; index >= 0; index-- )
       {
        printf( "%s\n", stack->names[ index ] );
       }

    printf( "============\n" );
    printf( "   Bottom\n\n" );
   }

/*
Name: uploadNames
Process: uploads names from given state data file,
         ignores first (title) line in .csv file,
         then captures comma-delimited state name, population, growth, 
         and political majority data on each row,
         then sets name in array,
         returns true if upload successful, false otherwise
Function input/parameters: file name (const char *)
Function output/parameters: updated array with uploaded values (StateDataType *)
Function output/returned: Boolean result of upload operation
Device input/HD: data uploaded from text file as specified
Device output/---: none
Dependencies: as needed
*/
bool uploadNames( char nameArray[][ STD_STR_LEN ], const char *fileName )
   {
    int intVal, index = 0;
    char name[ STD_STR_LEN ];
    char charVal;
    double doubleVal;
    bool verboseFlag = false;

    if( openInputFile( fileName ) )
       {
        // input top row, ignore
        readStringToLineEndFromFile( name );

        // input first data line, read prime
        readStringToDelimiterFromFile( COMMA, name );

        while( !checkForEndOfInputFile() )
           {
            // get population
            intVal = readIntegerFromFile();
            readCharacterFromFile();

            // get growth percentage
            doubleVal = readDoubleFromFile();
            readCharacterFromFile();
        
            charVal = readCharacterFromFile();

            if( verboseFlag )
               {
                printf( "[%3d] name: %s, int: %d, double: %7.6f, char: %c\n",
                              index + 1, name, intVal, doubleVal, charVal );
               }
            
            privateCopyString( nameArray[ index ], name  );

            index++;
  
            // read re-prime
            readStringToDelimiterFromFile( COMMA, name );
           }

        closeInputFile();

        return true;
       }

    return false;
   }


