    if( !failedControlCode )
       {
        // iterate from size down
        for( wkgIndex = iter->size; wkgIndex > insertIndex; wkgIndex-- )
           {

           }
        // end of loop
        // insert the value
        privateCopyString( iter->names[ wkgIndex ], newStr );

       } 