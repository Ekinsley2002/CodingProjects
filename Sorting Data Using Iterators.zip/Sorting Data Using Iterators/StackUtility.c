#include "StackUtility.h"

/*
Name: checkStackForResize
Process: if stack name array is full, 
         doubles capacity of array, otherwise, no action occurs
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: pointer to updated stack (StackType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createStackNameArray, privateCopyString, clearStackNameArray
*/
void checkStackForResize( StackType *stack )
  {
   // initialize functions/variables
      // initialize name array
      char **nameArray;
      // intiialize double capacity variable
      int doubleCap = 0;
      // initialize array index variable
      int arrayIndex = 0;
   
   // initiliaze double capacity to capacity * 2
   doubleCap = 2 * stack->capacity;

   // check if the size equals capacity
   if( stack->size == stack->capacity )
     {
      // create new 2d array with double capacity
      nameArray = createStackNameArray( doubleCap );

      // assign old data to new array
      for( arrayIndex = 0; arrayIndex < stack->size; arrayIndex++ )
        {
         privateCopyString( nameArray[ arrayIndex ],
            stack->names[ arrayIndex ] );
        }

      // free the old memory
      clearStackNameArray( stack->names, stack->capacity );

      // assign structures to new struct
      stack->names = nameArray;
      stack->capacity = doubleCap;
     }
   }

/*
Name: clearStack
Process: deallocates stack and internal array, returns NULL
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: none
Function output/returned: NULL (StackType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearStackvNameArray, free
*/
StackType *clearStack( StackType *stack )
  {
   // check to see if names is valid
   if( stack->names != NULL )
     {
      // free the names array
      clearStackNameArray( stack->names, stack->size );
     }
      
   // free the memory for the iterator
   free( stack );
   
   return NULL;
 }

/*
Name: clearStackNameArray
Process: deallocates name/string array, returns NULL
Function input/parameters: pointer to name/string array (char **), 
                           number of names (int)
Function output/parameters: none
Function output/returned: NULL (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
char **clearStackNameArray( char **nameArray, int numNames )
  {
   // initialize functions/variables
      // initialize array index variable
      int arrayIndex;

   // deallocate every index of name array
   for( arrayIndex = 0; arrayIndex < numNames; arrayIndex ++ )
     {
      if( nameArray[ arrayIndex ] != NULL )
        {
         free(nameArray[ arrayIndex ]); 
         nameArray[ arrayIndex ] = NULL;
        }
     }
     
   // free the name array memory
   free( nameArray );
   
   return NULL;
  }

/*
Name: createStack
Process: allocates Stack and internal array data,
         initializes all member data as needed
Function input/parameters: initial number of names (int)
Function output/parameters: none
Function output/returned: created stack (StackType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, createStackNameArray
*/
StackType *createStack( int initialCapacity )
  {
   // initialize functions/variables
      // initialize Iterator
      StackType *stack;
      
   stack = ( StackType *)malloc(sizeof( StackType ) );

   // allocate memory for the names vector
   stack->names = createStackNameArray( initialCapacity );
   
   // initialize member data
   stack->size = 0;
   stack->capacity = initialCapacity;
   
   return stack;
  }

/*
Name: createStackNameArray
Processallocates memory for array of names/strings
Function input/parameters: number of names (int)
Function output/parameters: none
Function output/returned: created array of names/strings (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc 
*/
char **createStackNameArray( int initialCapacity )
  {
   // initialize functions/variables
      // initilaize name array
      char **nameArray;
      // initialize array index
      int arrayIndex = 0;
      
   // allocate memory for the array of names
   nameArray = ( char ** )malloc( initialCapacity * sizeof( char * ) );

   // allocate memory for each name in the array
   for( arrayIndex = 0;  arrayIndex < initialCapacity; arrayIndex++)
     {
      // allocate memory for each word
      nameArray[ arrayIndex ] = ( char * )malloc
         ( STD_STR_LEN * sizeof( char ) );
     }

    return nameArray;
  }
/*
Name: duplicateStack
Process: creates new stack, copies data from given source
Function input/parameters: pointer to source Stack (StackType *)
Function output/parameters: none
Function output/returned: new duplicated stack (StackType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createStack, privateCopyString
*/
StackType *duplicateStack( const StackType *source )
  {
   // initialize functions/variables
      // initialize the duplicated iterator
      StackType *dupStack;
      
      // initialize array index
      int arrayIndex;
   
   // allocate memory for the duplicated struct
   dupStack = ( StackType *)malloc( sizeof( StackType ) );
   
   // allocate memory for the names array in dupStack
   dupStack->names = createStackNameArray( source->capacity );
   
   // traverse source index
   for( arrayIndex = 0; arrayIndex < source->size; arrayIndex++ )
     {
      // copy the names into dupplicated iterator
      privateCopyString(  dupStack->names[ arrayIndex ],
         source->names[ arrayIndex ] );
     }
     
   // assign struct members of duplicated array to source array
   dupStack->size = source->size;
   dupStack->capacity = source->capacity;
     
   return dupStack;
  }

/*
Name: stackIsEmpty
Process: returns true if stack is empty, false otherwise
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool stackIsEmpty( StackType *stack )
  {
   // if the stack is empty
   return ( stack->size == 0 );
  }

/*
Name: peekTop
Process: returns value at the top of the stack
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to source stack (StackType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (char *)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekTop( StackType *stack, char *returnStr )
  {
   // check if steck is empty
   if( stackIsEmpty( stack ) )
     {
      returnStr = NULL;
      return false;
     }
   // copy the top index data to return string
   privateCopyString( returnStr, stack->names[ stack->size ] );
   return true;
  }

/*
Name: pop
Process: removes and returns name at top of stack,
         updates index
         if found, sets return name and returns true,
         if not, sets return name to empty and returns false
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: removed name (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool pop( StackType *stack, char *returnStr )
  {
   // check if stack is empty
   if( stack->size == 0 )
     {
      returnStr = NULL;
      return false;
     }
   // decrement the size
   stack->size = stack->size - 1;
   // return name at the top of stack
   privateCopyString( returnStr, stack->names[ stack->size ] );
   return true;
  }

/*
Name: push
Process: adds new data to the top of the stack,
         updates the index
Function input/parameters: pointer to stack (StackType *),
                           new name/string (char *)
Function output/parameters: pointer to updated stack (StackType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: checkForResize, privateCopyString
*/
void push( StackType *stack, char *newStr )
  {
   // check to see if stack needs to be resized
   checkStackForResize( stack );
   // add new data to the top of the stack
   privateCopyString( stack->names[ stack->size ], newStr );
   // inrcrement stack size
   stack->size = stack->size + 1;
  }