#include "QueueUtility.h"

/*
Name: checkQueueForResize
Process: if queue name array is full, 
         doubles capacity of array, otherwise, no action occurs
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: pointer to updated queue (QueueType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueueNameArray, privateCopyString, clearQueueNameArray
*/
void checkQueueForResize( QueueType *queue )
  {
   // initialize functions/variables
      // initialize temporary array
      char **tempArray;
      // initialize a double capacity variable
      int doubleCap = 0;
      // initialize queue index variable
      int queueIndex = 0;

   // assign double capacity to capacity times 2
   doubleCap = 2 * queue->capacity;

   // check if the size and capacity are the same
   if( queue->size == queue->capacity )
     {
      // create new name array with double the capacity
      tempArray = createQueueNameArray( doubleCap );

      // copy data to new array
      for( queueIndex = 0; queueIndex < queue->size; queueIndex++ )
        {
         privateCopyString( tempArray[ queueIndex ],
            queue->names[ queueIndex ] );
        }

      // clear queue array
      clearQueueNameArray( queue->names, queue->capacity );

      // copy members from data struct to the new array
      queue->names = tempArray;
      queue->capacity = doubleCap;
      queue->frontIndex = 0;
      queue->rearIndex = queue->size - 1;
     }
  }

/*
Name: clearQueue
Process: deallocates queue and internal array, returns NULL
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: none
Function output/returned: NULL (Queue *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearQueueNameArray, free
*/
QueueType *clearQueue( QueueType *queue )
  {
   // check if names have data
   if( queue->names != NULL )
     {
      // clear the queue name array
      clearQueueNameArray( queue->names, queue->size );
     }

   // clear the queue struct
   free( queue );
   
   return NULL;
  }

/*
Name: clearQueueNameArray
Process: deallocates name/string array, returns NULL
Function input/parameters: pointer to name/string array (char **), 
                           number of names (int)
Function output/parameters: none
Function output/returned: NULL (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
char **clearQueueNameArray( char **nameArray, int numNames )
  {
   // initialize functions/variables
      // initialize array index variable
      int arrayIndex;

   // traverse through array and free every index
   // also set every index to NULL
   for( arrayIndex = 0; arrayIndex < numNames; arrayIndex ++ )
     {
      if( nameArray[ arrayIndex ] != NULL )
        {
         free( nameArray[ arrayIndex ] ); 
         nameArray[ arrayIndex ] = NULL;
        }
     }
     
   // free the name array
   free( nameArray );
   
   return NULL;
  }

/*
Name: createQueue
Process: allocates Queue and internal array data,
         initializes all member data as needed
Function input/parameters: initial number of names (int)
Function output/parameters: none
Function output/returned: created queue (QueueType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, createQueueNameArray
*/
QueueType *createQueue( int initialCapacity )
  {
   // initialize functions/variables
      // initialize queue
      QueueType *queue;
   // allocate memory for the queue struct   
   queue = ( QueueType *)malloc( sizeof( QueueType ) );

   // allocate memory for the names vector
   queue->names = createQueueNameArray( initialCapacity );
   
   // initialize member data
   queue->capacity = initialCapacity;
   queue->frontIndex = 0;
   queue->size = 0;
   queue->rearIndex = queue->size - 1; // this is wrong
   
   return queue;
  }
/*
Name: createQueueNameArray
Process: allocates memory for array of names/strings
Function input/parameters: number of names (int)
Function output/parameters: none
Function output/returned: created array of names/strings (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc 
*/
char **createQueueNameArray( int initialCapacity )
  {
   // initialize functions/variables
      // initialize indexes
      int nameIndex = 0;
      //initialize the name array
      char **nameArray;
      
   // allocate the memory for the array of names
   nameArray = ( char ** )malloc( initialCapacity * sizeof( char * ) );

   // allocate memory for each string in the array
   for( nameIndex = 0; nameIndex < initialCapacity; nameIndex++ )
     {
      // Allocate memory for each string (char array)
      nameArray[ nameIndex ] = ( char * )malloc
         ( STD_STR_LEN * sizeof( char ) );
     }

   return nameArray;
  }

/*
Name: dequeueProcess: removes and returns name at front of queue,
         updates front index
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: removed string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool dequeue( QueueType *queue, char *returnStr )
  {
   if( queue->size == 0 )
     {
      // initially set rear index to -1
      queue->rearIndex = -1;
      // also set front index to 0
      queue->frontIndex = 0;
     }
    
   // check to see if size is greater than 0
   if( queue->size > 0 )
     {
      // get the value at the front index
      privateCopyString( returnStr, queue->names[ queue->frontIndex ] );
      
      // increment the front queue
      queue->frontIndex = ( queue->frontIndex + 1 ) % queue->capacity;
      
      // decrement the size
      queue->size = queue->size - 1;
      
      // operation successful
      return true;
     }
   // operation failed
   return false;
  }

/*
Name: duplicateQueue
Process: creates new queue, copies data from given source
Function input/parameters: pointer to source queue (QueueType *)
Function output/parameters: none
Function output/returned: new duplicated queue (QueueType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueue, privateCopyString
*/
QueueType *duplicateQueue(const QueueType *source)
  {
   // initialize functions/variables
      // initialize the duplicated queue
      QueueType *dupQueue;
      // initialize the array index
      int arrayIndex = 0;
      // initialize the source index
      int sourceIndex = 0;
      
   // create duplicated queue
   dupQueue = createQueue( source->capacity );

   // assign the source index to the front index
   sourceIndex = source->frontIndex;

   // traverse through source array
   for( arrayIndex = 0; arrayIndex < source->size; arrayIndex++ )
     {
      // copy values from source to duplicated
      privateCopyString( dupQueue->names[ arrayIndex ],
         source->names[ sourceIndex ] );
      // increment source index and check bounds
      sourceIndex = ( sourceIndex + 1 ) % source->capacity;
     }

   // Assign struct members from source to dup
   dupQueue->frontIndex = 0;
   dupQueue->rearIndex = source->size - 1;
   dupQueue->size = source->size;
   
   // return the duplicated queue
   return dupQueue;
  }

/*
Name: enQueue
Process: adds new data to the rear of the queue,
         updates the rear index
Function input/parameters: pointer to queue (QueueType *),
                           new name/string (char *)
Function output/parameters: pointer to updated queue (QueueType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: checkQueueForResize, privateCopyString
*/
void enqueue( QueueType *queue, char *newStr )
  {
   // check to see if queue needs to be resized
   checkQueueForResize( queue );
   // check if the queue is empty
   if( queue->size == 0 )
     {
      // initially set the back index to -1
      queue->rearIndex = -1;
         // and the front index to 0
      queue->frontIndex = 0;
         // and initialize the size to zero
      queue->size = 0;
     }
   // increment the front index, 
   // rolling it over to the beginning of the array
   // if it goes past the end
   queue->rearIndex = ( queue->rearIndex + 1 ) % queue->capacity;
    
   // add the new value to the array at the back index
   privateCopyString( queue->names[ queue->rearIndex ], newStr );
   // update the size
   queue->size = queue->size + 1;
  }

/*
Name: queueIsEmpty
Process: returns true if queue is empty, false otherwise
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool queueIsEmpty( QueueType *queue )
  {
   // return whether the size is 0
   return queue->size == 0;
  }
/*
Name: peekFront
Process: returns value at the front of the queue
Function input/parameters: pointer to source queue (QueueType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (char *)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekFront( QueueType *queue, char *returnStr )
  {
   // check if the queue is empty
   if( queueIsEmpty( queue ) )
     {
      // operation failed
      return false;
     }
   // return the front value;
   privateCopyString( returnStr, queue->names[ queue->frontIndex ] );
   
   // operation successful
   return true;
  }