
#include "IteratorUtility.h"
/*
Name: checkIteratorForResize
Process: if iterator name array is full, 
         doubles capacity of array, otherwise, no action occurs
Function input/parameters: pointer to Iterator (IteratorType *)
Function output/parameters: pointer to updated Iterator (IteratorType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createIteratorNameArray, privateCopyString, 
              clearIteratorNameArray
*/
void checkIteratorForResize( IteratorType *iter )
  {
   // initialize variables
      // initialize name array
      char **tempArray;
      // initialize double capacity variable
      int doubleCap = 0;
      // initialize array index variable
      int arrayIndex = 0;
   // assign double capactity to capacity * 2
   doubleCap = 2 * iter->capacity;

   // if size = capacity
   if( iter->size == iter->capacity )
     {
      // create new 2d array with double capacity
      tempArray = createIteratorNameArray( doubleCap );

      // copy data from source to temporary array
      for( arrayIndex = 0; arrayIndex < iter->size; arrayIndex++ )
        {
         privateCopyString( tempArray[ arrayIndex ],
            iter->names[ arrayIndex ] );
        }

      // free previous array
      clearIteratorNameArray( iter->names, iter->capacity );

      // assign struct members
      iter->names = tempArray;
      iter->capacity = doubleCap;
     }
  }

/*
Name: clearIterator
Process: deallocates iterator and internal array, returns NULL
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: none
Function output/returned: NULL (Iterator *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearIteratorNameArray, free
*/
IteratorType *clearIterator( IteratorType *iter )
  {
   // check to see if names is valid
   if( iter->names != NULL )
     {
      // free name array
      clearIteratorNameArray( iter->names, iter->size );
     }
   // put in if statement
   // free iterator
   free( iter );
   
   return NULL;
  }

/*
Name: clearIteratorNameArray
Process: deallocates name/string array, returns NULL
Function input/parameters: pointer to name/string array (char **), 
                           number of names (int)
Function output/parameters: none
Function output/returned: NULL (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
char **clearIteratorNameArray( char **nameArray, int numNames )
  {
   // initialize functions/variables
      // initialize array index variable
      int arrayIndex;

   // deallocate every index of name array
   for( arrayIndex = 0; arrayIndex < numNames; arrayIndex ++ )
     {
      if( nameArray[ arrayIndex ] != NULL )
        {
         free( nameArray[ arrayIndex ] ); 
         nameArray[ arrayIndex ] = NULL;
        }
     }
     
   // free the name array memory
   free( nameArray );
   
   return NULL;
  }
/*
Name: createIterator
Process: allocates iterator and internal name array,
         initializes all member data as needed
Function input/parameters: initial number of names (int)
Function output/parameters: none
Function output/returned: created iterator (Iterator *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, createIteratorNameArray
*/
IteratorType *createIterator( int initialCapacity )
  {
   // initialize functions/variables
      // initialize iterator
      IteratorType *iterator;
   // allocate space for iterator  
   iterator = ( IteratorType * )malloc( sizeof( IteratorType ) );

   // allocate memory for the names vector
   iterator->names = createIteratorNameArray( initialCapacity );
   
   // initialize member data
   iterator->currentIndex = 0;
   iterator->size = 0;
   iterator->capacity = initialCapacity;
   
   return iterator;
  }

/*
Name: createIteratorNameArray
Process: allocates memory for array of names/strings
Function input/parameters: number of names (int)
Function output/parameters: none
Function output/returned: created array of names/strings (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc 
*/
char **createIteratorNameArray( int initialCapacity )
  {
   // initialize functions/variables
      // initialize name array
      char **nameArray;
      // initialize array index variable
      int arrayIndex;
      
   // allocate memory for the array of pointers
   nameArray = ( char ** )malloc( initialCapacity * sizeof( char * ) );

   // allocate the names array memory
   for( arrayIndex = 0; arrayIndex < initialCapacity; arrayIndex++ )
     {
      // allocate memory for each name
      nameArray[ arrayIndex ] = ( char * )malloc
         ( STD_STR_LEN * sizeof( char ) );
     }
   // return the name array
   return nameArray;
  }

/*
Name: duplicateIterator
Process: creates new iterator, copies data from given source
Function input/parameters: pointer to source Iterator (Iterator *)
Function output/parameters: none
Function output/returned: pointer to new duplicated iterator (Iterator *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createIterator, privateCopyString
*/
IteratorType *duplicateIterator( const IteratorType *source )
  {
   // initialize functions/variables
      // initialize the duplicated iterator
      IteratorType *dupIterator;
      
      // initialize array index
      int arrayIndex;
   
   // allocate memory for the duplicated struct
   dupIterator = ( IteratorType *)malloc( sizeof( IteratorType ) );
   
   // allocate memory for the names
   dupIterator->names = createIteratorNameArray( source->capacity );
   
   // traverse source index
   for( arrayIndex = 0; arrayIndex < source->size; arrayIndex++ )
     {
      // copy the names into dupplicated iterator
      privateCopyString(  dupIterator->names[ arrayIndex ],
         source->names[ arrayIndex ] );
     }
     
   // assign struct members of duplicated array to source array
   dupIterator->currentIndex = source->currentIndex;
   dupIterator->size = source->size;
   dupIterator->capacity = source->capacity;
     
   return dupIterator;
  }

/*
Name: getAtCurrent
Process: gets data at current location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getAtCurrent( IteratorType *iter, char *returnStr )
  {
   // get the data at the current location
   return privateGetEngine( iter, returnStr, CURRENT );
  }

/*
Name: getFirst
Process: gets data at first location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getFirst( IteratorType *iter, char *returnStr )
  {
   // get the data at first location
   return privateGetEngine( iter, returnStr, FIRST );
  }

/*
Name: getLast
Process: gets data at last location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getLast( IteratorType *iter, char *returnStr )
  {
   // get the data at the last location
   return privateGetEngine( iter, returnStr, LAST );
  }

/*
Name: getNext
Process: gets data at next location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getNext( IteratorType *iter, char *returnStr )
  {
   // get the data at the next location
   return privateGetEngine( iter, returnStr, NEXT );
  }

/*
Name: getPrev
Process: gets data prior to the current location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getPrev( IteratorType *iter, char *returnStr )
  {
   // get the data at the previous location
   return privateGetEngine( iter, returnStr, PREVIOUS );
  }

/*
Name: insertAtCurrent
Process: inserts data at current location in iterator
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *)
Function output/parameters: none
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateInsertEngine
*/
void insertAtCurrent( IteratorType *iter, char *newStr )
  {
   // insert the data at the current poisition
   privateInsertEngine( iter, newStr, CURRENT );
  }

/*
Name: insertAtEnd
Process: inserts data at last location in iterator
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *)
Function output/parameters: none
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateInsertEngine
*/
void insertAtEnd( IteratorType *iter, char *newStr )
  {
   // insert the data at the end poisition
   privateInsertEngine( iter, newStr, END );
  }

/*
Name: insertAtFirst
Process: inserts data at first location in iterator
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *)
Function output/parameters: none
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateInsertEngine
*/
void insertAtFirst( IteratorType *iter, char *newStr )
  {
   // insert the data at the first poisition
   privateInsertEngine( iter, newStr, FIRST );
  }

/*
Name: iteratorIsEmpty
Process: returns true if iterator is empty, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool iteratorIsEmpty( IteratorType *iter )
  {
   // return true if size if zero
   return ( iter->size == 0 );
  }

/*
Name: moveNext
Process: moves current index to the next index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool moveNext( IteratorType *iter )
  {
   // move current index to next
   return privateMoveEngine( iter, NEXT );
  }

/*
Name: movePrev
Process: moves current index to the next index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool movePrev( IteratorType *iter )
  {
   // move current index to previous
   return privateMoveEngine( iter, PREVIOUS );
  }

/*
Name: privateGetEngine
Process: gets data at specified location (CURRENT,FIRST,LAST,NEXT,PREV) 
         if available, returns true if successful, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *), control code (int)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool privateGetEngine( IteratorType *iter, char *returnStr, int ctrlCode )
  {
   // initialize function/variables
      // intitialize get index variable
      int getIndex;   
      // initialize failed control code variable
      bool failedControlCode = false;

   // check for current index
   if( ctrlCode == CURRENT )
     {
      // set insert index to current index
      getIndex = iter->currentIndex;
     }

   // otherwise, check for first 
   else if( ctrlCode == FIRST  )
     {
      // set insert index to zero
      getIndex = 0;
     }
       
   // otherwise, check for LAST
   else if( ctrlCode == LAST  )
     {
      // set insert index to size
      getIndex = iter->size - 1;
     }

   // otherwise, check for NEXT
   else if( ctrlCode == NEXT  )
     {
      // set insert index to size
      getIndex = iter->currentIndex + 1;
     }
       
   // otherwise, check for PREV
   else if( ctrlCode ==  PREVIOUS )
     {
      // set insert index to size
      getIndex = iter->currentIndex - 1;
     }

   // handle wrong control code
   else
       {
        failedControlCode = true;
       }
         // check to see if current index equals size
   if( getIndex < 0 || getIndex >= iter->size )
     {
      return false;
     }
   if( !failedControlCode )
     {
      // get the value and assign it to returnStr
      privateCopyString( returnStr, iter->names[ getIndex ] );
      // set the current index to get index
      iter->currentIndex = getIndex;
      return true;
     } 
   return false;
  }
   /*
Name: privateInsertEngine
Process: inserts data at specified location (CURRENT, END, FIRST)in iterator,
         resizes name array as needed
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *), control code (int)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString, checkIteratorForResize
*/
void privateInsertEngine( IteratorType *iter, char *newStr, int ctrlCode )
  {
   // initialize function/variables
      // intitialize working index and insert index
      int workingIndex, insertIndex;   
      // initialize failed control code variable
      bool failedControlCode = false;

   // check for resize
   checkIteratorForResize( iter );

   // check for current index
   if( ctrlCode == CURRENT )
     {
      // set insert index to current index
      insertIndex = iter->currentIndex;
     }

   // otherwise, check for first 
   else if( ctrlCode == FIRST  )
     {
      // set insert index to zero
      insertIndex = 0;
     }

   // otherwise, check for end
   else if( ctrlCode == END  )
     {
      // set insert index to size
      insertIndex = iter->size;
     }
 
   // handle wrong control code
   else
     {
      failedControlCode = true;
     }
   if( !failedControlCode )
     {
      // iterate from size down
      for( workingIndex = iter->size; workingIndex > insertIndex; workingIndex-- )
        {
         // assign element to next one up
         privateCopyString( iter->names[ workingIndex ],
            iter->names[ workingIndex - 1 ] );
        }
      privateCopyString( iter->names[ insertIndex ], newStr );
      iter->size = iter->size + 1;
     } 
  }
/*
Name: privateMoveEngine
Process: moves current index as specified (END, FIRST, NEXT, PREVIOUS)
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *),
                           control code (int)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool privateMoveEngine( IteratorType *iter, int ctrlCode )
  {
   // check if control code is last 
   if( ctrlCode == LAST )
     {
      iter->currentIndex = iter->size - 1;
      return true;
     }

   // otherwise, check for first 
   else if( ctrlCode == FIRST  )
     {
      iter->currentIndex = 0;
      return true;
     }
     
   // otherwise, check for NEXT
   else if( ctrlCode == NEXT  )
     {
      iter->currentIndex = iter->currentIndex + 1;
      return true;
     }
       
   // otherwise, check for PREV
   else if( ctrlCode ==  PREVIOUS )
     {
      iter->currentIndex = iter->currentIndex - 1;
      return true;
     }

   // handle wrong control code *just need to fall through to true*
   else
     {
      return false;
     }
  }

/*
Name: removeAtCurrent
Process: removes name from list at current location if possible,
         returns true if successful, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *),
                            return string (char *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
Note: must manage current index if it goes out of bounds
*/
bool removeAtCurrent( IteratorType *iter, char *returnStr )
  {
   // initialize functions/variables
      // intialize array index variable
      int arrayIndex = 0;
   // Check if current index is within bounds
   if( iter->currentIndex < 0 || iter->currentIndex >= iter->size )
     {
      return false;
     }
   privateCopyString( returnStr, iter->names[ iter->currentIndex ] );
   
   // traverse through array
   for( arrayIndex = iter->currentIndex;
      arrayIndex < iter->size - 1; arrayIndex++ )
     {
      privateCopyString( iter->names[ arrayIndex ],
         iter->names[ arrayIndex + 1 ] );
     }
     
   // decrement size
   iter->size = iter->size - 1;
   
   if( iter->currentIndex == iter->size )
     {
      iter->currentIndex--;
     }
     
   return true;
  }

/*
Name: setToLast
Process: moves current index to the last index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to update Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool setToLast( IteratorType *iter )
  {
   // sets current index to last
   return privateMoveEngine( iter, END );
  }
   
/*
Name: setToFirst
Process: moves current index to the first index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool setToFirst( IteratorType *iter )
  {
   // sets current index to first
   return privateMoveEngine( iter, FIRST );
  }