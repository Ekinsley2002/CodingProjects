#ifndef ITERATOR_UTILITY_H
#define ITERATOR_UTILITY_H

////////////////////////////////////////////////////////////////////////////////
// header files
#include <stdlib.h>
#include <stdbool.h>
#include "GeneralUtility.h"
////////////////////////////////////////////////////////////////////////////////
// global constants

#define CURRENT 101
#define END 102
#define FIRST 103
#define LAST 104
#define NEXT 105
#define PREVIOUS 106


////////////////////////////////////////////////////////////////////////////////
// data structures

typedef struct IteratorStruct
   {
    char **names;

    int currentIndex, size, capacity;
   } IteratorType;

// prototypes

/*
Name: checkIteratorForResize
Process: if iterator name array is full, 
         doubles capacity of array, otherwise, no action occurs
Function input/parameters: pointer to Iterator (IteratorType *)
Function output/parameters: pointer to updated Iterator (IteratorType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createIteratorNameArray, privateCopyString, 
              clearIteratorNameArray
*/
void checkIteratorForResize( IteratorType *iter );

/*
Name: clearIterator
Process: deallocates iterator and internal array, returns NULL
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: none
Function output/returned: NULL (Iterator *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearIteratorNameArray, free
*/
IteratorType *clearIterator( IteratorType *iter );

/*
Name: clearIteratorNameArray
Process: deallocates name/string array, returns NULL
Function input/parameters: pointer to name/string array (char **), 
                           number of names (int)
Function output/parameters: none
Function output/returned: NULL (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
char **clearIteratorNameArray( char **nameArray, int numNames );

/*
Name: createIterator
Process: allocates iterator and internal name array,
         initializes all member data as needed
Function input/parameters: initial number of names (int)
Function output/parameters: none
Function output/returned: created iterator (Iterator *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, createIteratorNameArray
*/
IteratorType *createIterator( int initialCapacity );

/*
Name: createIteratorNameArray
Process: allocates memory for array of names/strings
Function input/parameters: number of names (int)
Function output/parameters: none
Function output/returned: created array of names/strings (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc 
*/
char **createIteratorNameArray( int initialCapacity );

/*
Name: duplicateIterator
Process: creates new iterator, copies data from given source
Function input/parameters: pointer to source Iterator (Iterator *)
Function output/parameters: none
Function output/returned: pointer to new duplicated iterator (Iterator *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createIterator, privateCopyString
*/
IteratorType *duplicateIterator( const IteratorType *source );

/*
Name: getAtCurrent
Process: gets data at current location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getAtCurrent( IteratorType *iter, char *returnStr );

/*
Name: getFirst
Process: gets data at first location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getFirst( IteratorType *iter, char *returnStr );

/*
Name: getLast
Process: gets data at last location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getLast( IteratorType *iter, char *returnStr );

/*
Name: getNext
Process: gets data at next location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getNext( IteratorType *iter, char *returnStr );

/*
Name: getPrev
Process: gets data prior to the current location in iterator, if available,
         returns true upon success, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateGetEngine
*/
bool getPrev( IteratorType *iter, char *returnStr );

/*
Name: insertAtCurrent
Process: inserts data at current location in iterator
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *)
Function output/parameters: none
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateInsertEngine
*/
void insertAtCurrent( IteratorType *iter, char *newStr );

/*
Name: insertAtEnd
Process: inserts data at last location in iterator
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *)
Function output/parameters: none
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateInsertEngine
*/
void insertAtEnd( IteratorType *iter, char *newStr );

/*
Name: insertAtFirst
Process: inserts data at first location in iterator
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *)
Function output/parameters: none
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateInsertEngine
*/
void insertAtFirst( IteratorType *iter, char *newStr );

/*
Name: iteratorIsEmpty
Process: returns true if iterator is empty, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool iteratorIsEmpty( IteratorType *iter );

/*
Name: moveNext
Process: moves current index to the next index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool moveNext( IteratorType *iter );

/*
Name: movePrev
Process: moves current index to the next index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool movePrev( IteratorType *iter );

/*
Name: privateGetEngine
Process: gets data at specified location (CURRENT,FIRST,LAST,NEXT,PREV) 
         if available, returns true if successful, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *), control code (int)
Function output/parameters: return string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool privateGetEngine( IteratorType *iter, char *returnStr, int ctrlCode );

/*
Name: privateInsertEngine
Process: inserts data at specified location (CURRENT, END, FIRST)in iterator,
         resizes name array as needed
Function input/parameters: pointer to Iterator (Iterator *),
                           string to input (char *), control code (int)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString, checkIteratorForResize
*/
void privateInsertEngine( IteratorType *iter, char *newStr, int ctrlCode );

/*
Name: privateMoveEngine
Process: moves current index as specified (END, FIRST, NEXT, PREVIOUS)
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *),
                           control code (int)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool privateMoveEngine( IteratorType *iter, int ctrlCode );

/*
Name: removeAtCurrent
Process: removes name from list at current location if possible,
         returns true if successful, false otherwise
         and the return string is set to empty
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *),
                            return string (char *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
Note: must manage current index if it goes out of bounds
*/
bool removeAtCurrent( IteratorType *iter, char *returnStr );

/*
Name: setToLast
Process: moves current index to the last index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool setToLast( IteratorType *iter );
   
/*
Name: setToFirst
Process: moves current index to the first index if possible,
         returns true if successful, false otherwise
Function input/parameters: pointer to Iterator (Iterator *)
Function output/parameters: pointer to updated Iterator (Iterator *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateMoveEngine
*/
bool setToFirst( IteratorType *iter );

#endif   // ITERATOR_UTILITY_H


