#ifndef STACK_UTILITY_H
#define STACK_UTILITY_H

////////////////////////////////////////////////////////////////////////////////
// header files
#include <stdbool.h>
#include <stdlib.h>
#include "GeneralUtility.h"

////////////////////////////////////////////////////////////////////////////////
// data structures

typedef struct StackStruct
   {
    char **names;

    int capacity, size;
   } StackType;

////////////////////////////////////////////////////////////////////////////////
// function prototypes

/*
Name: checkStackForResize
Process: if stack name array is full, 
         doubles capacity of array, otherwise, no action occurs
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: pointer to updated stack (StackType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createStackNameArray, privateCopyString, clearStackNameArray
*/
void checkStackForResize( StackType *stack );

/*
Name: clearStack
Process: deallocates stack and internal array, returns NULL
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: none
Function output/returned: NULL (StackType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearStackvNameArray, free
*/
StackType *clearStack( StackType *stack );

/*
Name: clearStackNameArray
Process: deallocates name/string array, returns NULL
Function input/parameters: pointer to name/string array (char **), 
                           number of names (int)
Function output/parameters: none
Function output/returned: NULL (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
char **clearStackNameArray( char **nameArray, int numNames );

/*
Name: createStack
Process: allocates Stack and internal array data,
         initializes all member data as needed
Function input/parameters: initial number of names (int)
Function output/parameters: none
Function output/returned: created stack (StackType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, createStackNameArray
*/
StackType *createStack( int initialCapacity );

/*
Name: createStackNameArray
Process: allocates memory for array of names/strings
Function input/parameters: number of names (int)
Function output/parameters: none
Function output/returned: created array of names/strings (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc 
*/
char **createStackNameArray( int initialCapacity );

/*
Name: duplicateStack
Process: creates new stack, copies data from given source
Function input/parameters: pointer to source Stack (StackType *)
Function output/parameters: none
Function output/returned: new duplicated stack (StackType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createStack, privateCopyString
*/
StackType *duplicateStack( const StackType *source );

/*
Name: stackIsEmpty
Process: returns true if stack is empty, false otherwise
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool stackIsEmpty( StackType *stack );

/*
Name: peekTop
Process: returns value at the top of the stack
         if found, sets return data and returns true,
         if not, sets return data to empty and returns false
Function input/parameters: pointer to source stack (StackType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (char *)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekTop( StackType *stack, char *returnStr );

/*
Name: pop
Process: removes and returns name at top of stack,
         updates index
         if found, sets return name and returns true,
         if not, sets return name to empty and returns false
Function input/parameters: pointer to stack (StackType *)
Function output/parameters: removed name (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool pop( StackType *stack, char *returnStr );

/*
Name: push
Process: adds new data to the top of the stack,
         updates the index
Function input/parameters: pointer to stack (StackType *),
                           new name/string (char *)
Function output/parameters: pointer to updated stack (StackType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: checkForResize, privateCopyString
*/
void push( StackType *stack, char *newStr );


#endif   // STACK_UTILITY_H

