#ifndef QUEUE_UTILITY_H
#define QUEUE_UTILITY_H

////////////////////////////////////////////////////////////////////////////////
// header files
#include <stdbool.h>
#include <stdlib.h>
#include "GeneralUtility.h"

////////////////////////////////////////////////////////////////////////////////
// data structures

typedef struct QueueStruct
   {
    char **names;

    int capacity, frontIndex, rearIndex, size;
   } QueueType;

////////////////////////////////////////////////////////////////////////////////
// function prototypes

/*
Name: checkQueueForResize
Process: if queue name array is full, 
         doubles capacity of array, otherwise, no action occurs
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: pointer to updated queue (QueueType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueueNameArray, privateCopyString, clearQueueNameArray
*/
void checkQueueForResize( QueueType *queue );

/*
Name: clearQueue
Process: deallocates queue and internal array, returns NULL
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: none
Function output/returned: NULL (Queue *)
Device input/ ---: none
Device output/ ---: none
Dependencies: clearQueueNameArray, free
*/
QueueType *clearQueue( QueueType *queue );

/*
Name: clearQueueNameArray
Process: deallocates name/string array, returns NULL
Function input/parameters: pointer to name/string array (char **), 
                           number of names (int)
Function output/parameters: none
Function output/returned: NULL (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: free
*/
char **clearQueueNameArray( char **nameArray, int numNames );

/*
Name: createQueue
Process: allocates Queue and internal array data,
         initializes all member data as needed
Function input/parameters: initial number of names (int)
Function output/parameters: none
Function output/returned: created queue (QueueType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc, createQueueNameArray
*/
QueueType *createQueue( int initialCapacity );

/*
Name: createQueueNameArray
Process: allocates memory for array of names/strings
Function input/parameters: number of names (int)
Function output/parameters: none
Function output/returned: created array of names/strings (char **)
Device input/ ---: none
Device output/ ---: none
Dependencies: malloc 
*/
char **createQueueNameArray( int initialCapacity );

/*
Name: dequeue
Process: removes and returns name at front of queue,
         updates front index
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: removed string (char *)
Function output/returned: Boolean result of operation (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool dequeue( QueueType *queue, char *returnStr );

/*
Name: duplicateQueue
Process: creates new queue, copies data from given source
Function input/parameters: pointer to source queue (QueueType *)
Function output/parameters: none
Function output/returned: new duplicated queue (QueueType *)
Device input/ ---: none
Device output/ ---: none
Dependencies: createQueue, privateCopyString
*/
QueueType *duplicateQueue( const QueueType *source );

/*
Name: enQueue
Process: adds new data to the rear of the queue,
         updates the rear index
Function input/parameters: pointer to queue (QueueType *),
                           new name/string (char *)
Function output/parameters: pointer to updated queue (QueueType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: checkQueueForResize, privateCopyString
*/
void enqueue( QueueType *queue, char *newStr );

/*
Name: queueIsEmpty
Process: returns true if queue is empty, false otherwise
Function input/parameters: pointer to queue (QueueType *)
Function output/parameters: none
Function output/returned: Boolean result as specified (bool)
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
bool queueIsEmpty( QueueType *queue );

/*
Name: peekFront
Process: returns value at the front of the queue
Function input/parameters: pointer to source queue (QueueType *)
Function output/parameters: returned name/string (char *)
Function output/returned: Boolean result of operation (char *)
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
bool peekFront( QueueType *queue, char *returnStr );


#endif   // QUEUE_UTILITY_H

