// import libraries
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>
#include "StandardConstants.h"
#include "File_Input_Utility.h"
#include "StudentUtility.h"
#include "SetUtilityDeux.h"
/*
Name: addItemAsData
Process: adds item as student data to set with name as key,
         does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           student name (const char *),
                           student ID number (int),
                           student gpa (double),
                           student gender (char)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: privateCopyString, isInSet, deepCopyStudentType
*/
bool addItemAsData( SetType *setData, const char *inName,
    int inId, char inGender, double inGpa ) 
    {
    // create temporary student struct
    StudentType tempStudent;
    // copy inName variable into name member for temporary student
        // function: privateCopyString
    privateCopyString( tempStudent.name, inName );
    // assign inId to studentId member for temporary student
    tempStudent.studentId = inId;
    // assign Ingender to gender member for temporary student
    tempStudent.gender = inGender;
    // assign inGpa to gpa member for temporary student
    tempStudent.gpa = inGpa;
	
    // check to see if duplicate name and its less than capacity
        // function: isInSet
    if( ( !isInSet( *setData, tempStudent ) ) &&
        ( setData->size < setData->capacity ) )
        {
         // copy the student data into the array
         deepCopyStudentData( &setData->array[ setData->size ], tempStudent);
         // decrement the size of array
         setData->size = setData->size + 1;
         // successfully copied data to array
         return true;
        }
    // unable to add item
    return false;
    }

/*
Name: addItemAsStruct
Process: adds item as student data to set with name as key,
         does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           new item (StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: addItemAsData
Note: One line of code
*/
bool addItemAsStruct( SetType *setData, const StudentType newValue )
    {
     // return the items as struct 
     return( addItemAsData(setData, newValue.name,
         newValue.studentId, newValue.gender, newValue.gpa ));
    }

/*
Name: clearSetData
Process: checks for allocated memory,
         clears set along with internal array, returns NULL
Function Input/Parameters: pointer to set data (SetType *)
Function Output/Parameters: none
Function Output/Returned: NULL (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: free
*/
SetType *clearSetData(SetType *toBeCleared)
    {
     // check to see if array is not clear
     if( toBeCleared != NULL )
       {
       // clear array
       free( toBeCleared->array );
       // clear struct
       free( toBeCleared );
       }
     // return NULL once set data is cleared
     return NULL;
    }

/*
Name: copySet
Process: copies all data of one set into other
Function Input/Parameters: source set (const SetType)
Function Output/Parameters: pointer to destination set (SetType *)
Function Output/Returned: none
Device Input/---: none
Device Output/---: none
Dependencies: deepCopyStudentData
*/
void copySet( SetType *dest, const SetType source )
  {
   // initialize variables/function
      // initialize array index variable
      int arrIndex = 0;

	// traverse source struct
   for ( arrIndex = 0; arrIndex < source.size; arrIndex++ )
     {
      // copy data from source to destination struct
         // function: deepCopyStudentData
		deepCopyStudentData( &dest->array[ arrIndex ],
         source.array[ arrIndex ] );
     }
   // give the source size to destination struct
   dest->size = source.size;
  }

/*
Name: createEmptySet
Process: creates new SetType along with array, and sets capacity and size
Function Input/Parameters: array capacity (int)
Function Output/Parameters: none
Function Output/Returned: pointer to newly created SetType (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: malloc
*/
SetType *createEmptySet( int capacitySet )
  {
   // allocate the memory location for the new struct
   SetType *newSet = ( SetType* )malloc(sizeof( SetType ) );

   // check to see if the new set is created
   // allocate the memory location for StudentType array
   newSet->array = ( StudentType * )malloc
      ( capacitySet * sizeof( StudentType ) );

   // set the capacity member of the new set to the given capacity
   newSet->capacity = capacitySet;

   // set the size member of newSet to zero
   newSet->size = 0; 
   // return newly created empty set
   return newSet;
  }

/*
Name: createIntersectionSet
Process: creates a new set that is the intersection of two given sets
         using name as key
Function Input/Parameters: pointers to two sets (const SetType *)
Function Output/Parameters: none
Function Output/Returned: pointer to new intersection set, 
                          as specified (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: createEmptySet, privateCompareStrings, addItemAsStruct
*/
SetType *createIntersectionSet( SetType *oneSet, SetType *otherSet )
  {
   // initialize functions/variables
      // initialize the intersection set
      SetType *intersectionSet;

      // initialize the capacity of the intersection set 
      // as the sum of both set sizes
      int intersectionCapacity = oneSet->size + otherSet->size;

      // initialize teh first set index variable
      int firstSetIndex = 0;

      // initialize the second set index variable
      int secondSetIndex = 0;

      // Create an empty intersectionSet 
      intersectionSet = createEmptySet( intersectionCap );

   // traverse the first set
   for( firstSetIndex = 0; firstSetIndex < oneSet->size; firstSetIndex++ )
     {

      // traverse the second set
      for( secondSetIndex = 0; secondSetIndex < otherSet->size;
         secondSetIndex++ )
        {
           
         // check if item that is in oneSet is in otherSet
            // function: privateCompareStrings
         if( privateCompareStrings( oneSet->array[ firstSetIndex ].name,
            otherSet->array[ secondSetIndex ].name ) == 0 )
           {
            // attempt to add item into intersectionSet
               // function: addItemAsStruct
            addItemAsStruct( intersectionSet, oneSet->array[ oneIndex ] );
           }
        }
     }
   // return intersectionSet
   return intersectionSet;
  }

/*
Name: createSetFromData
Process: gets file name, 
         if flag set to randomSet, uploads given file as is,
         otherwise, uploads data from specified file to locally created set, 
         randomly assigns specified number of unique values from local set 
         to output set, clears local set, returns output set         
Function Input/Parameters: number of random items to create (int)
Function Output/Parameters: none
Function Output/Returned: pointer to created set data (SetType *)
Device Input/HD: data uploaded as specified, file name input from keyboard
Device Output/monitor: prompt for file name
Dependencies: openInputFile, readStringToDelimiterFromFile, readIntegerFromFile,
              readCharacterFromFile, readDoubleFromFile, createEmptySet, 
              addItemAsData, addItemAsStruct, closeInputFile, getRandBetween,
              clearSetData
*/

SetType *createSetFromData( int numItemsToCreate, bool randomSet )
   {
    SetType *tempSet = NULL, *newSet = NULL;
    int index, randIndex, numItemsInFile;
    char fileName[ STD_STR_LEN ], inNameStr[ STD_STR_LEN ];
    int inId;
    char inGender;
    double inGpa;

    printf( "\nEnter file name: " );
    scanf( "%s", fileName );

    // load data into temp set
    if( openInputFile( fileName ) )
       {
        readStringToDelimiterFromFile( COLON, inNameStr );

        numItemsInFile = readIntegerFromFile();

        tempSet = createEmptySet( numItemsInFile );

        for( index = 0; index < numItemsInFile; index++ )
           {
            readStringToDelimiterFromFile( SEMICOLON, inNameStr );

            inId = readIntegerFromFile();
            readCharacterFromFile();

            inGender = readCharacterFromFile();
            readCharacterFromFile();

            inGpa = readDoubleFromFile();

            addItemAsData( tempSet, inNameStr, inId, inGender, inGpa );
           }

        closeInputFile();
       }

    else
       {
        return NULL;
       }

    if( numItemsToCreate < numItemsInFile )
       {
        tempSet->size = numItemsToCreate;
       }

    // protection from requesting more than available
    else
       {
        numItemsToCreate = numItemsInFile;
       }

    if( !randomSet )
       {
        return tempSet;
       }

    // create file to output
    newSet = createEmptySet( numItemsToCreate );

    // only allows unique values in new set
    index = 0;
    while( index < numItemsToCreate )
       {
        randIndex = privateGetRandBetween( 0, numItemsInFile - 1 );

        if( addItemAsStruct( newSet, tempSet->array[ randIndex ] ) )
           {
            index = index + 1;
           }
       }

    tempSet = clearSetData( tempSet );

    return newSet;
   }

/*
Name: createUnionSet
Process: creates a new set that is the union of two given sets
         using name as key
Function Input/Parameters: pointers to two sets (const SetType *)
Function Output/Parameters: none
Function Output/Returned: pointer to new union set, as specified (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: createEmptySet, copySet, addItemAsStruct
*/
SetType *createUnionSet( SetType *oneSet, SetType *otherSet )
  {
   // initialize functions/variables
      // initialize the union set
      SetType *unionSet;

      // initialize union set capacity variable to the sum of both set sizes
      int unionSetCapacity = oneSet->size + otherSet->size;

      // initialize the first set index variable
      int firstSetIndex = 0;

      // initialize the second set index variable
      int secondSetIndex = 0;

      // create an empty union set using its capacity
         // function: createEmptySet
      unionSet = createEmptySet( unionSetCapacity );

   // loop until one of the sets run out of values
   while( indexOne < oneSet->size && indexOther < otherSet->size )
     {
      // check if the first sets name is less than the second set
         // function: privateCompareStrings
      if( privateCompareStrings( oneSet->array[ firstSetIndex ].name,
         otherSet->array[ secondSetIndex ].name ) < 0 )
        {
         // if it is then add it to union set
            // function: addItemAsStruct
         addItemAsStruct( unionSet, oneSet->array[ firstSetIndex ] );

         // increment the first sets index
         firstSetIndex = firstSetIndex + 1;
        }

        // check if the first sets name is greater than the second set
      else if( privateCompareStrings( oneSet->array[ indexOne ].name,
         otherSet->array[ indexOther ].name ) > 0 )
        {
         // if it is greater, add it to the union set
            // function: addItemAsStruct
         addItemAsStruct( unionSet, otherSet->array[ secondSetIndex ] );

         // increment the second sets index
         secondSetIndex = secondSetIndex + 1;
        }

      // if the names are the same
      else
        {
         // add the item to union set
            // function: addItemAsStruct
            addItemAsStruct( unionSet, oneSet->array[ firstSetIndex ] );

         // increment the first set index
         firstSetIndex = firstSetIndex + 1;

         // increment the second set index
         secondSetIndex = secondSetIndex + 1;
        }
     }

   // if the first loop has values left loop through them
   while( firstSetIndex < oneSet->size )
     {
      // add the rest of the items to unionSet
         // function: addItemAsStruct
      addItemAsStruct( unionSet, oneSet->array[ firstSetIndex ] );

      // increment the first sets index
      firstSetIndex = firstSetIndex + 1;
     }

   // Loop until the second set is out of values
   // (third of three loops)
   while( indexOther < otherSet->size )
     {
      // add the rest of the second sets data
         // function: addItemAsStruct
      addItemAsStruct( unionSet, otherSet->array[ secondSetIndex ] );

      // increment the first sets index
      firstSetIndex = firstSetIndex + 1;
     }

    // Return the unionSet
    return unionSet;
  }

/*
Name: displaySet
Process: displays series of set values, or displays "Empty Set" if no values
Function Input/Parameters: name of set array (const char *),
                           set data (const SetType)
Function Output/Parameters: none
Function Output/Returned: none
Device Input/---: none
Device Output/monitor: data displayed as specified
Dependencies: printf, studentDataToString
*/
void displaySet(const char *setName, const SetType setData)
  {
   // initialize functions/variables
      // initialize temporary string
      char tempString[MAX_STR_LEN];

      // initialize index variable
		int arrayIndex = 0;

   // tell the user which set is being displayed
   printf( "\nSet Data Display %c %s\n\n", DASH, setName );

   // check whether the set is empty
   if( setData.size == 0 )
     {
      // tell the user the set is empty
      printf( "Empty Set\n" );
     }

	// if the array isn't empty
	else
     {
      // traverse through the set
      for( arrayIndex = 0; arrayIndex < setData.size; arrayIndex++ )
        {
         // write the student data to temp string
            // function: studentDataToString
         studentDataToString( tempString, setData.array[ arrIndex ] );
         // print the data
         printf( "%3d) %s\n", arrIndex + 1, tempString );
        }
      // print newline
      printf( "\n" );
     }
  } 

/*
Name: isInSet
Process: searches for given student data in set using name as key,
         if found, returns true, otherwise returns false,
         must return found result immediately upon locating value
Function Input/Parameters: set (const SetType), search value (const StudentType)
Function Output/Parameters: none
Function Output/Returned: Boolean result of test, as specified
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings
*/
bool isInSet(const SetType testSet, const StudentType testData) 
  { 
   // initialize functions/variables
      // initialize array index variable
      int arrIndex = 0;
   // traverse through the set
   for( arrIndex = 0; arrIndex < testSet.size; arrIndex++ ) 
     {
      // compare the name in test data to test set
      if( privateCompareStrings( testData.name,
         testSet.array[ arrIndex ].name ) == 0 )
        {
         // the name has been found
         return true;
        }
		}
   // No match found
	return false;
}

/*
Name: isSubsetOfOther
Process: tests if first parameter is subset of second parameter
         using name as key,
         if so, returns true, otherwise, returns false
Function Input/Parameters: possible subset (const SetType *), 
                           other (const SetType *)
Function Output/Parameters: none
Function Output/Returned: Boolean result of test, as specified
Device Input/---: none
Device Output/---: none
Dependencies: isInSet
*/
bool isSubsetOfOther( const SetType *possibleSubSet, const SetType *other )
   {
    // initialize functions/variables
      // initialize array index variable
      int arrIndex = 0;
      
   // traverse the possible subset
   for( arrIndex = 0; arrIndex < possibleSubSet->size - 1; arrIndex++ )
      {
      // check to see if key is not in set
      if( !isInSet( *other, possibleSubSet->array[ arrIndex ] ) )
         {
            // return false since key was not found
            return false;
         }
      }
   // otherwise return true
   return true;
   }
   
/*
Name: runMerge
Process: sorts data between two indices (inclusive) using name as key
         by merging them from two sides of an array;
         one array is dynamically created within the function, 
         data is copied into that array,
         and then fed back into the original array using a merge operation
Function input/parameters: pointer to set data (SetType *),
                           low and high indices (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: malloc, deepCopyStudentData, privateCompareStrings, free
Note: Must create and deallocate inside StudentType array
*/
void runMerge( SetType *setData, int lowIndex, int midIndex, int highIndex )
   {
    // initialize functions/variables
      // initialize temporary student struct
      StudentType *tempArray = NULL;
      // initialize array index variable
      int arrIndex = 0;
      // initialize the left index start variable
      int leftIndex = 0;
      // initialize the right index start variable
      int rightIndex = midIndex + 1 - lowIndex;
      // initialize the source index variable
      int sourceIndex = lowIndex;
   
    // First, using the index parameters, find the capacity needed
    // for the local array and create the array
    // Only one array is created
    int capacity = highIndex - lowIndex + 1;
    // allocate the temporary array memory
    tempArray = (StudentType *)malloc(capacity * sizeof(StudentType));

    // Next, load the data from the source (parameter) array
    // (between the two indices, inclusive)
    // into the newly created local array
    for( arrIndex = 0; arrIndex < capacity; arrIndex++ )
       {
        deepCopyStudentData( &tempArray[ arrIndex ], setData->array[ lowIndex + arrIndex ] );
       }

    // Loop until either the left or right side group is out of values
    // (first of three loops)
    while (leftIndex < ( midIndex - lowIndex + 1 ) && rightIndex < ( highIndex - lowIndex + 1 ) )
       {
        // check if the first available value in the left group
        // is less than the first avaliable value in the right group
           // function: privateCompareStrings
        if ( privateCompareStrings(tempArray[leftIndex].name, tempArray[rightIndex].name) < 0 )
           {
            // Assign the first available left value
            // to the source array's first available element
              // function: deepCopyStudentData
            deepCopyStudentData(&setData->array[sourceIndex], tempArray[ leftIndex ] );

            // Increment the left group index
            leftIndex = leftIndex + 1;
           }

        // Otherwise, assume the right group's first available value
        // is less
        else
           {
            // Assign the first available right value
            // to the source array's first available element
              // function: deepCopyStudentData
            deepCopyStudentData( &setData->array[ sourceIndex ], tempArray[ rightIndex ] );

            // Increment the right group index
            rightIndex = rightIndex + 1;
           }

        // Increment the index for the source array
         sourceIndex = sourceIndex + 1;

       // End comparison loop
       }

    // Loop until the left side group is out of values
    // (second of three loops)
    while( leftIndex < ( midIndex - lowIndex + 1 ) )
       {
        // Assign the first available left value
        // to the source array's first available element
           // function: deepCopyStudentData
        deepCopyStudentData( &setData->array[ sourceIndex ], tempArray[ leftIndex ] );

        // Increment the left group index
        leftIndex = leftIndex + 1;

        // Increment the source array's index
        sourceIndex = sourceIndex + 1;

       // End left side clean out loop
       }

    // Loop until the right side group is out of values
    // (third of three loops)
    while (rightIndex < (highIndex - lowIndex + 1))
       {
        // Assign the first right value to the source array's
        // first available element
           // function: deepCopyStudentData
        deepCopyStudentData(&setData->array[ sourceIndex ], tempArray[rightIndex]);

        // Increment the right group index
        rightIndex = rightIndex + 1;

        // Increment the source array's index
        sourceIndex = sourceIndex + 1;

       // End right side clean out loop
       }

    // Deallocate the array
       // function: free
    free(tempArray);
   }
   

/*
Name: runMergeSort
Process: calls helper to sort data using merge sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           number of items (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runMergeSortHelper
*/
void runMergeSort( SetType *setData )
   {
   runMergeSortHelper( setData, 0, setData->size - 1 );
   }

/*
Name: runMergeSortHelper
Process: sorts data using merge sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           number of items (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runMerge, runMergeSortHelper (recursively)
*/
void runMergeSortHelper( SetType *setData, int lowIndex, int highIndex )
   {
   // initialize functions/variables
      // intitialize middle index
      int middleIndex = (highIndex + lowIndex) / 2;
   // first, make sure the lower index of the list
   // is less than the upper index of the list
   if( lowIndex < highIndex )
      {
       // call the merge sort process for the left side of the list
       runMergeSortHelper( setData, lowIndex, middleIndex );
       // call the merge sort process for the right side of the list
       runMergeSortHelper( setData, middleIndex + 1, highIndex);
       // then merge the two lists back together as sorted data
       runMerge( setData, lowIndex, middleIndex, highIndex );
      }
   }

/*
Name: runPartition
Process: partitions an set array segment between two indices (inclusive)
         using name as key;
         the first element in the array segment is used as a partition value,
         and all of the values less than the partition value are moved
         to the left of the array segment, all of the values greater than 
         the partition value are moved to the right of the array segment,
         and the partition value is placed between them;
         then the final location (index) of the partition value is returned
Function input/parameters: pointer to set data (SetType *),
                           low and high indices (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: partition (or pivot) location (int)
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, swapValues
Note: Must use first element in array segment as pivot value
*/
int runPartition( SetType *setData, int lowIndex, int highIndex )
   {
    // initialize functions/variables
      // initialize pivot value variable
      int pivotValue = lowIndex;
      // initialize pivot index variable
      int pivotIndex = lowIndex;
      // initialize working index variable
      int workingIndex = 0;
      
    // Start a loop across the the array segment
    // from the low index to the high index, inclusive
    // This will use the working index
    for( workingIndex = lowIndex + 1; workingIndex <= highIndex; workingIndex++ )
      {
       // check if the value at the current working index
       // is less than the original pivot value
       if( privateCompareStrings( setData->array[ workingIndex ].name, setData->array[ pivotValue ].name ) < 0 )
         {
           // increment the pivot index
           pivotIndex = pivotIndex + 1;
           // swap the value at the working index
           // with the value at the pivot index
           swapValues( &setData->array[ workingIndex ], &setData->array[ pivotIndex ] );
         }
       // end working loop 
      }
    // Swap the original pivot value (at the low index)
    // with the value at the current pivot index
    swapValues( &setData->array[ pivotValue ], &setData->array[ pivotIndex ] );

    // return the pivot index
    return pivotIndex;
   }

/*
Name: runQuickSort
Process: calls helper to sort data using quick sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           number of items (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runQuickSortHelper
*/
void runQuickSort( SetType *setData )
   {
    runQuickSortHelper( setData, 0, setData->size - 1 );
   }

/*
Name: runQuickSortHelper
Process: sorts data using quick sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           low and high indices (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runPartition, runQuickSortHelper (recursively)
*/
void runQuickSortHelper( SetType *setData, int lowIndex, int highIndex )
   {
   // initialize functions/variables
      // initialize pivot index variable
      int pivotIndex = 0;
      
   // first, make sure the lower index of the list
   // is less than the upper index of the list
   if( lowIndex < highIndex )
      {
       // call the partition process to set the pivot value
       // and get its index
       pivotIndex = runPartition( setData, lowIndex, highIndex );
       // call the quick sort process for the left side of the list
       // to the left of the pivot index
       runQuickSortHelper( setData, lowIndex, pivotIndex - 1 );
       // call the quick sort process for the right side of the list
       // to the right of the pivot index
       runQuickSortHelper( setData, pivotIndex + 1, highIndex );
      }
   }

/*
Name: swapValues
Process: swaps data between two set data quantities (StudentTypes)
Function input/parameters: pointers to two StudentType values (StudentType *)
Function output/parameters: pointers to updated StudentType values 
                                                                 (StudentType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: deepCopyStudentData
*/
void swapValues( StudentType *one, StudentType *other )
   {
	// initialize temporary student struct
	StudentType tempStr;

	// copy data from one to tempStr
	   // function: deepCopyStudentData
	deepCopyStudentData( &tempStr, *one );

	// copy other into one
	   // function: deepCopyStudentData
	deepCopyStudentData( one, *other );

	// copy tempStr into other
	   // function: deepCopyStudentData
	deepCopyStudentData( other, tempStr );
   }