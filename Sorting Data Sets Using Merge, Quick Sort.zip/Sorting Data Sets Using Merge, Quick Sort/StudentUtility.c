// Header files ///////////////////////////////////////////////////////////////
#include "StudentUtility.h"

// global constants ////////////////////////////////////////////////////////////

   // None

/*
Name: createStudentTypeStruct
Process: copies one StudentType item into another
Function input/parameters: source data (const StudentType)
Function output/parameters: destination data (StudentType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
void createStudentTypeStruct( StudentType *newStudent, char *inName,
                                        int inId, char inGender, double inGpa )
   {
    privateCopyString( newStudent->name, inName );
    newStudent->studentId = inId;
    newStudent->gender = inGender;
    newStudent->gpa = inGpa;
   }

/*
Name: deepCopyStudentData
Process: copies one StudentType item into another
Function input/parameters: source data (const StudentType)
Function output/parameters: destination data (StudentType *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: privateCopyString
*/
void deepCopyStudentData( StudentType *dest, StudentType source )
   {
    privateCopyString( dest->name, source.name );
    dest->studentId = source.studentId;
    dest->gender = source.gender;
    dest->gpa = source.gpa;
   }

/*
Name: privateCompareStrings
Process: compares strings from left to right, letter by letter,
         if left string greater than right string, returns greater than zero,
         if left string less than right string, returns less than zero,
         if all string characters are equal and the string lengths are the same,
         returns zero, 
         otherwise returns left to right difference in string lengths
Function input/parameters: left and right strings (char *)
Function output/parameters: none
Function output/returned: returned value as specified (int)
Device input/---: none
Device output/---: none
Dependencies: privateGetStringLength
Note: no literal constants (e.g., -1, 1, etc.) 
      may be returned from this function
*/
int privateCompareStrings( const char *leftStr, const char *rightStr )
   {
    int diff, index = 0;
    int leftStrLen = privateGetStringLength( leftStr );
    int rightStrLen = privateGetStringLength( rightStr );

    while( index < leftStrLen && index < rightStrLen )
       {
        diff = leftStr[ index ] - rightStr[ index ];

        if( diff != 0 )
           {
            return diff;
           }

        index = index + 1;
       }

    return leftStrLen - rightStrLen;
   }

/*
Name: privateCopyString
Process: utility function - copies one string into another
Function input/parameters: source data (char *)
Function output/parameters: destination data (char *)
Function output/returned: none
Device input/ ---: none
Device output/ ---: none
Dependencies: none
*/
void privateCopyString( char *dest, const char *source )
   {
    int index = 0;

    while( source[ index ] != NULL_CHAR )
       {
        dest[ index ] = source[ index ];

        index++;
       }

    dest[ index ] = NULL_CHAR;
   }

/*
Name: privateGetRandBetween
Process: generates and returns a random value
         between two given values, inclusive
Function Input/Parameters: low, high limits (int)
Function Output/Parameters: none
Function Output/Returned: random value as specified
Device Input/---: none
Device Output/---: none
Dependencies: rand
*/
int privateGetRandBetween( int lowVal, int highVal )
   {
    int range = highVal - lowVal + 1;

    return rand() % range + lowVal;
   }

/*
Name: privateGetStringLength
Process: returns length of c-style string
Function input/parameters: c-style string (char *)
Function output/parameters: none
Function output/returned: length of string (int)
Device input/---: none
Device output/---: none
Dependencies: none
*/
int privateGetStringLength( const char *str )
   {
    int index = 0;

    while( str[ index ] != NULL_CHAR )
       {
        index = index + 1;
       }

    return index;
   }

/*
Name: studentDataToString
Process: creates display string from all object data
Method input/parameters: student data (const StudentType )
Method output/parameters: pointer to return string (char *)
Method output/returned: none
Device input/keyboard: none
Device output/monitor: none
Dependencies: sprintf
*/
void studentDataToString( char *outString, StudentType toDisplay )
   {
    sprintf( outString, "Nm: %s, Id: %d, Gndr: %c, GPA: %5.4f",
                                                        toDisplay.name,
                                                        toDisplay.studentId,
                                                        toDisplay.gender,
                                                        toDisplay.gpa );

   }


