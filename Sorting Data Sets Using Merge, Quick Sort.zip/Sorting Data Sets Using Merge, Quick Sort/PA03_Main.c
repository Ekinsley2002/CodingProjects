#include "SetUtilityDeux.h"

// main function
int main( int argc, char **argv )
   {
    // initialize function/variables

       // create set pointers
       SetType *firstTestSet = NULL, *secondTestSet = NULL;
       SetType *thirdTestSet = NULL, *fourthTestSet = NULL;
       SetType *fifthTestSet = NULL;
       char tempStr[ MIN_STR_LEN ];
       bool randomFlag;
       int numItems;

       // seed random generator
       srand( time( NULL ) );

       // show title
       printf( "\nSET TEST PROGRAM\n" );
       printf( "================\n\n" );

    // processing

       // upload data for merge sort - randomly selected
       printf( "Uploading first data set\n" );
       randomFlag = true; numItems = 30;
       firstTestSet = createSetFromData( numItems, randomFlag );

       if( firstTestSet != NULL )
          {
           // create copy of first test set for later use
           fifthTestSet = createEmptySet( firstTestSet->size );

           copySet( fifthTestSet, *firstTestSet );

           // display data
           displaySet( "Data set before merge sort", *firstTestSet );
          
           // run bubble sort
           runMergeSort( firstTestSet );
   
           // display data
           displaySet( "Data set after merge sort", *firstTestSet );
          }

       else
          {
           printf( "\nFailure of first data set to upload\n\n" );
          }

        // upload data for quick sort - randomly selected
       printf( "Uploading second data set\n" );
       randomFlag = true; numItems = 40;
       secondTestSet = createSetFromData( numItems, randomFlag );

       if( secondTestSet != NULL )
          {
           // display data
           displaySet( "Data set before quick sort", *secondTestSet );
          
           // run insertion sort
           runQuickSort( secondTestSet );
   
           // display data
           displaySet( "Data set after quick sort", *secondTestSet );
          }

       else
          {
           printf( "\nFailure of second data set to upload\n\n" );
          }

       // check for both uploads successful
       if( firstTestSet != NULL && secondTestSet != NULL )
          {
           printf( "Creating Union from two sets\n" );
           thirdTestSet = createUnionSet( firstTestSet, secondTestSet );

           // display data
           displaySet( "Union data found", *thirdTestSet );

           // create union
           printf( "Creating Intersection from two sets\n" );
           fourthTestSet = createIntersectionSet( firstTestSet, secondTestSet );

           // display data
           displaySet( "Intersection data found", *fourthTestSet );

           privateCopyString( tempStr, " is not " );

           if( isSubsetOfOther( firstTestSet, secondTestSet ) )
              {
               privateCopyString( tempStr, " is " );
              }
if( !prevRotated )
           {
            rotateBox( &containerBox->insideBoxList[ currentBox ] );
            prevRotated = true;
           }
           printf( "The first set%sa subset of the second set \n", tempStr );

           fifthTestSet->size = fifthTestSet->size / 2;

           runQuickSort( fifthTestSet );

           displaySet( "Fifth test set", *fifthTestSet );

           privateCopyString( tempStr, " is not " );

           if( isSubsetOfOther( fifthTestSet, firstTestSet ) )
              {
               privateCopyString( tempStr, " is " );
              }

           printf( "The fifth set%sa subset of the first set \n", tempStr );
          }

    // end program

        // clear test set data
        firstTestSet = clearSetData( firstTestSet );
        secondTestSet = clearSetData( secondTestSet );
        thirdTestSet = clearSetData( thirdTestSet );
        fourthTestSet = clearSetData( fourthTestSet );
        fifthTestSet = clearSetData( fifthTestSet );

        // display end
        printf( "\nEnd Program\n" );

        // return success
        return 0;
   }



