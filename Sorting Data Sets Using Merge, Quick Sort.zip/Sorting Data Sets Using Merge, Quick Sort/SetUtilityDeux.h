#ifndef SET_UTILITIES_H
#define SET_UTILITIES_H

// headers/libraries
#include <stdio.h>
#include <stdbool.h>
#include "StandardConstants.h"
#include "File_Input_Utility.h"
#include "StudentUtility.h"

typedef struct SetStruct
   {
    StudentType *array;

    int capacity;

    int size;
   } SetType;

// prototypes

/*
Name: addItemAsData
Process: adds item as student data to set with name as key,
         does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           student name (const char *),
                           student ID number (int),
                           student gpa (double),
                           student gender (char)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: privateCopyString, isInSet, deepCopyStudentType
*/
bool addItemAsData( SetType *setData, const char *inName, int inId,
                                                  char inGender, double inGpa );

/*
Name: addItemAsStruct
Process: adds item as student data to set with name as key,
         does not allow duplicates,
         does not allow data to be added to full list, updates size,
         returns true if successful, false otherwise
Function Input/Parameters: pointer to set data (SetType *), 
                           new item (StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of process (bool)
Device Input/---: none
Device Output/---: none
Dependencies: addItemAsData
Note: One line of code
*/
bool addItemAsStruct( SetType *setData, const StudentType newValue );

/*
Name: clearSetData
Process: checks for allocated memory,
         clears set along with internal array, returns NULL
Function Input/Parameters: pointer to set data (SetType *)
Function Output/Parameters: none
Function Output/Returned: NULL (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: free
*/
SetType *clearSetData( SetType *toBeCleared );

/*
Name: copySet
Process: copies all data of one set into other
Function Input/Parameters: source set (const SetType)
Function Output/Parameters: pointer to destination set (SetType *)
Function Output/Returned: none
Device Input/---: none
Device Output/---: none
Dependencies: deepCopyStudentData
*/
void copySet( SetType *dest, const SetType source );

/*
Name: createEmptySet
Process: creates new SetType along with array, and sets capacity and size
Function Input/Parameters: array capacity (int)
Function Output/Parameters: none
Function Output/Returned: pointer to newly created SetType (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: malloc
*/
SetType *createEmptySet( int capacitySet );

/*
Name: createIntersectionSet
Process: creates a new set that is the intersection of two given sets
         using name as key
Function Input/Parameters: pointers to two sets (const SetType *)
Function Output/Parameters: none
Function Output/Returned: pointer to new intersection set, 
                          as specified (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: createEmptySet, privateCompareStrings, addItemAsStruct
*/
SetType *createIntersectionSet( SetType *oneSet, SetType *otherSet );

/*
Name: createSetFromData
Process: gets file name, 
         if flag set to randomSet, uploads given file as is,
         otherwise, uploads data from specified file to locally created set, 
         randomly assigns specified number of unique values from local set 
         to output set, clears local set, returns output set         
Function Input/Parameters: number of random items to create (int)
Function Output/Parameters: none
Function Output/Returned: pointer to created set data (SetType *)
Device Input/HD: data uploaded as specified, file name input from keyboard
Device Output/monitor: prompt for file name
Dependencies: openInputFile, readStringToDelimiterFromFile, readIntegerFromFile,
              readCharacterFromFile, readDoubleFromFile, createEmptySet, 
              addItemAsData, addItemAsStruct, closeInputFile, getRandBetween,
              clearSetData
*/
SetType *createSetFromData( int numItemsToCreate, bool randomSet );

/*
Name: createUnionSet
Process: creates a new set that is the union of two given sets
         using name as key
Function Input/Parameters: pointers to two sets (const SetType *)
Function Output/Parameters: none
Function Output/Returned: pointer to new union set, as specified (SetType *)
Device Input/---: none
Device Output/---: none
Dependencies: createEmptySet, copySet, addItemAsStruct
*/
SetType *createUnionSet( SetType *oneSet, SetType *otherSet );

/*
Name: deleteItem
Process: searches for item using name as key, deletes if found,
         moves array data down by one from above the removed value
         test loop must stop as soon as item is found (if it is found),
         updates size as needed,
         returns true if successful, false otherwise         
Function Input/Parameters: pointer to set data (SetType *), 
                           item to delete (const StudentType)
Function Output/Parameters: updated pointer to set data (SetType *)
Function Output/Returned: Boolean result of operation (bool)
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings, deepCopyStudentData
*/
bool deleteItem( SetType *setData, const StudentType itemToDelete );

/*
Name: displaySet
Process: displays series of set values, or displays "Empty Set" if no values
Function Input/Parameters: name of set array (const char *),
                           set data (const SetType)
Function Output/Parameters: none
Function Output/Returned: none
Device Input/---: none
Device Output/monitor: data displayed as specified
Dependencies: printf, studentDataToString
*/
void displaySet( const char *setName, const SetType setData );

/*
Name: isInSet
Process: searches for given student data in set using name as key,
         if found, returns true, otherwise returns false,
         must return found result immediately upon locating value
Function Input/Parameters: set (const SetType), search value (const StudentType)
Function Output/Parameters: none
Function Output/Returned: Boolean result of test, as specified
Device Input/---: none
Device Output/---: none
Dependencies: privateCompareStrings
*/
bool isInSet( const SetType testSet, const StudentType testData );

/*
Name: isSubsetOfOther
Process: tests if first parameter is subset of second parameter
         using name as key,
         if so, returns true, otherwise, returns false
Function Input/Parameters: possible subset (const SetType *), 
                           other (const SetType *)
Function Output/Parameters: none
Function Output/Returned: Boolean result of test, as specified
Device Input/---: none
Device Output/---: none
Dependencies: isInSet
*/
bool isSubsetOfOther( const SetType *possibleSubSet, const SetType *other );

/*
Name: runMerge
Process: sorts data between two indices (inclusive) using name as key
         by merging them from two sides of an array;
         one array is dynamically created within the function, 
         data is copied into that array,
         and then fed back into the original array using a merge operation
Function input/parameters: pointer to set data (SetType *),
                           low and high indices (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: malloc, deepCopyStudentData, privateCompareStrings, free
Note: Must create and deallocate inside StudentType array
*/
void runMerge( SetType *setData, int lowIndex, int midIndex, int highIndex );

/*
Name: runMergeSort
Process: calls helper to sort data using merge sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           number of items (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runMergeSortHelper
*/
void runMergeSort( SetType *setData );

/*
Name: runMergeSortHelper
Process: sorts data using merge sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           number of items (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runMerge, runMergeSortHelper (recursively)
*/
void runMergeSortHelper( SetType *setData, int lowIndex, int highIndex );

/*
Name: runPartition
Process: partitions an set array segment between two indices (inclusive)
         using name as key;
         the first element in the array segment is used as a partition value,
         and all of the values less than the partition value are moved
         to the left of the array segment, all of the values greater than 
         the partition value are moved to the right of the array segment,
         and the partition value is placed between them;
         then the final location (index) of the partition value is returned
Function input/parameters: pointer to set data (SetType *),
                           low and high indices (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: partition (or pivot) location (int)
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, swapValues
Note: Must use first element in array segment as pivot value
*/
int runPartition( SetType *setData, int lowIndex, int highIndex );

/*
Name: runQuickSort
Process: calls helper to sort data using quick sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           number of items (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runQuickSortHelper
*/
void runQuickSort( SetType *setData );

/*
Name: runQuickSortHelper
Process: sorts data using quick sort algorithm with name key
Function input/parameters: pointer to set data (SetType *),
                           low and high indices (int)
Function output/parameters: pointer to updated set data (SetType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: runPartition, runQuickSortHelper (recursively)
*/
void runQuickSortHelper( SetType *setData, int lowIndex, int highIndex );

/*
Name: swapValues
Process: swaps data between two set data quantities (StudentTypes)
Function input/parameters: pointers to two StudentType values (StudentType *)
Function output/parameters: pointers to updated StudentType values 
                                                                 (StudentType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: deepCopyStudentData
*/
void swapValues( StudentType *one, StudentType *other );


#endif     // SET_UTILITIES_H


