#include "HeapUtility.h"

/*
Name: accessPriority 
Process: static initial array pointer provided and set to NULL,
         and static initial size set to zero
         Priority Codes:
         INITIALIZE_PRIORITY_ENGINE - if array has not 
                                      been previously initialized,
                                      sets up priority generating system
                                      with possible values up 
                                      to twice as much as the given
                                      initial capacity provided,
                                      returns NON_VALID_PRIORITY
         GET_PRIORITY - generates a unique value between 1 and twice the
                        initial given capacity, returns value
         CLEAR_PRIORITY_ENGINE - if array has been initialized,
                                 deallocates dynamic memory created
                                 for the function operation,
                                 resets static array pointer to NULL,
                                 and size to zero,
                                 returns NON_VALID_PRIORITY
Function input/parameters: control code as specified (PriorityCode),
                           given initial capacity (int)
Function output/parameters: none
Function output/returned: value as specified (int)
Device input/---: none
Device output/---: none
Dependencies: getRandBetween, malloc w/sizeof, isInArray, free
*/
int accessPriority( PriorityCode code, int initialCapacity )
  {
   // intitialize functions/variables
      // initialize static priority array
      static int *priorityArray = NULL;
      // initialize priority array size
      static int prioritySize = 0;
      // initialize return value
      int returnVal = NON_VALID_PRIORITY;
      // initialize double capacity variable
      int doubleCap = initialCapacity * 2;
      
   // check if the code is to initialize engine and if array is empty
   if( code == INITIALIZE_PRIORITY_ENGINE && priorityArray == NULL )
     {
      // create an array with double capacity
      priorityArray = ( int * )malloc( doubleCap * sizeof( int ) );
     }
     
   // check if the code is get priority and if its not empty
   else if( code == GET_PRIORITY && priorityArray != NULL )
     {
      // start loop
      do
        {
         // generate test value
         returnVal = privateGetRandBetween( 1, doubleCap );
        }
      // continue loop if test value found in array
      while( privateIsInArray( priorityArray, returnVal, prioritySize ) );
         
      // set value into the array
      priorityArray[ prioritySize ] = returnVal;
      // increment prioritySize of array
      prioritySize = prioritySize + 1;
      // set the returnVal to return value
      return returnVal;
     }
     
   // check if the code is to clear priority and the array is empty
   else if( code == CLEAR_PRIORITY_ENGINE && priorityArray != NULL )
     {
      free( priorityArray );
      // set array to NULL
      priorityArray = NULL;
      // set size to zero
      prioritySize = 0;
     }
   return returnVal;
  }

/*
Name: addHeapItem
Process: adds item to heap with unique priority,
         reports action, updates size,
         calls bubble up to reset heap
Function input/parameters: heap data (HeapType *), patient name (char *)
Function output/parameters: updated heap data (HeapType *)
Function output/returned: none
Device input/---: none
Device output/monitor: patient addition action displayed 
Dependencies: setPatientFromData, printf, accessPriority,
              privateBubbleUp (recursively)
*/
void addHeapItem( HeapType *heap, const char *nameSet )
  {
   // initialize variables
      // intialize priority variable
      int priority;
      
   // set priority
   priority = accessPriority( GET_PRIORITY, heap->capacity );
   // print information based on display flag
   if( heap->displayFlag )
     {
      printf( "\n\nAdding new patient: %s, with priority %d: \n",
                                                           nameSet, priority );
     }
   // add item to heap
   setPatientFromData( &heap->array[ heap->size ], nameSet, priority );
   // increment heap size
   heap->size = heap->size + 1;
   // call private bubble up with size - 1
   privateBubbleUp( heap, heap->size - 1 );
  }

/*
Name: clearHeap
Process: frees heap array, sets all other data members appropriately,
         clears priority generating function
Function input/parameters: heap data (HeapType *)
Function output/parameters: none
Function output/returned: pointer to cleared heap type (NULL)
Device input/---: none
Device output/---: none
Dependencies: free, accessPriority
*/
HeapType *clearHeap( HeapType *heap )
  {
   // check if heap is not empty
   if( heap != NULL )
     {
      // free the heap array
      free( heap->array );
      // free priority array
      accessPriority( CLEAR_PRIORITY_ENGINE, heap->capacity );
      // free the heap
      free( heap );
      // set heap size/capacity to 0
      heap->size = 0;
      heap->capacity = 0;
     }
   return NULL;
  }

/*
Name: findHeapTreeHeight
Process: recursively calculates the height of the virtual tree used in the heap
Function input/parameters: number of items (int)
Function output/parameters: none
Function output/returned: height of virtual tree (int)
Device input/---: none
Device output/---: none
Dependencies: findHeapTreeHeight (recursively)
*/
int findHeapTreeHeight( int heapSize )
  {
   // check if the tree is not empty
   if( heapSize > 1 )
     {
      // recurse down tree, then back up counting recursions
      return findHeapTreeHeight( heapSize / 2 ) + 1;
     }
   // begin back track
   return 0;
  }

/*
Name: getDataFromFile
Process: initializes heap,
         uploads data from file with unknown number of data sets,
         if heap display flag set, 
         shows upload operation and sets heap display flag,
         returns true if data found and uploaded, false otherwise,
         priority is acquired and applied to each data item as it is input
Function input/parameters: file name (const char *),
                           initial capacity (int),
                           display flag (bool)
Function output/parameters: none
Function output/returned: pointer to newly created heap (HeapType *),
                          or NULL if upload failed
Device input/hard drive: data from HD
Device output/monitor: if display flag set, displays uploaded values
Dependencies: openInputFile, initializeHeap, printf, 
              readStringToDelimiterFromFile, readStringToLineEndFromFile, 
              addHeapItem, checkForEndOfInputFile, closeInputFile
*/
HeapType *getDataFromFile( const char *fileName, 
                                         int initialCapacity, bool verbose )
  {
   // initialize variables IMPORTANT SET HEAP DISPLAY FLAG
      // initialize heap
      HeapType *newHeap;
      // initialize name string
      char nameStr[ STD_STR_LEN ];
      // intialize temp string
      char tempStr[ STD_STR_LEN ];
      // initialize number variables
      int numberIndex = 1;
      
  // check/open file
   if( openInputFile( fileName ) )
     {
      // create new heap
      newHeap = initializeHeap( initialCapacity );
      // set the display flag
      setDisplayFlag( newHeap, verbose );
      
      printf("\nBegin Loading Data From File . . .\n");
      // set prime name
      readStringToDelimiterFromFile( SEMICOLON, nameStr );
      // while not at the end of file
      while( !checkForEndOfInputFile() )
        {
         // read patient name and store
         printf( "\n\n%d) Patient Name: %s", numberIndex, nameStr );
         readStringToLineEndFromFile( tempStr );
         addHeapItem( newHeap, nameStr );
         numberIndex = numberIndex + 1;
         readStringToDelimiterFromFile( SEMICOLON, nameStr );
        }
      // close the file
      closeInputFile( fileName );
      
      printf( "\n\n\t\t\t. . . End Loading Data From File\n\n" );
      return newHeap;
     }
   // otherwise return NULL
   return NULL;
  }

/*
Name: initializeHeap
Process: initializes heap, creates heap array from given capacity,
         sets other heap members appropriately, 
         initializes the priority generating engine,
         display flag is initially set to false
Function input/parameters: initial capacity (int)
Function output/parameters: none
Function output/returned: pointer to created heap (HeapType *)
Device input/---: none
Device output/---: none
Dependencies: malloc, sizeof, accessPriority
*/
HeapType *initializeHeap( int initialCapacity )
  {
   // initialize variables
      // initialize heap struct
      HeapType *newHeap;
      
   // allocate memeory for new heap
   newHeap = ( HeapType * )malloc( sizeof( HeapType ) );
   // set the capacity of new heap to initial capacity variable
   newHeap->capacity = initialCapacity;
   // set new heap size
   newHeap->size = 0;
   // set new heap display flag
   newHeap->displayFlag = false;
   // allocate memory for heap array
   newHeap->array = ( PatientType * )malloc
                                   ( initialCapacity * sizeof( PatientType ) );
   // initialize priority array
   accessPriority( INITIALIZE_PRIORITY_ENGINE, initialCapacity );
   // return new heap
   return newHeap;
  }

/*
Name: isEmpty
Process: reports if heap is empty
Function input/parameters: heap data (const HeapType)
Function output/parameters: none
Function output/returned: Boolean result of test (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool isEmpty( const HeapType heap )
  {
   // return boolean comparison of heap size to zero
   return ( heap.size == 0 );
  }

/*
Name: privateBubbleUp
Process: recursively rebalances heap after new data is added for max heap,
         displays bubble up actions if heap display flag set
Function input/parameters: heap data (HeapType *), current index (int)
Function output/parameters: updated heap data (HeapType *)
Function output/returned: none
Device input/---: none
Device output/monitor: bubble up operations displayed as specified
Dependencies: setPatientFromStruct, comparePriorities, setPatientToString
              privateBubbleUp (recursively), 
              other appropriate functions acceptable
Note: 1) Swapping operation may not exceed two lines
      2) Comparison process may not use array elements
*/
void privateBubbleUp( HeapType *heap, int currentIndex )
  {
   // initialize variables
      // initialize parent index
      int parentIndex;
      // intitialize temporary string variable
      char parentStr[ STD_STR_LEN ];
      // intitialize temporary string variable
      char childStr[ STD_STR_LEN ];
      // initialize parent data struct
      PatientType parentData;
      // initialize child data struct
      PatientType childData;
   
   // check if the current index is greater than 0
   if( currentIndex > 0 )
     {
      // calculate parents index
      parentIndex = (currentIndex - 1) / 2;
      // set parent data to array at parent index
      setPatientFromStruct( &parentData, heap->array[ parentIndex ] );
      // set child data to array at child index
      setPatientFromStruct( &childData, heap->array[ currentIndex ] );
      // check if the current index value is greater than parents
      if( comparePriorities( childData, parentData ) > 0)
        {
         // format parent data
         setPatientToString( parentStr, heap->array[ parentIndex ] );
         // format child data
         setPatientToString( childStr, heap->array[ currentIndex ] );
         // swap parent data with child data
         setPatientFromStruct( &heap->array[ parentIndex ], childData );
         setPatientFromStruct( &heap->array[ currentIndex ], parentData );
         
         // check heaps display flag
         if( heap->displayFlag )
           {
            // display information
            printf( "    - Bubble up:" );
            printf( "\n     - Swapping parent: %s", parentStr );
            printf( "\n       with child: %s", childStr );
           }
         // call function recursively with parent index
         privateBubbleUp( heap, parentIndex );
        }
     }
  }

/*
Name: privateTrickleDown
Process: recursively rebalances heap after data removal from max heap
         displays trickle down actions to screen if display flag set
Function input/parameters: heap data (HeapType *), current index (int),
                           display flag (bool)
Function output/parameters: updated heap data (HeapType *)
Function output/returned: none
Device input/---: none
Device output/monitor: trickle down operations displayed as specified
Dependencies: setPatientFromStruct, copyPatient, comparePriorities, 
              getPatientInfo, printf, setPatientToString,
              privateTrickleDown (recursively), others acceptable
Note: May not be more than two sets of swap actions, and, 
      May not be more than two recursion calls in code
      --- one to the left child
      --- one to the right child
comparePriorities calls may use array elements as needed
*/
void privateTrickleDown( HeapType *heap, int currentIndex )
  {
   // initialize functions/variables
      // initialize left child data struct
      PatientType leftChildData;
      // initialize right child data struct
      PatientType rightChildData;
      // initialize left child index
      int leftChildIndex;
      // initialize right child index
      int rightChildIndex;
      // initialize right parent comparison variable
      int rightParentCompare;
      // initialize left parent comparison variable
      int leftParentCompare;
      // initialize right left comparison variable
      int rightLeftCompare;
      // initialize parent string for formating
      char parentStr[ STD_STR_LEN ];
      // initialize left child string for formating
      char leftChildStr[ STD_STR_LEN ];
      // initialize right child string for formating
      char rightChildStr[ STD_STR_LEN ];
   
   // assign left child index using formula
   leftChildIndex = ( currentIndex * 2 ) + 1;
   // assign right child index using formula
   rightChildIndex = ( currentIndex * 2 ) + 2;
   // assign comparison between right child and current index
   rightParentCompare = comparePriorities( heap->array[ rightChildIndex ],
                                                 heap->array[ currentIndex ] );
   // assign comparison between left child and current index
   leftParentCompare = comparePriorities( heap->array[ leftChildIndex ],
                                                 heap->array[ currentIndex ] );
   // assign comparison between right child and left child
   rightLeftCompare = comparePriorities( heap->array[ rightChildIndex ],
                                               heap->array[ leftChildIndex ] );
   
   // check for left child available
   if( leftChildIndex < heap->size )
     {
      // check for right child exist
      // and rightChild > leftChild
      // and right child > parent
      if( rightChildIndex < heap->size && rightLeftCompare > 0
                                                    && rightParentCompare > 0 )
        {
         // format string for parent data
         setPatientToString( parentStr, heap->array[ currentIndex ] );
         // format string for right child data
         setPatientToString( rightChildStr, heap->array[ rightChildIndex ] );
         // swap right with parent
         setPatientFromStruct( &rightChildData,
                                              heap->array[ rightChildIndex ] );
                                              
         setPatientFromStruct( &heap->array[ rightChildIndex ],
                                                  heap->array[ currentIndex ]);
                                                  
         setPatientFromStruct( &heap->array[currentIndex], rightChildData );
         
         if( heap->displayFlag )
           {
            printf( "\n\t- Trickle down swap: \n" );
            printf( "\t  - moving down parent: %s\n", parentStr );
            printf( "\t  - moving up right child: %s\n ", rightChildStr );
           }
         // recurse to the right
         privateTrickleDown( heap, rightChildIndex );
        }
        
      // check if leftChild > parent
      if( leftParentCompare > 0 )
        {
         // format string for parent data
         setPatientToString( parentStr, heap->array[ currentIndex ] );
         // format string for left child data
         setPatientToString( leftChildStr, heap->array[ leftChildIndex ] );
         // swap left with parent
         setPatientFromStruct( &leftChildData, heap->array[leftChildIndex] );
         setPatientFromStruct( &heap->array[ leftChildIndex ],
                                                  heap->array[ currentIndex ]);
         setPatientFromStruct( &heap->array[currentIndex], leftChildData );
         
         if( heap->displayFlag )
           {
            printf( "\n\t- Trickle down swap: \n" );
            printf( "\t  - moving down parent: %s\n", parentStr );
            printf( "\t  - moving up left child: %s\n ", leftChildStr );
           }
         // recurse to the left
         privateTrickleDown( heap, leftChildIndex );
        }
     }
  }


/*
Name: removeItem
Process: removes item from heap, reports removal action, adjusts data, 
        displays removal action, updates size, calls trickle down to reset heap
Function input/parameters: heap data (HeapType *)
Function output/parameters: updated heap data (HeapType *),
                            patient data removed (PatientType *)
Function output/returned: none
Device input/---: none
Device output/monitor: removal action displayed as specified
Dependencies: setPatientFromStruct, setPatientToString, printf,
              trickleDownArrayHeap, others acceptable
*/
void removeItem( PatientType *removed, HeapType *heap )
  {
   // initialize functions/variables
      // initialize temporary 'garbage' string
      char tempStr[ STD_STR_LEN ];
      
   // check for heap not empty
   if( heap->size > 0 )
     {
      // set index 0 to whever it needs to go
      setPatientFromStruct( removed, heap->array[ 0 ] );
      
      if( heap->displayFlag )
        {
         setPatientToString( tempStr, heap->array[ 0 ] );
         printf( "\n Removing patient: %s\n", tempStr );
        }
      // put index size - 1 into index 0
      setPatientFromStruct( &heap->array[ 0 ], heap->array[ heap->size - 1 ] );
      // decrement size
      heap->size = heap->size - 1;
      // call trickle down
      privateTrickleDown( heap, 0 );
     }
     
   // assume empty
   else
     {
      // set return value to empty
      removed = NULL;
     }
  }


/*
Name: setDisplayFlag
Process: sets Boolean flag to drive bubble up, trickle down displays
Function input/parameters: heap data (HeapType *), flag (bool)
Function output/parameters: updated heap data (HeapType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void setDisplayFlag( HeapType *heap, bool flagSet )
  {
   // set structs flag member to flag set
   heap->displayFlag = flagSet;
  }


/*
Name: showArray
Process: displays array as is, from lowest index to highest
Function input/parameters: heap data (HeapType)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: array displayed as specified
Dependencies: setPatientToString, printf
*/
void showArray( HeapType heap )
  {
   // intiialize variables
      // initialize temporary string
      char tempStr[ STD_STR_LEN ];
      // initialize index variable
      int index;
      
   // traverse the array
   for( index = 0; index<heap.size; index++ )
     {
      // format each data item at current index
      setPatientToString( tempStr, heap.array[index] );
      // print formatted data
      printf( "%s", tempStr );
     }
  }
