// header files
#include <stdio.h>
#include "File_Input_Utility.h"
#include "BST_Utility.h"

// constant definitions
   // none

// function prototypes

UniversityType *addItem( UniversityType *rootPtr );
void copyTreeExample( UniversityType *rootPtr );
void displaySelectedData( UniversityType *rootPtr );
void findItem( UniversityType *rootPtr );
UniversityType *removeUniversity( UniversityType *rootPtr );
UniversityType *uploadData();

// main function
int main( int argc, char *argv[] )
   {
    UniversityType *rootPtr;
    char fileName[ STD_STR_LEN ] = "Universities_49.csv";
    char userResponse;
    int dispNum;
    bool runProgram = true;

    // set title
    printf( "\nBST Testing Program\n" ); 
    printf( "===================\n" ); 

    // initialize iterator
    initializeBST( &rootPtr );
    
    // upload data
       // function: getDataFromFile
   rootPtr = getDataFromFile( fileName );   if( rootPtr != NULL )
       {
        do
           {
            printf( "\nBinary Search Tree Test Program\n" );
            printf(   "===============================\n" );
   
            printf( "1) (A)dd or Replace Item\n" );
            printf( "2) (F)ind Item\n" );
            printf( "3) (R)emove Item\n" );
            printf( "4) (C)opy Tree\n" );
            printf( "5) Display Data (I)n Order\n" );
            printf( "6) Display Data Pos(t) Order\n" );
            printf( "7) Display Data Pr(e) Order\n" );
            printf( "8) Display (S)elected Data\n" );
            printf( "9) End (P)rogram\n" );
   
            printf( "\nEnter selection: " );
            scanf( "%c", &userResponse );
            fflush( stdin );
   
            switch( userResponse )
               {
                case '1': case 'a': case 'A':
                   rootPtr = addItem( rootPtr );
                   break;
   
                case '2': case 'f': case 'F':
                   findItem( rootPtr );
                   break;
   
                case '3': case 'r': case 'R':
                   rootPtr = removeUniversity( rootPtr );
                   break;
   
                case '4': case 'c': case 'C':
                   copyTreeExample( rootPtr );
                   break;
   
                case '5': case 'i': case 'I':
                   printf( "\nDisplay in order:\n" );
                   dispNum = 1;
                   displayInOrder( rootPtr, &dispNum );
                   break;
   
                case '6': case 't': case 'T':
                   printf( "\nDisplay post order:\n" );
                   dispNum = 1;
                   displayPostOrder( rootPtr, &dispNum );
                   break;
   
                case '7': case 'e': case 'E':
                   printf( "\nDisplay pre order:\n" );
                   dispNum = 1;
                   displayPreOrder( rootPtr, &dispNum );
                   break;
   
                case '8': case 's': case 'S':
                   dispNum = 1;
                   displaySelectedData( rootPtr );
                   break;
   
                case '9': case 'p': case 'P':
                   runProgram = false;
                   break;
   
                default:
                   printf( "Incorrect entry, Try again\n" );
                   break;               
               }
           }
        while( runProgram );    
        // end program
       }
    // end correct upload test

    else
       {
        printf( "Data not found - Program aborted\n" );
       }

       // clear BST
          // function: clearTree
       rootPtr = clearTree( rootPtr );

       // show program end
          // function: printf
       printf( "\nEnd Program\n" );

       // return success
       return 0;
   }

/*
Name: addItem
Process: prompts user for individual input, then loads to tree
Function input/parameters: pointer to root node (UniversityType *)
Function output/parameters: none
Function output/returned: root/link to recursive pointer (UniversityType *)
Device input/keyboard: prompts user as needed
Device output/monitor: displays data as specified
Dependencies: printf, scanf, gets, insertRawData, fflush
*/
UniversityType *addItem( UniversityType *rootPtr )
   {
    char univName[ STD_STR_LEN ];
    char univCity[ TINY_STR_LEN ];
    int univRank;

    printf( "\nAdd Item Module\n" );

    printf( "Enter university name: " );
    gets( univName );

    printf( "Enter university city: " );
    fgets( univCity, STD_STR_LEN - 1, stdin );

    printf( "Enter rank: " );
    scanf( "%d", &univRank );
    fflush( stdin );

    rootPtr = insertRawData( rootPtr, univName, univCity, univRank );

    printf( "\nUniversity %s added to BST\n", univName );

    return rootPtr;
   }

/*
Name: copyTreeExample
Process: shows original tree, copies tree, then shows copied display
Function input/parameters: pointer to root node (UniversityType *) 
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displays as specified
Dependencies: printf, displayInOrder, copyTree, clearTree, fflush
*/
void copyTreeExample( UniversityType *rootPtr )
   {
    UniversityType *cpdTreePtr;
    int dispNum = 1;

    printf( "\nCopy Tree Module\n" );

    printf( "\nOriginal Tree Displayed:\n" );
    displayInOrder( rootPtr, &dispNum );
    cpdTreePtr = copyTree( rootPtr );

    printf( "\n\nCopied Tree Displayed:\n" );
    dispNum = 1;
    displayInOrder( cpdTreePtr, &dispNum );

    clearTree( cpdTreePtr );

    fflush( stdin );
   }
/*
Name: displaySelectedData
Process: prompts user for university name, then displays all items
         beginning with the provided string segment
Function input/parameters: pointer to root node (UniversityType *)
Function output/parameters: none
Function output/returned: none
Device input/keyboard: prompts user as needed
Device output/monitor: displays data as specified
Dependencies: printf, scanf, fflush, displaySelectionInOrder
*/
void displaySelectedData( UniversityType *rootPtr )
   {
    char univNameSgmnt[ STD_STR_LEN ];
    int dispNum = 1;

    printf( "\nDisplay University Selection Module\n" );

    printf( "Enter segment of university name: " );
    scanf( "%s", univNameSgmnt );

    fflush( stdin );

    printf( "\nSelected Data Displayed:\n" );
    displaySelectionInOrder( rootPtr, univNameSgmnt, &dispNum );
   }

/*
Name: findItem
Process: prompts user for university name, finds and displays if available,
         otherwise displays "University not found"
Function input/parameters: pointer to root node (UniversityType *)
Function output/parameters: none
Function output/returned: none
Device input/keyboard: prompts user as needed
Device output/monitor: displays data as specified
Dependencies: printf, scanf, universityDataToString, search, fflush
*/
void findItem( UniversityType *rootPtr )
   {
    UniversityType *resultPtr;
    char resultStr[ MAX_STR_LEN ];
    char univNameSgmnt[ STD_STR_LEN ];

    printf( "\nFind Item Module\n" );

    printf( "Enter segment of university name: " );
    scanf( "%s", univNameSgmnt );
    
    resultPtr = search( rootPtr, univNameSgmnt );

    if( resultPtr != NULL )
       {
        universityDataToString( resultStr, *resultPtr );

        printf( "University found: %s\n", resultStr );
       }

    else
       {
        printf( "University not found\n" );
       }

    fflush( stdin );
   }

/*
Name: removeUniversity
Process: prompts user for university name, 
         finds and verifies item to be removed,
         then removes as prompted
Function input/parameters: pointer to root node (UniversityType *)
Function output/parameters: none
Function output/returned: pointer to updated root node (UniversityType *)
Device input/keyboard: prompts user as needed
Device output/monitor: displays data as specified
Dependencies: printf, scanf, universityDataToString, search, removeItem, fflush
*/
UniversityType *removeUniversity( UniversityType *rootPtr )
   {
    UniversityType *resultPtr;
    UniversityType result;
    char resultStr[ HUGE_STR_LEN ];
    char univNameSgmnt[ STD_STR_LEN ];
    char response;

    printf( "\nRemove Item Module\n" );

    printf( "Enter segment of university name: " );
    scanf( "%s", univNameSgmnt );
    
    resultPtr = search( rootPtr, univNameSgmnt );

    if( resultPtr != NULL )
       {
        universityDataToString( resultStr, *resultPtr );

        fflush( stdin );
        printf( "Remove %s (y/n)?: ", resultStr );

        scanf( "%c", &response );

        if( ( response == 'y' || response == 'Y' ) &&
                                removeItem( &result, &rootPtr, univNameSgmnt ) )
           {
            printf( "\nUniversity removed: %s\n", resultStr );
           }

        else
           {
            printf( "\nUniversity: %s not removed\n", univNameSgmnt );
           }
       }

    else
       {
        printf( "University not found\n" );
       }

    fflush( stdin );

    return rootPtr;
   }

