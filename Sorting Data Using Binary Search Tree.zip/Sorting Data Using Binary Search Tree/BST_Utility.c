#include "BST_utility.h"

/*
Name: clearTree
Process: recursively deallocates tree data, uses post order traversal algorithm
Function input/parameters: working pointer for recursion (UniversityType *)
Function output/parameters: none
Function output/returned: empty tree (NULL)
Device input/---: none
Device output/---: none
Dependencies: free, clearTree (recursively)
*/
UniversityType *clearTree(UniversityType *wkgPtr) 
  {
   // if working pointer is not null
   if( wkgPtr != NULL ) 
     {
      // recurse through left side and free
      clearTree( wkgPtr->leftChildPtr );
      // recurse through right side and free
      clearTree( wkgPtr->rightChildPtr );
      // free the current node      
      free( wkgPtr );
     }

   return NULL;
  }

/*
Name: copyTree
Process: recursively duplicates the provided tree
         using a pre order traversal strategy
Function input/parameters: working pointer for recursion 
                                                        (const UniversityType *)
Function output/parameters: none
Function output/returned: pointer to duplicate tree (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: createNodeFromNode, copyTree (recursively)
*/
UniversityType *copyTree( const UniversityType *wkgPtr )
  {
   // initialize functions/variables
      // initialize new node variable
      UniversityType *newNode;
      
   // test whether the wkg pointer is empty
   if( wkgPtr != NULL ) 
     {
      // copy the current nodes data
      newNode = createNodeFromNode( *wkgPtr );

      // copy the left side of the tree
      newNode->leftChildPtr = copyTree( wkgPtr->leftChildPtr );

      // copy the right side of the tree
      newNode->rightChildPtr = copyTree( wkgPtr->rightChildPtr );

      // return copied node
      return newNode;
     }

   // return copied node
   return NULL;
  }

/*
Name: createNodeFromData
Process: captures data from individual data items, 
         dynamically creates new node,
         copies data, and returns pointer to new node         
Function input/parameters: university and city (const char *), rank (int)
Function output/parameters: none
Function output/returned: pointer to new node as specified (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: malloc, privateCopyString
*/
UniversityType *createNodeFromData( const char *univName, 
                                           const char *univCity, int univRank )
  {
   // initialize functions/variables
      // initialize functions/variables
      UniversityType *newNode;
   
   // allocate memory for new node
   newNode = ( UniversityType * )malloc( sizeof( UniversityType ) );
   
   // test to see if the allocation was successful
   if( newNode != NULL ) 
     {
      // copy the university name
      privateCopyString( newNode->name, univName );
   
      // copy the city name
      privateCopyString( newNode->city, univCity );
   
      // copy the rank
      newNode->rank = univRank;
    
      // initialize left and right child pointers to NULL
      newNode->leftChildPtr = NULL;
      newNode->rightChildPtr = NULL;
      
      // return new node
      return newNode;
     }
   
   // otherwise return null
   return NULL;
  }
/*
Name: createNodeFromNode
Process: captures data from source node pointer, dynamically creates new node,
         copies data, and returns pointer to new node         
Function input/parameters: node to be copied (const UniversityType)
Function output/parameters: none
Function output/returned: pointer to new node as specified (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: createNodeFromData
*/
UniversityType *createNodeFromNode( const UniversityType source )
  {
   // create a new node and return pointer
   return createNodeFromData( source.name, source.city, source.rank );
  }

/*
Name: displayInOrder
Process: recursively displays numbered tree items using in order traversal
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayInOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayInOrder( const UniversityType *univPtr, int *number )
  {
   // initialize functions/variables
      // initialize temporary string variable
      char tempStr[ MAX_STR_LEN ];
      
   // make sure the pointer isn't empty
   if( univPtr != NULL )
     {
      // dipslay left side of the tree
      displayInOrder( univPtr->leftChildPtr, number );

      // format the current data to print
      universityDataToString( tempStr, *univPtr ); 
      // print the formated string
      printf( "%5d) %s", *number, tempStr );
      *number = *number + 1;
      // display right side of the tree
      displayInOrder( univPtr->rightChildPtr, number );
     }
  }

/*
Name: displayPostOrder
Process: recursively displays numbered tree items using post order traversal
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayPostOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayPostOrder( const UniversityType *univPtr, int *number )
  {
   // initialize functions/variables
      // initialize tempString variable
      char tempStr[ MAX_STR_LEN ];
   
   // check to see if the tree is empty
   if( univPtr != NULL ) 
     {
      // recurse left side of tree
      displayPostOrder( univPtr->leftChildPtr, number );

      // recurse right side of tree
      displayPostOrder( univPtr->rightChildPtr, number );
      
      // format the data to string
      universityDataToString( tempStr, *univPtr ); 
      
      printf( "%5d) %s", *number, tempStr );
      *number = *number + 1;
     }
  }

/*
Name: displayPreOrder
Process: recursively displays numbered tree items using pre order traversal
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayPreOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayPreOrder( const UniversityType *univPtr, int *number )
  {
   // initialize functions/variables
      // initialize tempString variable
      char tempStr[ MAX_STR_LEN ];
      
   if( univPtr != NULL ) 
     {
      // format current node data to string
      universityDataToString( tempStr, *univPtr ); 
      
      printf( "%5d) %s", *number, tempStr );
      *number = *number + 1;
      
      // recurse right child
      displayPreOrder( univPtr->leftChildPtr, number );

      // recurse left child
      displayPreOrder( univPtr->rightChildPtr, number );
     }
  }

/*
Name: displaySelectionInOrder
Process: recursively displays numbered selected items in tree using 
         in order traversal, items are specified by provided starting segment 
         of university name string
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           name segment for searching (const char *)
                           pointer to display number (int *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: privateCompareStringSegments, universityDataToString, printf,
              displaySelectionInOrder (recursively)
*/
void displaySelectionInOrder( UniversityType *univPtr, 
                                         const char *nameSegment, int *number )
  {
   // initialize functions/variables
      // initialize temporary string variable
      char tempStr[ MAX_STR_LEN ];
      
   // check to see if tree is empty
   if( univPtr != NULL ) 
     {
      // recurse left side of tree
      displaySelectionInOrder( univPtr->leftChildPtr, nameSegment, number );

      // check to see if the current node matches name segment
      if( privateCompareStringSegments( nameSegment, univPtr->name ) == 0 )
        {
         // format data to string
         universityDataToString( tempStr, *univPtr );
         printf( "%5d) %s", *number, tempStr );
         *number = *number + 1;
        }

      // recurse right side of tree
      displaySelectionInOrder( univPtr->rightChildPtr, nameSegment, number );
     }
  }
/*
Name: getDataFromFile
Process: uploads data from file with unknown number of data sets,
         has internal Boolean to test for data input success
Function input/parameters: file name (const char *)
Function output/parameters: none
Function output/returned: pointer to BST holding data (UniversityType *)
Device input/---: data from HD
Device output/monitor: if internal Boolean set, displays uploaded values
Dependencies: openInputFile, readStringToLineEndFromFile, 
              checkForEndOfInputFile, readIntegerFromFile,
              readStringToDelimiterFromFile, readCharacterFromFile, 
              insertRawData, printf, closeInputFile
*/
UniversityType *getDataFromFile( const char *fileName )
  {
   // initialize functions/variables
      // initialize the temporary string
      char tempStr[ STD_STR_LEN ];
      // initialize rank variable
      int rank;
      // initialize university name variable
      char university[ STD_STR_LEN ];
      // initialize town name variable
      char town[ STD_STR_LEN ];
      // initialize starting data index
      int dataIndex = 1;
      // initialize verbose flag variable
      bool verboseFlag = true;
      // initialize new node as NULL
      UniversityType *newNode = NULL;
      
   // open input file
   if( openInputFile( fileName ) )
     {
      // print begin loading data from file
      printf( "\nBegin Loading Data From File . . ." );
      
      // input top line (ignore)
      readStringToLineEndFromFile( tempStr );
      
      // assign rank
      rank = readIntegerFromFile();
      
      // while checkForEndOfInputFile is false
      while( !checkForEndOfInputFile() )
        {
         // "eat" the next comma
         readCharacterFromFile();
          
         // assign University
         readStringToDelimiterFromFile( COMMA, university );
         
         // assign town
         readStringToDelimiterFromFile( COMMA, town );
         
         // if verbose flag is true
         if( verboseFlag )
           {
            // print information
            printf( "\n\t%2d) Name: %s, City: %s, Rank: %d", dataIndex,
                                                      university, town, rank );
           }
           
         // insert data into the tree
         newNode = insertRawData( newNode, university, town, rank );
         
         // increment dataIndex
         dataIndex = dataIndex + 1;
         
         // assign rank
         rank = readIntegerFromFile();
        }
      // end of while loop
      
      // print end loading data from file
      printf( "\n\t\t\t\t\t. . . End Loading Data From File\n" );
      
      // close file
      closeInputFile( fileName );
      // end of if statement
      
      // return new node
      return newNode;
     }
   
   // if the file doesn't open
   // return NULL
   return NULL;
  }

/*
Name: initializeBST
Process: sets BST root pointer to NULL, root pointer is returned by address
Function input/parameters: address of root pointer (UniversityType **)
Function output/parameters: address of updated working pointer 
                            (UniversityType **)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void initializeBST( UniversityType **addressOfRootPtr )
  {
   // assign address of the root pointer to NULL
   addressOfRootPtr = NULL;
  }

/*
Name: insertNodeData
Process: recursively searches for available node in BST by name,
         creates new node and returns it to the calling function,
         if node is already in tree, data is overwritten,
         uses "look up" strategy
Function input/parameters: working pointer for recursion (UniversityType *),
                                          node to insert (const UniversityType )
Function output/parameters: none
Function output/returned: pointer to root (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: insertRawData
*/
UniversityType *insertNodeData( UniversityType *wkgPtr, 
                                                const UniversityType univNode )
  {
   // return inserted data
   return insertRawData( wkgPtr, univNode.name, univNode.city, univNode.rank );
  }

/*
Name: insertRawData
Process: recursively searches for available node in BST by name,
         creates new node and returns it to the calling function,
         if node is already in tree, data is overwritten,
         uses "look up" strategy
Function input/parameters: working pointer for recursion (UniversityType *),
                           university name (const char *), 
                           university city (const char *),
                           university ranking (int)
Function output/parameters: none
Function output/returned: pointer to current or new node as specified 
                                                              (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, setNodeRawData, 
              createNodeFromData, insertRawData (recursively)
*/
UniversityType *insertRawData( UniversityType *wkgPtr,  
                     const char *univName, const char *univCity, int univRank )
  {
   // initialize functions/variables
      // initialize comparison result variable
      int compareResult;
      
   // check to see if tree is empty
   if( wkgPtr != NULL ) 
     {
      // compare to see if the given name matches, 
      // is less than or greater than working pointer
      compareResult = privateCompareStrings( univName, wkgPtr->name );
      
      // check if the comparison is less then zero
      if( compareResult < 0 ) 
        {
         // insert left side
         wkgPtr->leftChildPtr = insertRawData( wkgPtr->leftChildPtr, univName,
                                                          univCity, univRank );
        } 
        
      // check if the comparison is more than zero
      else if( compareResult > 0 ) 
        {
         // insert right side
         wkgPtr->rightChildPtr = insertRawData( wkgPtr->rightChildPtr,
                                                univName, univCity, univRank );
        }
      // otherwise the data matches, overwrite
      else 
        {
         // overwrite current node
         setNodeRawData( wkgPtr, univName, univCity, univRank );
        }

      // return the working pointer
      return wkgPtr;
     }

   // create first node
   return createNodeFromData( univName, univCity, univRank );
  }
  
/*
Name: isEmpty
Process: tests BST for empty, returns result
Function input/parameters: pointer to root node (UniversityType *)
Function output/parameters: none
Function output/returned: result of test as specified (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool isEmpty( UniversityType *univPtr )
  {
   // check and return if the first pointer is NULL
   return ( univPtr == NULL );
  }

/*
Name: removeFromMin
Process: recursively searches for min node, when found, 
         node is unlinked from tree, and returned
Function input/parameters: pointer to parent and child nodes (UniversityType *)
Function output/parameters: none
Function output/returned: pointer to removed node (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: removeFromMin (recursively)
*/
UniversityType *removeFromMin( UniversityType *parentPtr,
                                                     UniversityType *childPtr )
  {
   // check to see if left child pointer is empty
   if ( childPtr->leftChildPtr != NULL )
      {
       // recurse left side
       return removeFromMin( childPtr, childPtr->leftChildPtr );
      }

   // assign left child pointer to NULL
   parentPtr->leftChildPtr = NULL; // should have set to childs right

   // return child pointer
   return childPtr;
  }
  
/*
Name: removeItem
Process: searches for item, if found, sets data into result pointer,
         then removes item from tree using helper function and returns true,
         otherwise, sets node data to empty and returns false
Function input/parameters: address of root pointer (UniversityType **),
                           name segment to be removed (const char *) 
Function output/parameters: pointer to result or empty node, as appropriate
                                                              (UniversityType *)
Function output/returned: Boolean result of operation (bool)
Device input/---: none
Device output/---: none
Dependencies: search, setNodeData, removeItemHelper, setNodeToEmpty
*/
bool removeItem( UniversityType *resultPtr, UniversityType **rootPtr, 
                                                         const char *toRemove )
  {
   // search the tree, if item found
   if( search( *rootPtr, toRemove ) != NULL ) // recheck after making item
      {
       item =  search( *rootPtr, toRemove );
       // set data to result pointer
       setNodeData( resultPtr, item );

       // remove the item
       
       *rootPtr = removeItemHelper( *rootPtr, toRemove );
       

       return true;
      }

   // set the current node to empty
   setNodeToEmpty( resultPtr );

   // Return false
   return false;
  }

/*
Name: removeItemHelper
Process: recursively searches for item, removes node,
         deallocates dynamic memory of removed node,
         returns updated link to parent (at each recursive level)
Function input/parameters: pointer to working node (UniversityType *),
                           name segment to be removed (const char *) 
Function output/parameters: none
Function output/returned: root/link to recursive parent
Device input/---: none
Device output/---: none
Dependencies: setNodeData, free, removeItemHelper (recursively),
               privateCompareStringSegments, removeFromMin
Note: Only one return at end of function
*/
UniversityType *removeItemHelper( UniversityType *wkgPtr, 
                                                         const char *toRemove )
  {
   // initialize functions/variables
   UniversityType *tempPtr = NULL;

   // check for current pointer not NULL
   if ( wkgPtr != NULL )
     {

      // SL #1

      // check if remove value is less than the current value
      if( privateCompareStringSegments( toRemove, wkgPtr->name ) < 0 )
        {
         // call recursion to the left, assign it to the left child
         wkgPtr->leftChildPtr = 
                            removeItemHelper( wkgPtr->leftChildPtr, toRemove );
        }

      // otherwise, check if remove value is greater than the current value
      else if( privateCompareStringSegments( toRemove, wkgPtr->name ) > 0 )
        {
         // call recursion to the right, assign it to the right child
         wkgPtr->rightChildPtr = 
                           removeItemHelper( wkgPtr->rightChildPtr, toRemove );
        }


      // SL #2 - remove value is found
      else
        {
         // otherwise, check if current node's left child is NULL
         if( wkgPtr->leftChildPtr == NULL )
           {
            // set a temp pointer to the current pointer
            tempPtr = wkgPtr;

            // set the current pointer to the right child
            wkgPtr = wkgPtr->rightChildPtr;

            // free the temp pointer
            free( tempPtr );
           }

         // otherwise, check if current node's right child is NULL
         else if( wkgPtr->rightChildPtr == NULL )
           {
            // set a temp pointer to the current pointer
            tempPtr = wkgPtr;

            // set the current pointer to the left child
            wkgPtr = wkgPtr->leftChildPtr;

            // free the temp pointer
            free( tempPtr );
           }

         // SL #3 - current node has two children
         else
           {
            // otherwise, check for right child's left child NULL
            if( wkgPtr->rightChildPtr->leftChildPtr == NULL )
              {
               // copy the data from the right child into the current node
               setNodeData( wkgPtr, *wkgPtr->rightChildPtr );

               // set temp pointer to the right child
               setNodeData( tempPtr, *wkgPtr->rightChildPtr );

               // set current pointer's right child 
               // to temp pointer's right child
               setNodeData( wkgPtr->rightChildPtr, *tempPtr->rightChildPtr );

               // free the temp pointer
               free( tempPtr );
              }

            // otherwise
            else
              {
               // remove, return min node, assign to temp pointer
               tempPtr = removeFromMin( wkgPtr, wkgPtr->leftChildPtr );

               // copy the data from the temp pointer into the current node
               setNodeData( wkgPtr, *tempPtr );

               // free the temp pointer
               free( tempPtr );
               }
           }
        }
     } 
   // return the current node pointer
   return wkgPtr;
  }

/*
Name: search
Process: recursively searches for item, if found, returns pointer to node,
         otherwise, returns NULL
Function input/parameters: pointer to working node (UniversityType *),
                           name segment to be removed (const char *)
Function output/parameters: none
Function output/returned: pointer to found node, or NULL, as specified 
                                                              (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: privateCompareStringSegments, search (recursively)
*/
UniversityType *search( UniversityType *wkgPtr, const char *toFind )
  {
   // initialize function/variables
      // initialize compare result
      int compareResult;
      
   // check if the tree is empty
   if( wkgPtr != NULL )
     {
      // compare the name of current node to the toFind variable
      compareResult = privateCompareStringSegments( toFind, wkgPtr->name );
      
      // test if the name is less than node
      if( compareResult < 0 )
        {
         // recurse left, return
         return search( wkgPtr->leftChildPtr, toFind );
        }
        
      // compare the name of current node to the toFind variable
      else if( compareResult > 0 )
        {
         // recurse right, return
         return search( wkgPtr->rightChildPtr, toFind );
        }
        
      // otherwise, duplicated name
      else
        {
         // return current node
         return wkgPtr;
        }
     }
   // end of check for not NULL

   // return NULL
   return NULL;
  }
/*
Name: setNodeData
Process: copies data from source node to destination pointer,
         does not copy or set node child pointers
Function input/parameters: node to be copied (UniversityType)
Function output/parameters: pointer to destination node (UniversityType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: setNodeRawData
*/
void setNodeData( UniversityType *destPtr, const UniversityType source )
  {
   // set the node data
   setNodeRawData( destPtr, source.name, source.city, source.rank );
  }

/*
Name: setNodeRawData
Process: copies data from raw data to destination pointer,
         does not copy or set node child pointers
Function input/parameters: university name and city (const char *),
                           university rank (int)
Function output/parameters: destination pointer (UniversityType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCopyString
*/
void setNodeRawData( UniversityType *destPtr, const char *univName,
                                           const char *univCity, int univRank )
  {
   // copy the name of the university to node
   privateCopyString( destPtr->name, univName );
   
   // copy the name of the university to node
   privateCopyString( destPtr->city, univCity );
   
   // copy the rank of the university to node
   destPtr->rank = univRank;
  }

/*
Name: setNodeToEmpty
Process: sets node strings to empty, and ranking to zero
Function input/parameters: pointer to node (UniversityType *),
         does not copy or set node child pointers
Function output/parameters: updated pointer to node (UniversityType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: setNodeRawData
*/
void setNodeToEmpty( UniversityType *nodePtr )
  {
   // set node to NULL for names and zero for rank
   setNodeRawData( nodePtr, NULL, NULL, 0 );
  }

/*
Name: universityDataToString
Process: sets data from node to formatted string
Function input/parameters: node with data to be set (const UniversityType)
Function output/parameters: string array with result (char *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: sprintf
*/
void universityDataToString( char *destStr, 
                                          const UniversityType universityData )
  {
   // format the the given data to the specified string format
   sprintf( destStr, "Name: %s, City: %s, Rank: %d\n", universityData.name,
                                   universityData.city, universityData.rank );
  }