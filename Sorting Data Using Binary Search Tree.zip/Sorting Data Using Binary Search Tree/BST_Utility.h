#ifndef BST_UTILITY_H
#define BST_UTILITY_H

// header files
#include <stdlib.h>
#include <stdio.h>
#include "File_Input_Utility.h"
#include "GeneralUtility.h"
#include "StandardConstants.h"

// external constants


// data types

typedef struct UniversityStruct
   {
    char name[ STD_STR_LEN ];
    char city[ MIN_STR_LEN ];
    int rank;

    struct UniversityStruct *leftChildPtr;
    struct UniversityStruct *rightChildPtr;
   } UniversityType;

// prototypes

/*
Name: clearTree
Process: recursively deallocates tree data, uses post order traversal algorithm
Function input/parameters: working pointer for recursion (UniversityType *)
Function output/parameters: none
Function output/returned: empty tree (NULL)
Device input/---: none
Device output/---: none
Dependencies: free, clearTree (recursively)
*/
UniversityType *clearTree( UniversityType *wkgPtr );

/*
Name: copyTree
Process: recursively duplicates the provided tree
         using a pre order traversal strategy
Function input/parameters: working pointer for recursion 
                                                        (const UniversityType *)
Function output/parameters: none
Function output/returned: pointer to duplicate tree (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: createNodeFromNode, copyTree (recursively)
*/
UniversityType *copyTree( const UniversityType *wkgPtr );

/*
Name: createNodeFromData
Process: captures data from individual data items, 
         dynamically creates new node,
         copies data, and returns pointer to new node         
Function input/parameters: university and city (const char *), rank (int)
Function output/parameters: none
Function output/returned: pointer to new node as specified (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: malloc, privateCopyString
*/
UniversityType *createNodeFromData( const char *univName, 
                                           const char *univCity, int univRank );

/*
Name: createNodeFromNode
Process: captures data from source node pointer, dynamically creates new node,
         copies data, and returns pointer to new node         
Function input/parameters: node to be copied (const UniversityType)
Function output/parameters: none
Function output/returned: pointer to new node as specified (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: createNodeFromData
*/
UniversityType *createNodeFromNode( const UniversityType source );

/*
Name: displayInOrder
Process: recursively displays numbered tree items using in order traversal
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayInOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayInOrder( const UniversityType *univPtr, int *number );

/*
Name: displayPostOrder
Process: recursively displays numbered tree items using post order traversal
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayPostOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayPostOrder( const UniversityType *univPtr, int *number );

/*
Name: displayPreOrder
Process: recursively displays numbered tree items using pre order traversal
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           pointer to display number (int *)
Function output/parameters: pointer to display number (int *)
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: universityDataToString, printf, displayPreOrder (recursively)
Note: Uses printf control to align numbering
*/
void displayPreOrder( const UniversityType *univPtr, int *number );

/*
Name: displaySelectionInOrder
Process: recursively displays numbered selected items in tree using 
         in order traversal, items are specified by provided starting segment 
         of university name string
Function input/parameters: working pointer for recursion 
                                                       (const UniversityType *),
                           name segment for searching (const char *)
                           pointer to display number (int *)
Function output/parameters: none
Function output/returned: none
Device input/---: none
Device output/monitor: displayed as specified
Dependencies: privateCompareStringSegments, universityDataToString, printf,
              displaySelectionInOrder (recursively)
*/
void displaySelectionInOrder( UniversityType *univPtr, 
                                         const char *nameSegment, int *number );

/*
Name: getDataFromFile
Process: uploads data from file with unknown number of data sets,
         has internal Boolean to test for data input success
Function input/parameters: file name (const char *)
Function output/parameters: none
Function output/returned: pointer to BST holding data (UniversityType *)
Device input/---: data from HD
Device output/monitor: if internal Boolean set, displays uploaded values
Dependencies: openInputFile, readStringToLineEndFromFile, 
              checkForEndOfInputFile, readIntegerFromFile,
              readStringToDelimiterFromFile, readCharacterFromFile, 
              insertRawData, printf, closeInputFile
*/
UniversityType *getDataFromFile( const char *fileName );

/*
Name: initializeBST
Process: sets BST root pointer to NULL, root pointer is returned by address
Function input/parameters: address of root pointer (UniversityType **)
Function output/parameters: address of updated working pointer 
                            (UniversityType **)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: none
*/
void initializeBST( UniversityType **addressOfRootPtr );

/*
Name: insertNodeData
Process: recursively searches for available node in BST by name,
         creates new node and returns it to the calling function,
         if node is already in tree, data is overwritten,
         uses "look up" strategy
Function input/parameters: working pointer for recursion (UniversityType *),
                                          node to insert (const UniversityType )
Function output/parameters: none
Function output/returned: pointer to root (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: insertRawData
*/
UniversityType *insertNodeData( UniversityType *wkgPtr, 
                                                const UniversityType univNode );

/*
Name: insertRawData
Process: recursively searches for available node in BST by name,
         creates new node and returns it to the calling function,
         if node is already in tree, data is overwritten,
         uses "look up" strategy
Function input/parameters: working pointer for recursion (UniversityType *),
                           university name (const char *), 
                           university city (const char *),
                           university ranking (int)
Function output/parameters: none
Function output/returned: pointer to current or new node as specified 
                                                              (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: privateCompareStrings, setNodeRawData, 
              createNodeFromData, insertRawData (recursively)
*/
UniversityType *insertRawData( UniversityType *wkgPtr,  
                     const char *univName, const char *univCity, int univRank );

/*
Name: isEmpty
Process: tests BST for empty, returns result
Function input/parameters: pointer to root node (UniversityType *)
Function output/parameters: none
Function output/returned: result of test as specified (bool)
Device input/---: none
Device output/---: none
Dependencies: none
*/
bool isEmpty( UniversityType *univPtr );

/*
Name: removeFromMin
Process: recursively searches for min node, when found, 
         node is unlinked from tree, and returned
Function input/parameters: pointer to parent and child nodes (UniversityType *)
Function output/parameters: none
Function output/returned: pointer to removed node (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: removeFromMin (recursively)
*/
UniversityType *removeFromMin( UniversityType *parentPtr,
                                                     UniversityType *childPtr );

/*
Name: removeItem
Process: searches for item, if found, sets data into result pointer,
         then removes item from tree using helper function and returns true,
         otherwise, sets node data to empty and returns false
Function input/parameters: address of root pointer (UniversityType **),
                           name segment to be removed (const char *) 
Function output/parameters: pointer to result or empty node, as appropriate
                                                              (UniversityType *)
Function output/returned: Boolean result of operation (bool)
Device input/---: none
Device output/---: none
Dependencies: search, setNodeData, removeItemHelper, setNodeToEmpty
*/
bool removeItem( UniversityType *resultPtr, UniversityType **rootPtr, 
                                                         const char *toRemove );

/*
Name: removeItemHelper
Process: recursively searches for item, removes node,
         deallocates dynamic memory of removed node,
         returns updated link to parent (at each recursive level)
Function input/parameters: pointer to working node (UniversityType *),
                           name segment to be removed (const char *) 
Function output/parameters: none
Function output/returned: root/link to recursive parent
Device input/---: none
Device output/---: none
Dependencies: setNodeData, free, removeItemHelper (recursively),
               privateCompareStringSegments, removeFromMin
Note: Only one return at end of function
*/
UniversityType *removeItemHelper( UniversityType *wkgPtr, 
                                                         const char *toRemove );

/*
Name: search
Process: recursively searches for item, if found, returns pointer to node,
         otherwise, returns NULL
Function input/parameters: pointer to working node (UniversityType *),
                           name segment to be removed (const char *)
Function output/parameters: none
Function output/returned: pointer to found node, or NULL, as specified 
                                                              (UniversityType *)
Device input/---: none
Device output/---: none
Dependencies: privateCompareStringSegments, search (recursively)
*/
UniversityType *search( UniversityType *wkgPtr, const char *toFind );

/*
Name: setNodeData
Process: copies data from source node to destination pointer,
         does not copy or set node child pointers
Function input/parameters: node to be copied (UniversityType)
Function output/parameters: pointer to destination node (UniversityType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: setNodeRawData
*/
void setNodeData( UniversityType *destPtr, const UniversityType source );

/*
Name: setNodeRawData
Process: copies data from raw data to destination pointer,
         does not copy or set node child pointers
Function input/parameters: university name and city (const char *),
                           university rank (int)
Function output/parameters: destination pointer (UniversityType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: privateCopyString
*/
void setNodeRawData( UniversityType *destPtr, const char *univName,
                                           const char *univCity, int univRank );

/*
Name: setNodeToEmpty
Process: sets node strings to empty, and ranking to zero
Function input/parameters: pointer to node (UniversityType *),
         does not copy or set node child pointers
Function output/parameters: updated pointer to node (UniversityType *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: setNodeRawData
*/
void setNodeToEmpty( UniversityType *nodePtr );

/*
Name: universityDataToString
Process: sets data from node to formatted string
Function input/parameters: node with data to be set (const UniversityType)
Function output/parameters: string array with result (char *)
Function output/returned: none
Device input/---: none
Device output/---: none
Dependencies: sprintf
*/
void universityDataToString( char *destStr, 
                                          const UniversityType universityData );


#endif   // BST_UTILITY_H

